import React, { useState } from 'react';
import { NavigationTab, ComplianceItem, Announcement, ReportConfig } from './types';
import { INITIAL_COMPLIANCE_ITEMS, INITIAL_ANNOUNCEMENTS } from './data/esgData';
import { Sidebar } from './components/Sidebar';
import { TopNavBar } from './components/TopNavBar';
import { ExecutiveDashboardView } from './components/ExecutiveDashboardView';
import { CarbonAnalyticsView } from './components/CarbonAnalyticsView';
import { ComplianceTrackingView } from './components/ComplianceTrackingView';
import { SustainabilityCopilotView } from './components/SustainabilityCopilotView';
import { AIReportGenView } from './components/AIReportGenView';

// Modals
import { UploadEvidenceModal } from './components/modals/UploadEvidenceModal';
import { ResolveActionModal } from './components/modals/ResolveActionModal';
import { ViewComplianceDetailsModal } from './components/modals/ViewComplianceDetailsModal';
import { AddComplianceItemModal } from './components/modals/AddComplianceItemModal';
import { GlobalMetricsModal } from './components/modals/GlobalMetricsModal';
import { AnnouncementsDrawer } from './components/modals/AnnouncementsDrawer';
import { RegionalDataModal } from './components/modals/RegionalDataModal';
import { SettingsModal, SupportModal } from './components/modals/SettingsAndSupportModals';
import { GenerateReportModal } from './components/modals/GenerateReportModal';

export function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('executive-dashboard');
  const [complianceItems, setComplianceItems] = useState<ComplianceItem[]>(INITIAL_COMPLIANCE_ITEMS);
  const [announcements, setAnnouncements] = useState<Announcement[]>(INITIAL_ANNOUNCEMENTS);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [copilotInitialPrompt, setCopilotInitialPrompt] = useState<string | null>(null);
  const [reportInitialNotes, setReportInitialNotes] = useState<string>('');

  // Modals state
  const [uploadEvidenceItem, setUploadEvidenceItem] = useState<ComplianceItem | null>(null);
  const [resolveActionItem, setResolveActionItem] = useState<ComplianceItem | null>(null);
  const [viewDetailsItem, setViewDetailsItem] = useState<ComplianceItem | null>(null);
  const [isAddingComplianceItem, setIsAddingComplianceItem] = useState(false);
  const [isGlobalMetricsOpen, setIsGlobalMetricsOpen] = useState(false);
  const [isAnnouncementsOpen, setIsAnnouncementsOpen] = useState(false);
  const [isRegionalDataOpen, setIsRegionalDataOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);
  const [isNewReportModalOpen, setIsNewReportModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Compliance Item Handlers
  const handleUploadEvidenceSuccess = (itemId: string, fileName: string) => {
    setComplianceItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            status: 'Under Review',
            evidenceFile: fileName,
            actionLabel: 'View Details',
            actionType: 'view',
          };
        }
        return item;
      })
    );
    showToast(`Evidence document "${fileName}" uploaded and submitted for audit.`);
  };

  const handleResolveActionSuccess = (itemId: string, note: string) => {
    setComplianceItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            status: 'Complete',
            actionLabel: 'Download',
            actionType: 'download',
            details: `${item.details || ''}\nResolution note: ${note}`,
          };
        }
        return item;
      })
    );
    showToast('Compliance action marked as resolved and logged.');
  };

  const handleAddComplianceItem = (newItem: ComplianceItem) => {
    setComplianceItems((prev) => [newItem, ...prev]);
    showToast(`New requirement "${newItem.title}" added to compliance ledger.`);
  };

  // Copilot navigation helpers
  const handleAskCopilot = (prompt: string) => {
    setCopilotInitialPrompt(prompt);
    setActiveTab('sustainability-copilot');
  };

  // Report Generator Quick Modal submit
  const handleNewReportSubmit = (config: ReportConfig) => {
    setReportInitialNotes(config.customNotes || '');
    setActiveTab('ai-report-gen');
  };

  const handleMarkAllAnnouncementsRead = () => {
    setAnnouncements((prev) => prev.map((a) => ({ ...a, read: true })));
    showToast('All announcements marked as read.');
  };

  const handleSelectAnnouncement = (id: string) => {
    setAnnouncements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, read: true } : a))
    );
  };

  return (
    <div id="app-root-container" className="min-h-screen bg-[#f7f9fb] flex flex-col font-['Inter',sans-serif] text-[#191c1e]">
      {/* Toast Notification */}
      {toastMessage && (
        <div
          id="app-toast-notification"
          className="fixed bottom-6 right-6 z-50 bg-[#003527] text-white text-[13.5px] font-semibold py-3 px-5 rounded-xl shadow-2xl flex items-center gap-2.5 border border-[#b0f0d6]/30 animate-in slide-in-from-bottom-5 duration-200"
        >
          <span className="material-symbols-outlined text-[#95d3ba] text-[20px]">
            check_circle
          </span>
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-white/70 hover:text-white"
          >
            <span className="material-symbols-outlined text-[16px]">close</span>
          </button>
        </div>
      )}

      {/* Sidebar Component */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenNewReport={() => setIsNewReportModalOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenSupport={() => setIsSupportOpen(true)}
        isOpenMobile={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Top Navigation Bar */}
      <TopNavBar
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(true)}
        onOpenNewReport={() => setIsNewReportModalOpen(true)}
        onOpenGlobalMetrics={() => setIsGlobalMetricsOpen(true)}
        onOpenAnnouncements={() => setIsAnnouncementsOpen(true)}
        onOpenRegionalData={() => setIsRegionalDataOpen(true)}
        unreadAnnouncementsCount={announcements.filter((a) => !a.read).length}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Screen Content View */}
      <main
        id="main-app-content-viewport"
        className="flex-1 md:ml-[280px] mt-16 p-4 sm:p-6 lg:p-8 overflow-y-auto"
      >
        {activeTab === 'executive-dashboard' && (
          <ExecutiveDashboardView
            onNavigateToTab={setActiveTab}
            onOpenReportModal={() => setIsNewReportModalOpen(true)}
          />
        )}

        {activeTab === 'carbon-analytics' && (
          <CarbonAnalyticsView onAskCopilot={handleAskCopilot} />
        )}

        {activeTab === 'compliance-tracking' && (
          <ComplianceTrackingView
            items={complianceItems}
            onUploadEvidence={(item) => setUploadEvidenceItem(item)}
            onResolveAction={(item) => setResolveActionItem(item)}
            onViewDetails={(item) => setViewDetailsItem(item)}
            onAddItem={() => setIsAddingComplianceItem(true)}
          />
        )}

        {activeTab === 'sustainability-copilot' && (
          <SustainabilityCopilotView
            initialPrompt={copilotInitialPrompt}
            onClearInitialPrompt={() => setCopilotInitialPrompt(null)}
            onOpenReportModalWithContext={(ctx) => {
              setReportInitialNotes(ctx);
              setActiveTab('ai-report-gen');
            }}
          />
        )}

        {activeTab === 'ai-report-gen' && (
          <AIReportGenView
            initialNotes={reportInitialNotes}
            onNavigateToCopilotWithPrompt={handleAskCopilot}
          />
        )}
      </main>

      {/* Modals & Drawers */}
      <UploadEvidenceModal
        item={uploadEvidenceItem}
        onClose={() => setUploadEvidenceItem(null)}
        onSuccess={handleUploadEvidenceSuccess}
      />

      <ResolveActionModal
        item={resolveActionItem}
        onClose={() => setResolveActionItem(null)}
        onSuccess={handleResolveActionSuccess}
      />

      <ViewComplianceDetailsModal
        item={viewDetailsItem}
        onClose={() => setViewDetailsItem(null)}
        onUploadEvidence={(item) => {
          setViewDetailsItem(null);
          setUploadEvidenceItem(item);
        }}
      />

      {isAddingComplianceItem && (
        <AddComplianceItemModal
          onClose={() => setIsAddingComplianceItem(false)}
          onAdd={handleAddComplianceItem}
        />
      )}

      {isGlobalMetricsOpen && (
        <GlobalMetricsModal onClose={() => setIsGlobalMetricsOpen(false)} />
      )}

      <AnnouncementsDrawer
        isOpen={isAnnouncementsOpen}
        onClose={() => setIsAnnouncementsOpen(false)}
        announcements={announcements}
        onMarkAllRead={handleMarkAllAnnouncementsRead}
        onSelectAnnouncement={handleSelectAnnouncement}
      />

      {isRegionalDataOpen && (
        <RegionalDataModal
          onClose={() => setIsRegionalDataOpen(false)}
          onFilterRegion={(region) => {
            showToast(`Filtered active view for region: ${region}`);
          }}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal onClose={() => setIsSettingsOpen(false)} />
      )}

      {isSupportOpen && (
        <SupportModal onClose={() => setIsSupportOpen(false)} />
      )}

      {isNewReportModalOpen && (
        <GenerateReportModal
          onClose={() => setIsNewReportModalOpen(false)}
          onSubmitAndNavigate={handleNewReportSubmit}
        />
      )}
    </div>
  );
}

export default App;
