export type ActiveTab =
  | 'landing'
  | 'dashboard'
  | 'data-management'
  | 'carbon-analytics'
  | 'ai-copilot'
  | 'compliance'
  | 'settings';

export type EsgPillar = 'environmental' | 'social' | 'governance';

export interface OrganizationInfo {
  name: string;
  subhead: string;
  fiscalYear: string;
  sector: string;
  reportingFrameworks: string[];
  headquarters: string;
  facilitiesCount: number;
}

export interface MetricCardData {
  title: string;
  value: number | string;
  max?: number;
  unit?: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  color: string;
  iconName: string;
  progressPercent?: number;
}

export interface QuickStat {
  label: string;
  value: string;
  unit?: string;
  iconName: string;
}

export interface MonthlyCarbonData {
  month: string;
  emissions: number; // in tCO2e
  lineTrend: number;
  target?: number;
}

export interface SourceEmissions {
  source: string;
  percentage: number;
  amount: number; // in tCO2e
  color: string;
}

export interface EmissionFactor {
  sourceType: string;
  factorApplied: string;
  reference: string;
  category: string;
}

export interface FacilityEmission {
  facility: string;
  amount: number;
  percentage: number;
  color: string;
}

export type ComplianceStatus = 'COMPLETE' | 'PENDING' | 'OVERDUE';

export interface ComplianceItem {
  id: string;
  name: string;
  subtext: string;
  status: ComplianceStatus;
  dueDate: string;
  responsible: {
    name: string;
    initials: string;
    avatarColor?: string;
  };
  framework: string;
  evidenceUrl?: string;
  evidenceNotes?: string;
  lastUpdated?: string;
}

export type RecordStatus = 'VERIFIED' | 'DRAFT' | 'REJECTED';

export interface DataRecord {
  id: string;
  date: string;
  indicator: string;
  category: EsgPillar;
  value: number;
  unit: string;
  facility: string;
  status: RecordStatus;
  sourceDoc?: string;
  confidence?: number;
  verifiedBy?: string;
}

export interface DocumentIntelligenceData {
  isOpen: boolean;
  activeRecordId?: string;
  sourceDocTitle: string;
  previewUrl: string;
  extractedFields: {
    indicator: {
      name: string;
      value: string;
      confidence: number;
      isMatch: boolean;
    };
    value: {
      name: string;
      value: string;
      unit: string;
      confidence: number;
      isMatch: boolean;
    };
    facilityMatch: {
      name: string;
      facilityName: string;
      confidence: number;
      isWarning?: boolean;
    };
  };
  documentDetails: {
    invoiceNo: string;
    billingPeriod: string;
    supplier: string;
    issueDate: string;
  };
}

export interface CopilotInsightCard {
  title: string;
  value: string;
  changeBadge: string;
  changeBadgeType: 'increase-bad' | 'decrease-good' | 'neutral';
  colorBar: string;
  iconType: string;
}

export interface CopilotMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  cards?: CopilotInsightCard[];
  actionLinks?: { label: string; action: string; icon: string }[];
  isStreaming?: boolean;
}

export interface ESGReportConfig {
  title: string;
  framework: 'BRSR' | 'SEC' | 'CSRD' | 'GRI' | 'TCFD' | 'ALL';
  year: string;
  includeScope3: boolean;
  includePeerBenchmarking: boolean;
  includeExecutiveSummary: boolean;
}
