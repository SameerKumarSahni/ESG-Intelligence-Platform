import React, { useState } from 'react';
import {
  Cloud,
  Download,
  ChevronDown,
  Info,
  MoreVertical,
  FlaskConical,
  Building,
  CheckCircle2,
  Filter,
  ExternalLink,
  Layers
} from 'lucide-react';
import {
  monthlyCarbonAnalyticsTrend,
  emissionsBySource,
  calculationEngineTransparency,
  facilityEmissionsList
} from '../data/mockData';

interface CarbonAnalyticsViewProps {
  onExportData: () => void;
}

export const CarbonAnalyticsView: React.FC<CarbonAnalyticsViewProps> = ({
  onExportData
}) => {
  const [selectedYear, setSelectedYear] = useState('YTD 2024');
  const [hoveredMonth, setHoveredMonth] = useState<number | null>(null);
  const [activeSourceFilter, setActiveSourceFilter] = useState<string | null>(null);

  // Maximum emission for chart scaling
  const maxMonthEmission = Math.max(...monthlyCarbonAnalyticsTrend.map((d) => d.emissions));

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header matching Image 5 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            Carbon Analytics
          </h1>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium mt-1">
            <Info className="w-3.5 h-3.5 text-slate-400" />
            <span>Estimated Calculations based on Organization Data</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Export Data Button */}
          <button
            onClick={onExportData}
            className="inline-flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export Data</span>
          </button>

          {/* Timeframe Dropdown */}
          <div className="relative">
            <button className="inline-flex items-center gap-2 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors">
              <span>{selectedYear}</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
            </button>
          </div>
        </div>
      </div>

      {/* Top 3 Metric Cards matching Image 5 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* TOTAL ESTIMATED CO2E */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              TOTAL ESTIMATED CO2E
            </span>
            <div className="p-1 rounded text-slate-300">
              <Cloud className="w-8 h-8 stroke-1 text-slate-300" />
            </div>
          </div>

          <div className="my-2">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-slate-900 tracking-tight">12,450</span>
              <span className="text-sm font-semibold text-slate-500">tCO2e</span>
            </div>
          </div>

          <div>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
              <span className="font-bold">↓</span> 4.2% vs previous period
            </span>
          </div>
        </div>

        {/* SCOPE 1 DIRECT */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              SCOPE 1 DIRECT
            </span>
          </div>

          <div className="my-2">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-slate-900 tracking-tight">4,120</span>
              <span className="text-sm font-semibold text-slate-500">tCO2e</span>
            </div>
          </div>

          {/* Progress bar matching Image 5 */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-[#064e3b] h-full rounded-full" style={{ width: '33%' }}></div>
          </div>
        </div>

        {/* SCOPE 2 INDIRECT */}
        <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              SCOPE 2 INDIRECT
            </span>
          </div>

          <div className="my-2">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-extrabold text-slate-900 tracking-tight">8,330</span>
              <span className="text-sm font-semibold text-slate-500">tCO2e</span>
            </div>
          </div>

          {/* Progress bar matching Image 5 */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-[#1e3a8a] h-full rounded-full" style={{ width: '67%' }}></div>
          </div>
        </div>
      </div>

      {/* Middle Grid: Monthly Carbon Trend (Left) + Emissions by Source (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Monthly Carbon Trend (Bar + Line Combo) */}
        <div className="lg:col-span-8 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Monthly Carbon Trend</h3>
              <p className="text-xs text-slate-400 mt-0.5">Historical footprint & intensity trajectory</p>
            </div>
            <button className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-50">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          {/* Interactive Chart Container */}
          <div className="relative pt-6 pb-2">
            {/* Grid lines background */}
            <div className="absolute inset-x-0 top-6 bottom-8 flex flex-col justify-between pointer-events-none opacity-40">
              <div className="border-b border-slate-200 w-full"></div>
              <div className="border-b border-slate-200 w-full"></div>
              <div className="border-b border-slate-200 w-full"></div>
              <div className="border-b border-slate-200 w-full"></div>
            </div>

            {/* SVG Spline Line Overlay matching Image 5 */}
            <svg 
              className="absolute inset-x-6 top-6 h-56 w-[calc(100%-48px)] pointer-events-none z-10 overflow-visible"
              viewBox="0 0 1000 220"
              preserveAspectRatio="none"
            >
              <polyline
                fill="none"
                stroke="#3b5998"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points="
                  50,140
                  150,110
                  250,125
                  350,70
                  450,90
                  550,20
                  650,75
                  750,105
                  850,120
                  950,100
                "
              />
              {/* Spline node points */}
              {[
                [50, 140],
                [150, 110],
                [250, 125],
                [350, 70],
                [450, 90],
                [550, 20],
                [650, 75],
                [750, 105],
                [850, 120],
                [950, 100],
              ].map(([cx, cy], i) => (
                <circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r="5"
                  fill="#ffffff"
                  stroke="#3b5998"
                  strokeWidth="3"
                />
              ))}
            </svg>

            {/* Bars */}
            <div className="h-64 flex items-end justify-between gap-3 px-4 relative z-0">
              {monthlyCarbonAnalyticsTrend.map((d, i) => {
                const heightPct = Math.round((d.emissions / maxMonthEmission) * 85);
                const isHovered = hoveredMonth === i;

                return (
                  <div
                    key={d.month}
                    className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer relative"
                    onMouseEnter={() => setHoveredMonth(i)}
                    onMouseLeave={() => setHoveredMonth(null)}
                  >
                    {isHovered && (
                      <div className="absolute -top-12 bg-slate-900 text-white text-xs py-1.5 px-3 rounded-lg shadow-xl z-30 whitespace-nowrap animate-in fade-in zoom-in-95">
                        <p className="font-bold">{d.month} 2024</p>
                        <p className="text-slate-300">{d.emissions} tCO2e</p>
                      </div>
                    )}

                    {/* Bar matching Image 5 dark teal/emerald tone */}
                    <div
                      className="w-full bg-[#2f6655] hover:bg-[#235043] rounded-t-sm transition-all duration-200"
                      style={{ height: `${heightPct}%` }}
                    ></div>

                    <span className="text-xs font-semibold text-slate-600 mt-3 group-hover:text-slate-900">
                      {d.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Emissions by Source Donut Chart Card matching Image 5 */}
        <div className="lg:col-span-4 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-base mb-4">Emissions by Source</h3>

          {/* Donut Chart Visualization */}
          <div className="flex flex-col items-center justify-center py-4">
            <div className="relative w-44 h-44 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                {/* Background ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#f1f5f9"
                  strokeWidth="12"
                />
                
                {/* Electricity Segment: 65% -> stroke-dasharray="155 238" */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#1b4d3e"
                  strokeWidth="12"
                  strokeDasharray="155 238"
                  strokeDashoffset="0"
                  className="transition-all hover:stroke-width-14"
                />

                {/* Fuel Segment: 25% -> stroke-dasharray="60 238" offset="155" */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#3b5998"
                  strokeWidth="12"
                  strokeDasharray="60 238"
                  strokeDashoffset="-155"
                  className="transition-all hover:stroke-width-14"
                />

                {/* Waste Segment: 10% -> stroke-dasharray="24 238" offset="215" */}
                <circle
                  cx="50"
                  cy="50"
                  r="38"
                  fill="transparent"
                  stroke="#34d399"
                  strokeWidth="12"
                  strokeDasharray="24 238"
                  strokeDashoffset="-215"
                  className="transition-all hover:stroke-width-14"
                />
              </svg>

              {/* Center Text matching Image 5 */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-2xl font-extrabold text-slate-900 leading-none">3</span>
                <span className="text-xs font-semibold text-slate-500 mt-1">Sources</span>
              </div>
            </div>

            {/* Legend list matching Image 5 */}
            <div className="w-full space-y-3 mt-6 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#1b4d3e]"></span>
                  <span>Electricity</span>
                </div>
                <span className="text-slate-900">65%</span>
              </div>

              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#3b5998]"></span>
                  <span>Fuel</span>
                </div>
                <span className="text-slate-900">25%</span>
              </div>

              <div className="flex items-center justify-between text-xs font-semibold text-slate-700">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#34d399]"></span>
                  <span>Waste</span>
                </div>
                <span className="text-slate-900">10%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Calculation Engine Transparency + Emissions by Facility */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Calculation Engine Transparency Card matching Image 5 */}
        <div className="lg:col-span-7 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <FlaskConical className="w-4 h-4 text-slate-600" />
            <h3 className="font-bold text-slate-900 text-base">
              Calculation Engine Transparency
            </h3>
          </div>
          <p className="text-xs text-slate-500 mb-4">
            Active emission factors applied to current dataset.
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                  <th className="pb-3 pr-4">SOURCE TYPE</th>
                  <th className="pb-3 px-4">FACTOR APPLIED</th>
                  <th className="pb-3 pl-4">REFERENCE</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {calculationEngineTransparency.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 pr-4 font-semibold text-slate-900">
                      {item.sourceType}
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-600">
                      {item.factorApplied}
                    </td>
                    <td className="py-3 pl-4 text-slate-500 flex items-center justify-between">
                      <span>{item.reference}</span>
                      <span className="text-[10px] font-semibold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                        {item.category}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Emissions by Facility matching Image 5 */}
        <div className="lg:col-span-5 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <h3 className="font-bold text-slate-900 text-base mb-4">
            Emissions by Facility
          </h3>

          <div className="space-y-4">
            {facilityEmissionsList.map((facility, idx) => (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-800">
                  <span className="truncate">{facility.facility}</span>
                  <span className="font-mono text-slate-900">
                    {facility.amount.toLocaleString()} tCO2e
                  </span>
                </div>
                
                {/* Horizontal Progress Bar matching Image 5 */}
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${facility.percentage * 2}%`,
                      backgroundColor: facility.color
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
