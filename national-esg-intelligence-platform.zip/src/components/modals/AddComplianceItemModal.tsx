import React, { useState } from 'react';
import { ComplianceItem, PillarType, ComplianceStatus } from '../../types';

interface AddComplianceItemModalProps {
  onClose: () => void;
  onAdd: (item: ComplianceItem) => void;
}

export const AddComplianceItemModal: React.FC<AddComplianceItemModalProps> = ({ onClose, onAdd }) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [pillar, setPillar] = useState<PillarType>('Environmental');
  const [status, setStatus] = useState<ComplianceStatus>('Pending');
  const [deadline, setDeadline] = useState('');
  const [details, setDetails] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) return;

    const newItem: ComplianceItem = {
      id: `comp-${Date.now()}`,
      title,
      subtitle: subtitle || `${pillar} Mandatory Filing`,
      pillar,
      status,
      deadline: deadline || 'Dec 31, 2024',
      actionLabel: status === 'Complete' ? 'Download' : 'Upload Evidence',
      actionType: status === 'Complete' ? 'download' : 'upload',
      icon: pillar === 'Environmental' ? 'eco' : pillar === 'Social' ? 'diversity_3' : 'gavel',
      details,
    };

    onAdd(newItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              Add Compliance Requirement
            </h3>
            <p className="text-[13px] text-[#707974]">
              Register a new mandatory ESG filing, certification, or audit deadline.
            </p>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Requirement / Framework Title
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. EU Taxonomy Article 8 Disclosure"
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Pillar
              </label>
              <select
                value={pillar}
                onChange={(e) => setPillar(e.target.value as PillarType)}
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              >
                <option value="Environmental">Environmental</option>
                <option value="Social">Social</option>
                <option value="Governance">Governance</option>
              </select>
            </div>

            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Initial Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as ComplianceStatus)}
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              >
                <option value="Missing">Missing</option>
                <option value="Pending">Pending</option>
                <option value="Under Review">Under Review</option>
                <option value="Overdue">Overdue</option>
                <option value="Complete">Complete</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Sub-title / Framework
              </label>
              <input
                type="text"
                value={subtitle}
                onChange={(e) => setSubtitle(e.target.value)}
                placeholder="e.g. Green Asset Ratio (GAR)"
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              />
            </div>

            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Deadline Date
              </label>
              <input
                type="text"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                placeholder="e.g. Dec 15, 2024"
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Description &amp; Guidelines
            </label>
            <textarea
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              rows={2}
              placeholder="Enter audit criteria, data collection methods, and verification bodies..."
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-[13px] font-bold bg-[#003527] text-white rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer"
            >
              Add Requirement
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
