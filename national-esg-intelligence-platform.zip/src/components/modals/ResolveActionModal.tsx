import React, { useState } from 'react';
import { ComplianceItem } from '../../types';

interface ResolveActionModalProps {
  item: ComplianceItem | null;
  onClose: () => void;
  onSuccess: (itemId: string, note: string) => void;
}

export const ResolveActionModal: React.FC<ResolveActionModalProps> = ({ item, onClose, onSuccess }) => {
  const [reference, setReference] = useState('');
  const [resolutionNote, setResolutionNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!item) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onSuccess(item.id, resolutionNote || `Settled via Ref #${reference || 'TXN-2024-9981'}`);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#ba1a1a] bg-[#ffdad6] px-2 py-0.5 rounded">
              Urgent Compliance Action
            </span>
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e] mt-1">
              Resolve Statutory Action
            </h3>
            <p className="text-[13px] text-[#707974]">{item.title}</p>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-3.5 bg-[#fef08a]/20 border border-[#fef08a] rounded-xl text-[13px] text-[#854d0e]">
            <p className="font-semibold flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[16px]">info</span>
              Settlement Requirement:
            </p>
            <p className="mt-1 text-[12px]">{item.details}</p>
          </div>

          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Transaction / Filing Reference Number
            </label>
            <input
              type="text"
              required
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="e.g. EUA-ETS-2024-NL-849102"
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Compliance Sign-off Notes
            </label>
            <textarea
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              rows={2}
              placeholder="Surrendered 1,200 European Union Allowances (EUAs) via regional registry."
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 text-[13px] font-bold bg-[#003527] text-white rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer flex items-center gap-1.5"
            >
              {isSubmitting ? (
                <>
                  <span className="material-symbols-outlined text-[16px] animate-spin">progress_activity</span>
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[16px]">check_circle</span>
                  <span>Mark as Resolved</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
