import { ComplianceItem, GlobalMetric, Announcement, GeneratedReport } from '../types';

export const INITIAL_COMPLIANCE_ITEMS: ComplianceItem[] = [
  {
    id: 'comp-1',
    title: 'BRSR Report 2024',
    subtitle: 'Business Responsibility and Sustainability Report',
    status: 'Missing',
    deadline: 'Oct 15, 2024',
    pillar: 'Governance',
    actionLabel: 'Upload Evidence',
    actionType: 'upload',
    icon: 'description',
    details: 'SEBI mandated Business Responsibility and Sustainability Report covering 9 core ESG principles. Missing Section C Principle 6 (Environment) supplier verification.'
  },
  {
    id: 'comp-2',
    title: 'Carbon Tax Payment (Q3)',
    subtitle: 'Regional EU ETS Compliance',
    status: 'Overdue',
    deadline: 'Sep 30, 2024',
    pillar: 'Environmental',
    actionLabel: 'Resolve Action',
    actionType: 'resolve',
    icon: 'payments',
    details: 'Surrender of European Union Allowance (EUA) credits for Rotterdam and Frankfurt distribution centers. Immediate settlement required to prevent 100 EUR/tCO2e fine.'
  },
  {
    id: 'comp-3',
    title: 'Supply Chain Audit (Tier 1)',
    subtitle: 'Supplier Code of Conduct Verification',
    status: 'Pending',
    deadline: 'Nov 01, 2024',
    pillar: 'Social',
    actionLabel: 'Upload Evidence',
    actionType: 'upload',
    icon: 'assignment',
    details: 'Third-party human rights and labor condition audit for Tier-1 component manufacturers across South-East Asia facilities.'
  },
  {
    id: 'comp-4',
    title: 'Diversity & Inclusion Policy Update',
    subtitle: 'Annual HR Policy Review',
    status: 'Under Review',
    deadline: 'Nov 15, 2024',
    pillar: 'Social',
    actionLabel: 'View Details',
    actionType: 'view',
    icon: 'policy',
    details: 'Executive pay equity ratio evaluation, gender parity in senior management benchmarking, and updated parental leave framework.'
  },
  {
    id: 'comp-5',
    title: 'ISO 14001 Certification',
    subtitle: 'Environmental Management Systems',
    status: 'Complete',
    deadline: 'Dec 31, 2024',
    pillar: 'Environmental',
    actionLabel: 'Download',
    actionType: 'download',
    icon: 'workspace_premium',
    details: 'Bureau Veritas certified EMS covering ISO 14001:2015 standards across all 14 corporate manufacturing sites.'
  },
  {
    id: 'comp-6',
    title: 'EU CSRD Double Materiality Assessment',
    subtitle: 'Corporate Sustainability Due Diligence',
    status: 'Pending',
    deadline: 'Dec 15, 2024',
    pillar: 'Governance',
    actionLabel: 'Upload Evidence',
    actionType: 'upload',
    icon: 'balance',
    details: 'Financial and impact materiality scoring across stakeholder groups according to European ESRS standards.'
  },
  {
    id: 'comp-7',
    title: 'Water Withdrawal & Discharge Permits',
    subtitle: 'Municipal Water Safety Compliance',
    status: 'Complete',
    deadline: 'Jan 20, 2025',
    pillar: 'Environmental',
    actionLabel: 'Download',
    actionType: 'download',
    icon: 'water_drop',
    details: 'Zero-liquid discharge (ZLD) plant validation certificates approved by local environmental protection agencies.'
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Q3 2024 Scope 3 Supply Chain Disclosures Finalized',
    date: 'Today, 08:30 AM',
    category: 'Regulatory',
    priority: 'high',
    summary: 'Supplier data integration from 142 vendors has been ingested. Scope 3 emissions stand at 21,500 tCO2e (+3.1% YoY).',
    read: false
  },
  {
    id: 'ann-2',
    title: 'EU ETS Compliance Window Warning',
    date: 'Yesterday, 04:15 PM',
    category: 'Audit',
    priority: 'high',
    summary: 'Action needed for Q3 regional allowances submission to avoid late compliance penalties.',
    read: false
  },
  {
    id: 'ann-3',
    title: 'Renewable Power Purchase Agreement (PPA) Active',
    date: 'Oct 18, 2024',
    category: 'Target',
    priority: 'medium',
    summary: '45MW solar farm contract in Spain commenced generation, projected to cut Scope 2 footprint by 18% in Q4.',
    read: true
  },
  {
    id: 'ann-4',
    title: 'Sustainability Copilot Gemini 2.5 Flash Upgrade',
    date: 'Oct 15, 2024',
    category: 'Platform',
    priority: 'low',
    summary: 'Enhanced multimodal analysis and automated SEC climate disclosure cross-referencing capabilities enabled.',
    read: true
  }
];

export const GLOBAL_METRICS: GlobalMetric[] = [
  {
    id: 'gm-1',
    region: 'North America',
    country: 'United States & Canada',
    esgScore: 88,
    carbonIntensity: 18.4,
    renewableEnergyPercent: 62.5,
    complianceRate: 94,
    trend: 'up'
  },
  {
    id: 'gm-2',
    region: 'Western Europe',
    country: 'Germany, France, UK, Netherlands',
    esgScore: 92,
    carbonIntensity: 12.1,
    renewableEnergyPercent: 81.0,
    complianceRate: 98,
    trend: 'up'
  },
  {
    id: 'gm-3',
    region: 'Asia Pacific',
    country: 'Japan, Singapore, India, Australia',
    esgScore: 79,
    carbonIntensity: 28.6,
    renewableEnergyPercent: 44.2,
    complianceRate: 83,
    trend: 'neutral'
  },
  {
    id: 'gm-4',
    region: 'Latin America',
    country: 'Brazil, Mexico, Chile',
    esgScore: 81,
    carbonIntensity: 21.0,
    renewableEnergyPercent: 58.0,
    complianceRate: 87,
    trend: 'up'
  },
  {
    id: 'gm-5',
    region: 'Middle East & Africa',
    country: 'UAE, South Africa, Saudi Arabia',
    esgScore: 74,
    carbonIntensity: 34.2,
    renewableEnergyPercent: 29.5,
    complianceRate: 76,
    trend: 'down'
  }
];

export const INITIAL_SAMPLE_REPORTS: GeneratedReport[] = [
  {
    id: 'rep-1',
    title: 'BRSR Annual Sustainability & Governance Report 2024',
    framework: 'BRSR',
    fiscalYear: 'FY 2024',
    createdAt: '2024-10-18',
    author: 'AI Sustainability Engine',
    status: 'Ready',
    overallScore: 86,
    scores: {
      environmental: 82,
      social: 89,
      governance: 91
    },
    emissions: {
      total: 42850,
      scope1: 12400,
      scope2: 8950,
      scope3: 21500
    },
    executiveSummary: 'The organization demonstrates strong alignment with SASB and GRI frameworks, recording an overall ESG performance score of 86/100 (Top Quartile). Key progress includes a 5.2% reduction in operational carbon footprint and 74.5% total waste diversion.',
    keyFindings: [
      'Scope 1 direct emissions reduced by 4.8% due to boiler electrification.',
      'Scope 2 indirect emissions increased by 12% in Eastern facilities due to grid intensity variations.',
      'Scope 3 supply chain accounts for 50.1% of overall emissions profile.',
      'Gender diversity in board-level management stands at 42% (above industry benchmark of 34%).'
    ],
    recommendations: [
      'Accelerate Power Purchase Agreements (PPAs) in Eastern region to offset Scope 2 volatility.',
      'Mandate Tier-1 suppliers to report through CDP climate questionnaire by Q1 2025.',
      'Implement closed-loop water recirculation systems in manufacturing units A and C.'
    ],
    fullContentMarkdown: `# National ESG Platform — Executive ESG Intelligence Report (FY 2024)
**Framework**: Business Responsibility and Sustainability Report (BRSR)
**Overall ESG Score**: 86/100 (Top Quartile) | **Status**: Verified

---

## 1. Executive Statement
Our unified ESG reporting program reflects ongoing commitments to decarbonization, circular economy transition, and ethical stakeholder governance. During FY 2024, our composite ESG Index improved by **+2.4%** over baseline, placing the enterprise in the top quartile of peer benchmarks.

### Key Pillars Breakdown
- **Environmental (82/100, Target 85)**: Progress driven by renewable power adoption and -8.4% water intensity reduction.
- **Social (89/100, Target 90)**: Enhanced worker safety ratings with zero lost-time incidents across 6 sites.
- **Governance (91/100, Target 90)**: Robust anti-bribery policies, transparent cybersecurity disclosure, and 100% whistleblower protection.

---

## 2. GHG Emissions Inventory (Greenhouse Gas Protocol)
| Emission Category | Volume (tCO2e) | % of Total | YoY Delta |
| :--- | :--- | :--- | :--- |
| **Scope 1 (Direct Operations)** | 12,400 | 28.9% | -4.8% |
| **Scope 2 (Market-based Power)** | 8,950 | 20.9% | +12.0% |
| **Scope 3 (Value Chain / Supply)** | 21,500 | 50.2% | +3.1% |
| **Total Carbon Footprint** | **42,850** | **100%** | **+4.2%** |

---

## 3. Resource Efficiency & Circularity
- **Total Energy Usage**: 45.8 GWh (Renewable proportion: 58.4%)
- **Water Intensity**: 120 m³/rev (-8.4% vs baseline)
- **Waste Diverted from Landfills**: 74.5% (Target: 80.0% by 2026)`
  }
];
