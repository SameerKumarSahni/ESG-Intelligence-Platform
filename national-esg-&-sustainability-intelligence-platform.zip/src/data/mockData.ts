import {
  OrganizationInfo,
  MetricCardData,
  QuickStat,
  MonthlyCarbonData,
  SourceEmissions,
  EmissionFactor,
  FacilityEmission,
  ComplianceItem,
  DataRecord,
  CopilotMessage
} from '../types/esg';

export const initialOrganization: OrganizationInfo = {
  name: 'GreenTech Manufacturing Pvt. Ltd.',
  subhead: 'Executive Sustainability Dashboard',
  fiscalYear: 'FY 2024',
  sector: 'Heavy Industrial & Electronics Components',
  reportingFrameworks: ['BRSR Core', 'SEC Climate Disclosure', 'CSRD ESRS', 'GRI Standards'],
  headquarters: 'Pune Technology Corridor, India & Chicago Hub, USA',
  facilitiesCount: 4
};

export const initialExecutiveMetrics: MetricCardData[] = [
  {
    title: 'OVERALL ESG SCORE',
    value: 78,
    max: 100,
    change: '+2.4 from last quarter',
    changeType: 'positive',
    color: '#059669', // Emerald
    iconName: 'TrendingUp',
    progressPercent: 78
  },
  {
    title: 'ENVIRONMENTAL',
    value: 82,
    max: 100,
    color: '#10b981', // Green
    iconName: 'Leaf',
    progressPercent: 82
  },
  {
    title: 'SOCIAL',
    value: 74,
    max: 100,
    color: '#3b82f6', // Blue
    iconName: 'Users',
    progressPercent: 74
  },
  {
    title: 'GOVERNANCE',
    value: 79,
    max: 100,
    color: '#8b5cf6', // Purple
    iconName: 'Building2',
    progressPercent: 79
  }
];

export const initialQuickStats: QuickStat[] = [
  {
    label: 'Carbon Emissions',
    value: '4,250',
    unit: 'tCO2e',
    iconName: 'CloudFog'
  },
  {
    label: 'Renewable Energy',
    value: '32%',
    iconName: 'SunMedium'
  },
  {
    label: 'Recycling Rate',
    value: '68%',
    iconName: 'Recycle'
  }
];

export const carbonEmissionsTrend6Months: MonthlyCarbonData[] = [
  { month: 'May', emissions: 720, lineTrend: 710, target: 800 },
  { month: 'Jun', emissions: 860, lineTrend: 840, target: 800 },
  { month: 'Jul', emissions: 980, lineTrend: 950, target: 780 },
  { month: 'Aug', emissions: 1350, lineTrend: 1300, target: 780 },
  { month: 'Sep', emissions: 1580, lineTrend: 1520, target: 750 },
  { month: 'Oct', emissions: 1240, lineTrend: 1210, target: 750 }
];

export const monthlyCarbonAnalyticsTrend: MonthlyCarbonData[] = [
  { month: 'Jan', emissions: 1100, lineTrend: 1050, target: 1200 },
  { month: 'Feb', emissions: 1320, lineTrend: 1280, target: 1200 },
  { month: 'Mar', emissions: 1220, lineTrend: 1190, target: 1150 },
  { month: 'Apr', emissions: 1650, lineTrend: 1620, target: 1150 },
  { month: 'May', emissions: 1480, lineTrend: 1440, target: 1100 },
  { month: 'Jun', emissions: 2150, lineTrend: 2120, target: 1100 },
  { month: 'Jul', emissions: 1720, lineTrend: 1690, target: 1050 },
  { month: 'Aug', emissions: 1490, lineTrend: 1450, target: 1050 },
  { month: 'Sep', emissions: 1380, lineTrend: 1340, target: 1000 },
  { month: 'Oct', emissions: 1540, lineTrend: 1500, target: 1000 }
];

export const emissionsBySource: SourceEmissions[] = [
  { source: 'Electricity', percentage: 65, amount: 8092, color: '#1e3a8a' }, // Deep indigo/blue
  { source: 'Fuel', percentage: 25, amount: 3112, color: '#2563eb' },        // Royal blue
  { source: 'Waste', percentage: 10, amount: 1246, color: '#10b981' }        // Emerald teal
];

export const calculationEngineTransparency: EmissionFactor[] = [
  {
    sourceType: 'Grid Electricity (US)',
    factorApplied: '0.45 kg CO2e/kWh',
    reference: 'EPA eGRID 2023',
    category: 'Scope 2'
  },
  {
    sourceType: 'Natural Gas (Stationary)',
    factorApplied: '2.02 kg CO2e/m³',
    reference: 'GHG Protocol 2023',
    category: 'Scope 1'
  },
  {
    sourceType: 'Diesel Transport (Fleet)',
    factorApplied: '2.68 kg CO2e/L',
    reference: 'DEFRA UK 2024',
    category: 'Scope 1'
  },
  {
    sourceType: 'Landfill Waste Disposal',
    factorApplied: '0.58 kg CO2e/kg',
    reference: 'EPA WARM v15',
    category: 'Scope 3'
  }
];

export const facilityEmissionsList: FacilityEmission[] = [
  { facility: 'Global HQ', amount: 5200, percentage: 41.7, color: '#064e3b' },
  { facility: 'Manufacturing Facility A', amount: 4100, percentage: 32.9, color: '#1e3a8a' },
  { facility: 'Plant B (Assembly South)', amount: 2450, percentage: 19.7, color: '#0d9488' },
  { facility: 'Distribution Hub East', amount: 700, percentage: 5.7, color: '#6366f1' }
];

export const initialComplianceItems: ComplianceItem[] = [
  {
    id: 'req-1',
    name: 'BRSR Section A',
    subtext: 'General Disclosures',
    status: 'COMPLETE',
    dueDate: 'Oct 15, 2024',
    responsible: {
      name: 'Jane Doe',
      initials: 'JD',
      avatarColor: 'bg-blue-600'
    },
    framework: 'BRSR',
    evidenceUrl: 'https://storage.national-portal.esg/audit/brsr-2024-sec-a.pdf',
    evidenceNotes: 'Corporate identity, turnover, market capitalization, and workforce composition fully reconciled with annual audited statements.'
  },
  {
    id: 'req-2',
    name: 'SEC Scope 1 & 2',
    subtext: 'Direct Emissions',
    status: 'COMPLETE',
    dueDate: 'Nov 01, 2024',
    responsible: {
      name: 'Mark Smith',
      initials: 'MS',
      avatarColor: 'bg-emerald-600'
    },
    framework: 'SEC',
    evidenceUrl: 'https://storage.national-portal.esg/audit/sec-scope1-2-verification.pdf',
    evidenceNotes: 'Third-party assurance report delivered by SGS Environmental Services. Scope 1 & 2 GHG footprint verified within +/-1.2% uncertainty bound.'
  },
  {
    id: 'req-3',
    name: 'SEC Scope 3',
    subtext: 'Value Chain Emissions',
    status: 'PENDING',
    dueDate: 'Dec 15, 2024',
    responsible: {
      name: 'Unassigned',
      initials: 'UA',
      avatarColor: 'bg-slate-400'
    },
    framework: 'SEC',
    evidenceNotes: 'Awaiting supplier activity data from top Tier 1 metal and semiconductor vendors. Automated supplier survey launched on portal.'
  },
  {
    id: 'req-4',
    name: 'Water Usage Metrics',
    subtext: 'Facility Level Data',
    status: 'OVERDUE',
    dueDate: 'Sep 30, 2024',
    responsible: {
      name: 'Jane Doe',
      initials: 'JD',
      avatarColor: 'bg-blue-600'
    },
    framework: 'GRI',
    evidenceNotes: 'Plant B (South) sub-meter calibration was delayed during sensor overhaul. Escalated to Facility Engineering Director.'
  },
  {
    id: 'req-5',
    name: 'CSRD Double Materiality',
    subtext: 'Impact & Financial Materiality Assessment',
    status: 'COMPLETE',
    dueDate: 'Oct 30, 2024',
    responsible: {
      name: 'Elena Rostova',
      initials: 'ER',
      avatarColor: 'bg-purple-600'
    },
    framework: 'CSRD',
    evidenceUrl: 'https://storage.national-portal.esg/audit/csrd-materiality-matrix.pdf',
    evidenceNotes: 'Stakeholder engagement rounds across 14 external focus groups concluded. 8 primary material topics indexed to ESRS E1-E5, S1-S4, G1.'
  },
  {
    id: 'req-6',
    name: 'Zero Waste to Landfill Audit',
    subtext: 'Solid Waste Diversion Tracking',
    status: 'PENDING',
    dueDate: 'Nov 28, 2024',
    responsible: {
      name: 'Mark Smith',
      initials: 'MS',
      avatarColor: 'bg-emerald-600'
    },
    framework: 'BRSR',
    evidenceNotes: 'Waste manifest documents uploaded for Q1-Q3. Awaiting final compost certification manifest from municipal partner.'
  }
];

export const initialDataRecords: DataRecord[] = [
  {
    id: 'rec-001',
    date: '2024-03-31',
    indicator: 'Electricity Consumption',
    category: 'environmental',
    value: 142500,
    unit: 'kWh',
    facility: 'Plant A (North)',
    status: 'VERIFIED',
    sourceDoc: 'Apex_Global_Utility_Statement_March2024.pdf',
    confidence: 0.98,
    verifiedBy: 'AI Document Intelligence (Audited by J. Doe)'
  },
  {
    id: 'rec-002',
    date: '2024-03-31',
    indicator: 'Water Usage',
    category: 'environmental',
    value: 8240,
    unit: 'm³',
    facility: 'Plant B (South)',
    status: 'DRAFT',
    sourceDoc: 'South_Water_Utility_Invoice_Q1.pdf',
    confidence: 0.85,
    verifiedBy: 'Pending Engineer Approval'
  },
  {
    id: 'rec-003',
    date: '2024-03-30',
    indicator: 'Natural Gas Consumption',
    category: 'environmental',
    value: 14300,
    unit: 'm³',
    facility: 'Manufacturing Facility A',
    status: 'VERIFIED',
    sourceDoc: 'CityGas_Meter_Readings_Mar2024.pdf',
    confidence: 0.96,
    verifiedBy: 'Automated Smart Meter API'
  },
  {
    id: 'rec-004',
    date: '2024-03-29',
    indicator: 'On-site Solar Generation',
    category: 'environmental',
    value: 45200,
    unit: 'kWh',
    facility: 'Global HQ',
    status: 'VERIFIED',
    sourceDoc: 'SolarEdge_Inverter_Export_Mar.csv',
    confidence: 0.99,
    verifiedBy: 'IoT Smart Inverter Telemetry'
  },
  {
    id: 'rec-005',
    date: '2024-03-28',
    indicator: 'Hazardous Waste Diverted',
    category: 'environmental',
    value: 1820,
    unit: 'kg',
    facility: 'Plant A (North)',
    status: 'VERIFIED',
    sourceDoc: 'EcoRecycle_Manifest_1092.pdf',
    confidence: 0.94,
    verifiedBy: 'Environmental Compliance Officer'
  },
  {
    id: 'rec-006',
    date: '2024-03-25',
    indicator: 'Workforce Safety Training Hours',
    category: 'social',
    value: 3420,
    unit: 'Hours',
    facility: 'Plant A (North)',
    status: 'VERIFIED',
    sourceDoc: 'HR_LMS_Quarterly_Audit_Q1.xlsx',
    confidence: 0.97,
    verifiedBy: 'HR Director'
  },
  {
    id: 'rec-007',
    date: '2024-03-24',
    indicator: 'Gender Diversity in Leadership',
    category: 'social',
    value: 42,
    unit: '%',
    facility: 'Global HQ',
    status: 'VERIFIED',
    sourceDoc: 'Executive_Board_Demographics_2024.pdf',
    confidence: 0.99,
    verifiedBy: 'Nominations & Governance Committee'
  },
  {
    id: 'rec-008',
    date: '2024-03-22',
    indicator: 'Community CSR Investment',
    category: 'social',
    value: 125000,
    unit: 'USD',
    facility: 'Plant B (South)',
    status: 'VERIFIED',
    sourceDoc: 'CSR_Foundation_Disbursement_Mar24.pdf',
    confidence: 0.95,
    verifiedBy: 'Corporate Social Responsibility Lead'
  },
  {
    id: 'rec-009',
    date: '2024-03-18',
    indicator: 'Independent Board Ratio',
    category: 'governance',
    value: 67,
    unit: '%',
    facility: 'Global HQ',
    status: 'VERIFIED',
    sourceDoc: 'SEC_Def14A_Proxy_Statement_2024.pdf',
    confidence: 0.99,
    verifiedBy: 'General Legal Counsel'
  },
  {
    id: 'rec-010',
    date: '2024-03-15',
    indicator: 'Whistleblower Case Resolution Rate',
    category: 'governance',
    value: 100,
    unit: '%',
    facility: 'Global HQ',
    status: 'VERIFIED',
    sourceDoc: 'Ethics_Point_Q1_Resolution_Audit.pdf',
    confidence: 0.98,
    verifiedBy: 'Audit & Ethics Committee'
  }
];

export const initialCopilotConversation: CopilotMessage[] = [
  {
    id: 'msg-1',
    role: 'user',
    content: 'Why did our carbon emissions increase in Q3?',
    timestamp: 'TODAY, 10:42 AM'
  },
  {
    id: 'msg-2',
    role: 'assistant',
    content:
      'Based on your ESG records, the **18% increase** in Q3 was primarily driven by a **22% surge in electricity consumption** at Facility B, coupled with a temporary decrease in solar array efficiency due to scheduled maintenance.',
    timestamp: 'TODAY, 10:42 AM',
    cards: [
      {
        title: 'FACILITY B ELEC.',
        value: '1.4k MWh',
        changeBadge: '↗ +22%',
        changeBadgeType: 'increase-bad',
        colorBar: 'bg-red-500',
        iconType: 'Zap'
      },
      {
        title: 'SOLAR ARRAY EFF.',
        value: '68%',
        changeBadge: '↘ -12%',
        changeBadgeType: 'decrease-good',
        colorBar: 'bg-emerald-600',
        iconType: 'Sun'
      }
    ],
    actionLinks: [
      { label: 'View detailed Q3 report', action: 'view-q3-report', icon: 'BarChart2' },
      { label: 'Check maintenance logs', action: 'view-maintenance-logs', icon: 'Users' }
    ]
  }
];
