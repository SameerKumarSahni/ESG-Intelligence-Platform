import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { ChatMessage } from '../types';

interface SustainabilityCopilotViewProps {
  initialPrompt?: string | null;
  onClearInitialPrompt?: () => void;
  onOpenReportModalWithContext?: (context: string) => void;
}

export const SustainabilityCopilotView: React.FC<SustainabilityCopilotViewProps> = ({
  initialPrompt,
  onClearInitialPrompt,
  onOpenReportModalWithContext,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      role: 'user',
      text: 'Why did our ESG score decrease?',
      timestamp: '10:42 AM',
    },
    {
      id: 'msg-2',
      role: 'assistant',
      text: "I've analyzed the recent data updates. Your overall ESG score decreased by 4% (from 78 to 74) primarily due to changes in the Environmental pillar.",
      timestamp: '10:43 AM',
      dataWidgets: [
        {
          title: 'Scope 2 Emissions',
          metric: '+12%',
          comparison: 'vs last quarter',
          description: 'Increased energy consumption in Eastern region facilities.',
          type: 'emission',
          icon: 'factory',
        },
        {
          title: 'Water Usage',
          metric: '+3.5%',
          comparison: 'vs last quarter',
          description: 'Minor spike in processing plants.',
          type: 'water',
          icon: 'water_drop',
        },
      ],
      recommendations: [
        {
          title: 'Prioritize renewable energy procurement',
          description: 'Shift 15% of Eastern region grid dependency to renewable contracts to offset the Scope 2 increase.',
          icon: 'solar_power',
          highlight: true,
        },
        {
          title: 'Initiate water audit',
          description: 'Conduct a targeted audit at processing plants A and C to identify potential leakage or inefficiencies.',
          icon: 'plumbing',
          highlight: false,
        },
      ],
      quickSuggestions: [
        'Draft a mitigation plan',
        'Show detailed regional breakdown',
        'Compare against EU Taxonomy',
      ],
    },
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [feedbackGiven, setFeedbackGiven] = useState<Record<string, 'up' | 'down'>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Handle external prompts (e.g. from Carbon Analytics "Identify Major Sources")
  useEffect(() => {
    if (initialPrompt) {
      handleSendMessage(initialPrompt);
      if (onClearInitialPrompt) onClearInitialPrompt();
    }
  }, [initialPrompt]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || inputText.trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/copilot/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-4),
        }),
      });

      if (!response.ok) {
        throw new Error('API server returned error');
      }

      const data = await response.json();

      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        text: data.text || 'Analysis complete.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        dataWidgets: data.dataWidgets || [],
        recommendations: data.recommendations || [],
        quickSuggestions: data.quickSuggestions || ['Draft a mitigation plan', 'Show detailed regional breakdown'],
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Copilot send error:', err);
      // Fallback assistant reply
      const fallbackMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        text: `Based on your request "${query}", our ESG telemetry suggests steady progress towards FY 2024 decarbonization goals. Consider focusing on Scope 2 energy efficiency and completing overdue statutory filings.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        dataWidgets: [
          {
            title: 'Scope 2 Mitigation',
            metric: '-15%',
            comparison: 'projected impact',
            description: 'Potential reduction through 15MW solar PPA contract.',
            type: 'emission',
            icon: 'solar_power',
          },
        ],
        recommendations: [
          {
            title: 'Review action items in Compliance Tracking',
            description: 'Address missing SEBI and EU ETS filings.',
            icon: 'fact_check',
            highlight: true,
          },
        ],
        quickSuggestions: ['Draft a mitigation plan', 'Show detailed regional breakdown'],
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyText = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetChat = () => {
    if (confirm('Start a fresh conversation with Sustainability Copilot?')) {
      setMessages([
        {
          id: `asst-${Date.now()}`,
          role: 'assistant',
          text: 'Hello! I am your AI Sustainability Copilot. I have access to your live ESG telemetry, Scope 1-3 carbon records, and regulatory filings (BRSR, GRI, CSRD, SEC). How can I assist your sustainability team today?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          quickSuggestions: [
            'Why did our ESG score decrease?',
            'Draft a decarbonization mitigation plan',
            'Summarize Scope 3 emissions drivers',
            'Check BRSR 2024 compliance status',
          ],
        },
      ]);
    }
  };

  return (
    <div id="sustainability-copilot-container" className="max-w-[1200px] mx-auto flex flex-col h-[calc(100vh-100px)] min-h-[600px] pb-4">
      {/* Copilot Header */}
      <div className="flex items-center justify-between pb-4 border-b border-[#bfc9c3]/30 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#003527] text-[#95d3ba] flex items-center justify-center shadow-md">
            <span className="material-symbols-outlined text-[24px]">smart_toy</span>
          </div>
          <div>
            <h2 className="font-['Montserrat',sans-serif] text-[22px] font-bold text-[#191c1e] flex items-center gap-2">
              Sustainability Copilot
              <span className="text-[11px] font-semibold bg-[#064e3b]/10 text-[#003527] px-2 py-0.5 rounded-full border border-[#064e3b]/20">
                Gemini 2.5 Flash
              </span>
            </h2>
            <p className="text-[12.5px] text-[#707974]">
              Real-time AI ESG &amp; decarbonization intelligence powered by multimodal Gemini.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="copilot-reset-btn"
            onClick={handleResetChat}
            className="p-2 text-[#707974] hover:text-[#003527] hover:bg-[#eceef0] rounded-lg transition-colors cursor-pointer"
            title="Reset Conversation"
          >
            <span className="material-symbols-outlined text-[20px]">restart_alt</span>
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div id="copilot-messages-scroll-area" className="flex-1 overflow-y-auto py-6 space-y-6 pr-2">
        {messages.map((msg) => (
          <div key={msg.id} id={`chat-msg-${msg.id}`} className="space-y-3">
            {msg.role === 'user' ? (
              /* User Message Card */
              <div className="flex justify-end gap-3">
                <div className="max-w-xl bg-white border border-[#bfc9c3]/35 rounded-2xl rounded-tr-xs p-4 shadow-xs">
                  <div className="flex justify-between items-center gap-4 mb-1 text-[11px] text-[#707974]">
                    <span className="font-semibold text-[#191c1e]">You</span>
                    <span>{msg.timestamp}</span>
                  </div>
                  <p className="text-[14.5px] text-[#191c1e] leading-relaxed font-medium">{msg.text}</p>
                </div>
                <div className="w-8 h-8 rounded-full border border-[#bfc9c3] overflow-hidden shrink-0">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuAp_aXWt17CdKnhknxLJEvTKwRhoKg_n3a4JKk7yFYjDYwe65WBWL_-2yVgNm-uM0QvEFxu8SsQXB1ZOtjbsFdO__GOGPgE3ZHlR0uPiyZoi3k2E7vm5oGncG8P2UceMAIADiRf8R0FKC_eyz5uVrTZt7N4-kndBXjMAJ6C4-5cjIm7kWscVH-7Ll4OKRbOkGOxNy4HI7iJ2SiTJAp--ap2e_1OYpuVebCQ9BagwBNji5Ikr2JX_4-I3g"
                    alt="User Avatar"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            ) : (
              /* Assistant Message Card */
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#003527] text-[#95d3ba] flex items-center justify-center shrink-0 shadow-xs mt-1">
                  <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
                </div>
                <div className="flex-1 max-w-3xl space-y-4">
                  {/* Narrative Text */}
                  <div className="bg-white border border-[#bfc9c3]/35 rounded-2xl rounded-tl-xs p-5 shadow-xs">
                    <div className="flex justify-between items-center mb-2 text-[11px] text-[#707974]">
                      <span className="font-bold text-[#003527] flex items-center gap-1">
                        Sustainability Copilot
                      </span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <div className="text-[14.5px] text-[#191c1e] leading-relaxed markdown-content">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                    </div>

                    {/* Data Widgets (Bento Cards in response) */}
                    {msg.dataWidgets && msg.dataWidgets.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-5">
                        {msg.dataWidgets.map((widget, widx) => (
                          <div
                            key={widx}
                            className="bg-[#f2f4f6] rounded-xl p-4 border border-[#bfc9c3]/30 flex flex-col justify-between"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <span className="text-[13px] font-semibold text-[#404944]">
                                {widget.title}
                              </span>
                              <span className="material-symbols-outlined text-[#707974] text-[18px]">
                                {widget.icon || 'monitoring'}
                              </span>
                            </div>
                            <div className="flex items-baseline gap-2 mb-1">
                              <span className="font-['Montserrat',sans-serif] text-[24px] font-bold text-[#ba1a1a]">
                                {widget.metric}
                              </span>
                              <span className="text-[12px] text-[#707974] font-medium">
                                {widget.comparison}
                              </span>
                            </div>
                            <p className="text-[12px] text-[#404944] mt-1 leading-snug">
                              {widget.description}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Actionable Recommendations */}
                    {msg.recommendations && msg.recommendations.length > 0 && (
                      <div className="mt-5 space-y-3">
                        <p className="text-[13px] font-bold text-[#191c1e] uppercase tracking-wider">
                          Actionable Recommendations:
                        </p>
                        <div className="space-y-2.5">
                          {msg.recommendations.map((rec, ridx) => (
                            <div
                              key={ridx}
                              className={`p-3.5 rounded-xl border flex items-start gap-3 transition-all ${
                                rec.highlight
                                  ? 'bg-[#003527]/5 border-[#003527]/30 text-[#003527]'
                                  : 'bg-[#f7f9fb] border-[#bfc9c3]/30 text-[#191c1e]'
                              }`}
                            >
                              <div
                                className={`p-2 rounded-lg shrink-0 ${
                                  rec.highlight ? 'bg-[#003527] text-white' : 'bg-[#e6e8ea] text-[#404944]'
                                }`}
                              >
                                <span className="material-symbols-outlined text-[18px]">
                                  {rec.icon || 'lightbulb'}
                                </span>
                              </div>
                              <div>
                                <h5 className="font-semibold text-[13.5px] leading-snug">
                                  {rec.title}
                                </h5>
                                <p className="text-[12px] text-[#404944] mt-1 leading-relaxed">
                                  {rec.description}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Action Buttons Toolbar */}
                    <div className="flex items-center justify-between pt-4 mt-4 border-t border-[#eceef0] text-[#707974]">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleCopyText(msg.id, msg.text)}
                          className="p-1.5 hover:text-[#191c1e] hover:bg-[#eceef0] rounded-md transition-colors text-[12px] flex items-center gap-1 cursor-pointer"
                          title="Copy response"
                        >
                          <span className="material-symbols-outlined text-[16px]">
                            {copiedId === msg.id ? 'check' : 'content_copy'}
                          </span>
                          <span>{copiedId === msg.id ? 'Copied' : 'Copy'}</span>
                        </button>
                        {onOpenReportModalWithContext && (
                          <button
                            onClick={() => onOpenReportModalWithContext(msg.text)}
                            className="p-1.5 hover:text-[#003527] hover:bg-[#003527]/10 rounded-md transition-colors text-[12px] flex items-center gap-1 cursor-pointer"
                            title="Insert into ESG Report Generator"
                          >
                            <span className="material-symbols-outlined text-[16px]">file_download</span>
                            <span>Export to Report</span>
                          </button>
                        )}
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setFeedbackGiven((prev) => ({ ...prev, [msg.id]: 'up' }))}
                          className={`p-1.5 rounded-md hover:bg-[#eceef0] transition-colors cursor-pointer ${
                            feedbackGiven[msg.id] === 'up' ? 'text-[#003527]' : 'hover:text-[#191c1e]'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[16px]">thumb_up</span>
                        </button>
                        <button
                          onClick={() => setFeedbackGiven((prev) => ({ ...prev, [msg.id]: 'down' }))}
                          className={`p-1.5 rounded-md hover:bg-[#eceef0] transition-colors cursor-pointer ${
                            feedbackGiven[msg.id] === 'down' ? 'text-[#ba1a1a]' : 'hover:text-[#191c1e]'
                          }`}
                        >
                          <span className="material-symbols-outlined text-[16px]">thumb_down</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Follow-up Quick Suggestion Chips */}
                  {msg.quickSuggestions && msg.quickSuggestions.length > 0 && (
                    <div className="flex flex-wrap gap-2 pl-2">
                      {msg.quickSuggestions.map((sugg, sidx) => (
                        <button
                          key={sidx}
                          id={`quick-sugg-${sidx}`}
                          onClick={() => handleSendMessage(sugg)}
                          className="px-3 py-1.5 bg-white border border-[#bfc9c3]/50 text-[#003527] text-[12.5px] font-semibold rounded-full hover:bg-[#003527] hover:text-white transition-all shadow-2xs cursor-pointer flex items-center gap-1.5 active:scale-98"
                        >
                          <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                          <span>{sugg}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#003527] text-[#95d3ba] flex items-center justify-center shrink-0 animate-pulse">
              <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
            </div>
            <div className="bg-white border border-[#bfc9c3]/35 rounded-2xl rounded-tl-xs p-4 shadow-xs flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#003527] animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#003527] animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#003527] animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-[13px] text-[#707974] font-medium">
                Analyzing ESG emissions telemetry &amp; generating insights...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Bottom Floating Input Bar */}
      <div className="pt-2 shrink-0">
        <form
          id="copilot-input-form"
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="relative bg-white border border-[#bfc9c3] rounded-2xl shadow-md p-2 flex items-center gap-2 focus-within:border-[#003527] focus-within:ring-2 focus-within:ring-[#003527]/10 transition-all"
        >
          <button
            type="button"
            onClick={() => alert('Attachment: Upload CSV telemetry or PDF audit document for instant multimodal analysis.')}
            className="p-2 text-[#707974] hover:text-[#003527] hover:bg-[#eceef0] rounded-xl transition-colors cursor-pointer"
            title="Attach file (CSV, PDF, Excel)"
          >
            <span className="material-symbols-outlined text-[22px]">attach_file</span>
          </button>

          <input
            id="copilot-input-field"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask Sustainability Copilot anything about your carbon, compliance, or ESG metrics..."
            disabled={isLoading}
            className="flex-1 bg-transparent border-none text-[14px] text-[#191c1e] placeholder:text-[#707974] focus:outline-none px-2"
          />

          <button
            type="button"
            onClick={() => alert('Voice input: Audio streaming enabled for hands-free sustainability briefings.')}
            className="p-2 text-[#707974] hover:text-[#003527] hover:bg-[#eceef0] rounded-xl transition-colors cursor-pointer hidden sm:flex"
            title="Voice input"
          >
            <span className="material-symbols-outlined text-[22px]">mic</span>
          </button>

          <button
            id="copilot-send-btn"
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className="p-2.5 bg-[#003527] text-white rounded-xl hover:bg-[#064e3b] disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-xs cursor-pointer active:scale-95 flex items-center justify-center"
          >
            <span className="material-symbols-outlined text-[20px]">send</span>
          </button>
        </form>
        <p className="text-center text-[11px] text-[#707974] mt-2">
          Sustainability Copilot is grounded in GHG Protocol, SASB, and SEBI BRSR standards.
        </p>
      </div>
    </div>
  );
};
