import React from 'react';
import { GLOBAL_METRICS } from '../../data/esgData';

interface GlobalMetricsModalProps {
  onClose: () => void;
}

export const GlobalMetricsModal: React.FC<GlobalMetricsModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[26px]">public</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[22px] font-bold text-[#191c1e]">
                Global ESG Performance Matrix
              </h3>
              <p className="text-[13px] text-[#707974]">
                Comparative benchmarks across all multinational manufacturing and operational regions.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[22px]">close</span>
          </button>
        </div>

        {/* Matrix Table */}
        <div className="overflow-x-auto border border-[#bfc9c3]/40 rounded-xl">
          <table className="w-full text-left border-collapse min-w-[650px]">
            <thead className="bg-[#f2f4f6] text-[11.5px] font-bold uppercase tracking-wider text-[#707974]">
              <tr>
                <th className="p-3.5 pl-5">Region</th>
                <th className="p-3.5">Key Operations</th>
                <th className="p-3.5">ESG Score</th>
                <th className="p-3.5">Carbon Intensity</th>
                <th className="p-3.5">Renewable %</th>
                <th className="p-3.5 pr-5">Compliance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#bfc9c3]/20 text-[13px]">
              {GLOBAL_METRICS.map((gm) => (
                <tr key={gm.id} className="hover:bg-[#f7f9fb] transition-colors">
                  <td className="p-3.5 pl-5 font-bold text-[#191c1e]">{gm.region}</td>
                  <td className="p-3.5 text-[#404944]">{gm.country}</td>
                  <td className="p-3.5">
                    <span className="font-bold text-[#003527] bg-[#003527]/10 px-2.5 py-1 rounded-md">
                      {gm.esgScore} / 100
                    </span>
                  </td>
                  <td className="p-3.5 font-mono text-[#191c1e]">{gm.carbonIntensity} tCO2e/$M</td>
                  <td className="p-3.5 font-semibold text-[#004d46]">{gm.renewableEnergyPercent}%</td>
                  <td className="p-3.5 pr-5">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-[#e6e8ea] h-2 rounded-full overflow-hidden">
                        <div className="bg-[#003527] h-full rounded-full" style={{ width: `${gm.complianceRate}%` }} />
                      </div>
                      <span className="text-[12px] font-bold text-[#191c1e]">{gm.complianceRate}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex justify-between items-center pt-2">
          <span className="text-[12px] text-[#707974]">
            Data normalized against MSCI ESG and CDP benchmark indicators.
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#003527] text-white font-bold text-[13px] rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer"
          >
            Close Matrix
          </button>
        </div>
      </div>
    </div>
  );
};
