import React, { useState, useMemo } from 'react';
import { ComplianceItem, PillarType, ComplianceStatus } from '../types';

interface ComplianceTrackingViewProps {
  items: ComplianceItem[];
  onUploadEvidence: (item: ComplianceItem) => void;
  onResolveAction: (item: ComplianceItem) => void;
  onViewDetails: (item: ComplianceItem) => void;
  onAddItem: () => void;
}

export const ComplianceTrackingView: React.FC<ComplianceTrackingViewProps> = ({
  items,
  onUploadEvidence,
  onResolveAction,
  onViewDetails,
  onAddItem,
}) => {
  const [activePillarTab, setActivePillarTab] = useState<'All Items' | PillarType>('All Items');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Filter items based on tab, status, and search
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchPillar = activePillarTab === 'All Items' || item.pillar === activePillarTab;
      const matchStatus = statusFilter === 'all' || item.status.toLowerCase() === statusFilter.toLowerCase();
      const matchSearch =
        item.title.toLowerCase().includes(searchFilter.toLowerCase()) ||
        item.subtitle.toLowerCase().includes(searchFilter.toLowerCase()) ||
        item.pillar.toLowerCase().includes(searchFilter.toLowerCase());
      return matchPillar && matchStatus && matchSearch;
    });
  }, [items, activePillarTab, statusFilter, searchFilter]);

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage) || 1;
  const paginatedItems = filteredItems.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Compute stat totals
  const missingOverdueCount = items.filter((i) => i.status === 'Missing' || i.status === 'Overdue').length;
  const pendingCount = items.filter((i) => i.status === 'Pending' || i.status === 'Under Review').length;

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      ['ID,Title,Subtitle,Status,Deadline,Pillar', ...items.map((i) => `"${i.id}","${i.title}","${i.subtitle}","${i.status}","${i.deadline}","${i.pillar}"`)].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ESG_Compliance_Frameworks_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getStatusBadge = (status: ComplianceStatus) => {
    switch (status) {
      case 'Missing':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#ffdad6] text-[#ba1a1a] border border-[#ba1a1a]/20">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a]" />
            Missing
          </span>
        );
      case 'Overdue':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-bold bg-[#7f1d1d]/15 text-[#7f1d1d] border border-[#7f1d1d]/30">
            <span className="material-symbols-outlined text-[13px]">warning</span>
            Overdue
          </span>
        );
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#fef08a] text-[#854d0e] border border-[#fef08a]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#854d0e] animate-pulse" />
            Pending
          </span>
        );
      case 'Under Review':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#8fa7fe]/30 text-[#1d3989] border border-[#8fa7fe]/50">
            <span className="material-symbols-outlined text-[13px]">visibility</span>
            Under Review
          </span>
        );
      case 'Complete':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[12px] font-semibold bg-[#064e3b]/15 text-[#003527] border border-[#064e3b]/30">
            <span className="material-symbols-outlined text-[14px]">check_circle</span>
            Complete
          </span>
        );
    }
  };

  return (
    <div id="compliance-tracking-container" className="max-w-[1440px] mx-auto space-y-8 pb-20">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="font-['Montserrat',sans-serif] text-[32px] sm:text-[40px] font-bold text-[#191c1e] tracking-tight leading-tight">
            Compliance Tracking
          </h2>
          <p className="text-[15px] sm:text-[16.5px] text-[#404944] mt-2 max-w-2xl">
            Monitor and manage mandatory ESG reporting frameworks, certifications, and regulatory submissions across all operating regions.
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <button
            id="compliance-add-item-btn"
            onClick={onAddItem}
            className="px-4 py-2 bg-white border border-[#bfc9c3] text-[#003527] font-semibold text-[13px] rounded-lg hover:bg-[#f2f4f6] transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
          >
            <span className="material-symbols-outlined text-[18px]">add_circle</span>
            Add Requirement
          </button>
          <button
            id="compliance-export-btn"
            onClick={handleExportCSV}
            className="px-4 py-2 border border-[#003527] text-[#003527] font-semibold text-[13px] rounded-lg hover:bg-[#003527]/5 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">download</span>
            Export
          </button>
          <button
            id="compliance-filter-btn"
            onClick={() => setStatusFilter(statusFilter === 'all' ? 'missing' : 'all')}
            className={`px-4 py-2 font-semibold text-[13px] rounded-lg transition-colors flex items-center gap-2 shadow-xs cursor-pointer ${
              statusFilter !== 'all'
                ? 'bg-[#ba1a1a] text-white'
                : 'bg-[#003527] text-white hover:bg-[#064e3b]'
            }`}
          >
            <span className="material-symbols-outlined text-[18px]">filter_list</span>
            {statusFilter !== 'all' ? 'Filtered (Urgent)' : 'Filters'}
          </button>
        </div>
      </div>

      {/* Bento Grid Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Overall Readiness Card */}
        <div
          id="compliance-readiness-card"
          className="md:col-span-2 bg-white/80 backdrop-blur-md border border-[#bfc9c3]/35 rounded-xl p-6 relative overflow-hidden flex flex-col justify-between shadow-[0px_4px_12px_rgba(0,0,0,0.03)]"
        >
          <div className="relative z-10 flex justify-between items-start mb-6">
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e] flex items-center gap-2">
                <span className="material-symbols-outlined text-[#003527]">donut_large</span>
                Overall Readiness
              </h3>
              <p className="text-[13px] text-[#707974] mt-1 font-medium">Q3 2024 Regulatory Cycle</p>
            </div>
            <div className="bg-[#064e3b] text-[#80bea6] font-['Montserrat',sans-serif] text-[24px] font-bold px-4 py-1.5 rounded-lg shadow-inner">
              78%
            </div>
          </div>

          <div className="relative z-10 space-y-2">
            <div className="flex justify-between text-[12.5px] font-semibold">
              <span className="text-[#404944]">Progress to Goal (100%)</span>
              <span className="text-[#003527] font-bold">22% remaining</span>
            </div>
            <div className="h-3.5 w-full bg-[#e0e3e5] rounded-full overflow-hidden relative">
              <div
                className="h-full bg-[#003527] rounded-full relative transition-all duration-1000"
                style={{ width: '78%' }}
              >
                <div className="absolute inset-0 bg-white/20 w-full animate-shimmer" />
              </div>
            </div>
          </div>

          {/* Decorative watermark */}
          <div className="absolute -right-8 -bottom-8 opacity-5 pointer-events-none">
            <span className="material-symbols-outlined text-[160px]">public</span>
          </div>
        </div>

        {/* Status Summary 1: Missing / Overdue */}
        <div
          id="compliance-overdue-summary-card"
          onClick={() => setStatusFilter(statusFilter === 'overdue' ? 'all' : 'overdue')}
          className="bg-white/80 backdrop-blur-md border border-[#bfc9c3]/35 rounded-xl p-6 flex flex-col justify-center border-l-4 border-l-[#ba1a1a] shadow-[0px_4px_12px_rgba(0,0,0,0.03)] cursor-pointer hover:shadow-md transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-full bg-[#ffdad6]/60 flex items-center justify-center text-[#ba1a1a]">
              <span className="material-symbols-outlined text-[20px]">warning</span>
            </div>
            <span className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#ba1a1a]">
              {missingOverdueCount}
            </span>
          </div>
          <p className="text-[12px] font-bold text-[#404944] uppercase tracking-wider">
            Missing / Overdue
          </p>
          <p className="text-[13px] text-[#707974] mt-0.5">Requires immediate action</p>
        </div>

        {/* Status Summary 2: Pending Tasks */}
        <div
          id="compliance-pending-summary-card"
          onClick={() => setStatusFilter(statusFilter === 'pending' ? 'all' : 'pending')}
          className="bg-white/80 backdrop-blur-md border border-[#bfc9c3]/35 rounded-xl p-6 flex flex-col justify-center border-l-4 border-l-[#eab308] shadow-[0px_4px_12px_rgba(0,0,0,0.03)] cursor-pointer hover:shadow-md transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 rounded-full bg-[#fef08a]/60 flex items-center justify-center text-[#854d0e]">
              <span className="material-symbols-outlined text-[20px]">hourglass_empty</span>
            </div>
            <span className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#191c1e]">
              {pendingCount}
            </span>
          </div>
          <p className="text-[12px] font-bold text-[#404944] uppercase tracking-wider">
            Pending Tasks
          </p>
          <p className="text-[13px] text-[#707974] mt-0.5">In progress or awaiting review</p>
        </div>
      </div>

      {/* Main Compliance Table Area */}
      <div
        id="compliance-table-card"
        className="bg-white border border-[#bfc9c3]/35 rounded-xl overflow-hidden shadow-sm"
      >
        {/* Table Toolbar Header */}
        <div className="p-5 border-b border-[#bfc9c3]/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white">
          <div>
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              Action Items &amp; Deadlines
            </h3>
            <p className="text-[12.5px] text-[#707974]">
              Mandatory disclosures, statutory payments, and verified certifications
            </p>
          </div>

          {/* Inline Tabs */}
          <div className="flex p-1 bg-[#f2f4f6] rounded-lg border border-[#bfc9c3]/20">
            {(['All Items', 'Environmental', 'Social', 'Governance'] as const).map((tab) => (
              <button
                key={tab}
                id={`compliance-tab-${tab.toLowerCase().replace(/\s+/g, '-')}`}
                onClick={() => {
                  setActivePillarTab(tab);
                  setCurrentPage(1);
                }}
                className={`px-3.5 py-1.5 rounded-md text-[12.5px] font-semibold transition-all cursor-pointer ${
                  activePillarTab === tab
                    ? 'bg-white text-[#191c1e] shadow-xs'
                    : 'text-[#707974] hover:text-[#191c1e]'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto w-full">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-[#f2f4f6]/60 border-b border-[#bfc9c3]/30 text-[#707974] text-[11.5px] font-bold uppercase tracking-wider">
                <th className="p-4 pl-6 w-1/3">Requirement / Framework</th>
                <th className="p-4">Status</th>
                <th className="p-4">Deadline</th>
                <th className="p-4">Pillar</th>
                <th className="p-4 pr-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#bfc9c3]/20 text-[13.5px]">
              {paginatedItems.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-[#707974]">
                    No compliance items match the selected filter.
                  </td>
                </tr>
              ) : (
                paginatedItems.map((item) => {
                  const isOverdue = item.status === 'Overdue';
                  const isMissing = item.status === 'Missing';

                  return (
                    <tr
                      key={item.id}
                      id={`compliance-row-${item.id}`}
                      className={`hover:bg-[#f7f9fb] transition-colors group ${
                        isOverdue ? 'bg-[#ba1a1a]/5' : ''
                      }`}
                    >
                      {/* Title & Subtitle */}
                      <td className="p-4 pl-6">
                        <div className="flex items-start gap-3">
                          <span
                            className={`material-symbols-outlined mt-0.5 text-[21px] ${
                              item.status === 'Complete' ? 'text-[#003527]' : 'text-[#707974]'
                            }`}
                          >
                            {item.icon}
                          </span>
                          <div>
                            <p className="font-semibold text-[#191c1e] text-[14.5px] leading-snug">
                              {item.title}
                            </p>
                            <p className="text-[#707974] text-[12px] mt-0.5">{item.subtitle}</p>
                          </div>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="p-4">{getStatusBadge(item.status)}</td>

                      {/* Deadline */}
                      <td className="p-4">
                        <span
                          className={`font-mono text-[13px] font-semibold flex items-center gap-1.5 ${
                            isMissing || isOverdue ? 'text-[#ba1a1a]' : 'text-[#191c1e]'
                          }`}
                        >
                          {(isMissing || isOverdue) && (
                            <span className="material-symbols-outlined text-[16px]">
                              event_busy
                            </span>
                          )}
                          {item.deadline}
                        </span>
                      </td>

                      {/* Pillar */}
                      <td className="p-4 text-[#404944] font-medium">{item.pillar}</td>

                      {/* Action Button */}
                      <td className="p-4 pr-6 text-right">
                        {item.actionType === 'upload' && (
                          <button
                            id={`action-upload-${item.id}`}
                            onClick={() => onUploadEvidence(item)}
                            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 text-[12px] font-semibold bg-[#003527] text-white rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer shadow-xs active:scale-98"
                          >
                            <span className="material-symbols-outlined text-[14px]">upload</span>
                            {item.actionLabel || 'Upload Evidence'}
                          </button>
                        )}

                        {item.actionType === 'resolve' && (
                          <button
                            id={`action-resolve-${item.id}`}
                            onClick={() => onResolveAction(item)}
                            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 text-[12px] font-semibold border border-[#707974] text-[#191c1e] rounded-lg hover:bg-[#f2f4f6] transition-colors cursor-pointer active:scale-98"
                          >
                            {item.actionLabel || 'Resolve Action'}
                          </button>
                        )}

                        {item.actionType === 'view' && (
                          <button
                            id={`action-view-${item.id}`}
                            onClick={() => onViewDetails(item)}
                            className="inline-flex items-center justify-center gap-1 px-3 py-1.5 text-[12px] font-semibold text-[#003527] hover:bg-[#003527]/10 rounded-lg transition-colors cursor-pointer"
                          >
                            View Details
                            <span className="material-symbols-outlined text-[16px]">
                              chevron_right
                            </span>
                          </button>
                        )}

                        {item.actionType === 'download' && (
                          <button
                            id={`action-download-${item.id}`}
                            onClick={() => {
                              alert(`Downloading verified compliance certificate: ${item.title} (PDF)`);
                            }}
                            className="inline-flex items-center justify-center p-2 text-[#003527] hover:bg-[#003527]/10 rounded-lg transition-colors cursor-pointer"
                            title="Download Certificate"
                          >
                            <span className="material-symbols-outlined text-[20px]">download</span>
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer & Pagination */}
        <div className="p-4 border-t border-[#bfc9c3]/30 flex justify-between items-center bg-white">
          <span className="text-[13px] text-[#707974]">
            Showing {(currentPage - 1) * itemsPerPage + 1} to{' '}
            {Math.min(currentPage * itemsPerPage, filteredItems.length)} of {filteredItems.length} items
          </span>
          <div className="flex gap-2">
            <button
              id="compliance-page-prev"
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="w-8 h-8 rounded border border-[#bfc9c3] flex items-center justify-center text-[#707974] hover:bg-[#f2f4f6] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">chevron_left</span>
            </button>
            <span className="flex items-center px-2 text-[13px] font-semibold text-[#191c1e]">
              Page {currentPage} of {totalPages}
            </span>
            <button
              id="compliance-page-next"
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="w-8 h-8 rounded border border-[#bfc9c3] flex items-center justify-center text-[#191c1e] hover:bg-[#f2f4f6] disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
            >
              <span className="material-symbols-outlined text-[18px]">chevron_right</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
