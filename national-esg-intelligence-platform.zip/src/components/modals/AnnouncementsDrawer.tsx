import React from 'react';
import { Announcement } from '../../types';

interface AnnouncementsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  announcements: Announcement[];
  onMarkAllRead: () => void;
  onSelectAnnouncement: (id: string) => void;
}

export const AnnouncementsDrawer: React.FC<AnnouncementsDrawerProps> = ({
  isOpen,
  onClose,
  announcements,
  onMarkAllRead,
  onSelectAnnouncement,
}) => {
  if (!isOpen) return null;

  return (
    <>
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/40 backdrop-blur-2xs z-50 transition-opacity"
      />
      <div className="fixed right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-5 border-b border-[#bfc9c3]/40 flex justify-between items-center bg-[#f7f9fb]">
          <div className="flex items-center gap-2.5">
            <span className="material-symbols-outlined text-[#003527] text-[22px]">
              notifications_active
            </span>
            <h3 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-[#191c1e]">
              Regulatory Alerts &amp; Updates
            </h3>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Action Toolbar */}
        <div className="px-5 py-2.5 bg-white border-b border-[#eceef0] flex justify-between items-center text-[12px]">
          <span className="text-[#707974]">
            {announcements.filter((a) => !a.read).length} unread updates
          </span>
          <button
            onClick={onMarkAllRead}
            className="text-[#003527] font-semibold hover:underline cursor-pointer"
          >
            Mark all as read
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {announcements.map((ann) => (
            <div
              key={ann.id}
              onClick={() => onSelectAnnouncement(ann.id)}
              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                ann.read
                  ? 'bg-white border-[#bfc9c3]/30 hover:bg-[#f7f9fb]'
                  : 'bg-[#003527]/5 border-[#003527]/30 shadow-xs'
              }`}
            >
              <div className="flex justify-between items-start mb-1">
                <span
                  className={`text-[10.5px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    ann.category === 'Regulatory'
                      ? 'bg-[#ba1a1a]/10 text-[#ba1a1a]'
                      : ann.category === 'Audit'
                      ? 'bg-[#854d0e]/15 text-[#854d0e]'
                      : 'bg-[#003527]/10 text-[#003527]'
                  }`}
                >
                  {ann.category}
                </span>
                <span className="text-[11px] text-[#707974]">{ann.date}</span>
              </div>
              <h4 className="font-bold text-[14px] text-[#191c1e] leading-snug mt-1">
                {ann.title}
              </h4>
              <p className="text-[12.5px] text-[#404944] mt-1 leading-relaxed">
                {ann.summary}
              </p>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#bfc9c3]/30 bg-[#f7f9fb]">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-[#003527] text-white font-bold text-[13px] rounded-lg hover:bg-[#064e3b] transition-colors cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      </div>
    </>
  );
};
