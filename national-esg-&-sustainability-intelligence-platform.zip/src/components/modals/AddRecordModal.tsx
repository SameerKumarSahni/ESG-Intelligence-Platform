import React, { useState } from 'react';
import { X, Plus, Sparkles, Building, Database } from 'lucide-react';
import { DataRecord, EsgPillar } from '../../types/esg';

interface AddRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddRecord: (record: DataRecord) => void;
}

export const AddRecordModal: React.FC<AddRecordModalProps> = ({
  isOpen,
  onClose,
  onAddRecord
}) => {
  const [indicator, setIndicator] = useState('Electricity Consumption');
  const [category, setCategory] = useState<EsgPillar>('environmental');
  const [value, setValue] = useState<number>(50000);
  const [unit, setUnit] = useState('kWh');
  const [facility, setFacility] = useState('Plant A (North)');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newRecord: DataRecord = {
      id: `rec-${Date.now()}`,
      date,
      indicator,
      category,
      value: Number(value),
      unit,
      facility,
      status: 'VERIFIED',
      sourceDoc: `Manual_Entry_${facility.replace(/\s+/g, '_')}.pdf`,
      confidence: 1.0,
      verifiedBy: 'Direct Facility Entry'
    };
    onAddRecord(newRecord);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-[#064e3b] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Database className="w-5 h-5" />
            <h3 className="font-bold text-base">Add New ESG Data Record</h3>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 uppercase tracking-wider mb-1">
              Pillar Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['environmental', 'social', 'governance'] as EsgPillar[]).map((p) => (
                <button
                  type="button"
                  key={p}
                  onClick={() => setCategory(p)}
                  className={`p-2.5 rounded-lg border font-semibold capitalize transition-colors ${
                    category === p
                      ? 'bg-emerald-50 border-[#064e3b] text-[#064e3b]'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Indicator Name
            </label>
            <input
              type="text"
              required
              value={indicator}
              onChange={(e) => setIndicator(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              placeholder="e.g., Electricity Consumption, Water Withdrawn, Lost Time Incidents"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Value</label>
              <input
                type="number"
                required
                value={value}
                onChange={(e) => setValue(parseFloat(e.target.value))}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 font-mono text-slate-800 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Unit</label>
              <input
                type="text"
                required
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
                placeholder="kWh, m³, tCO2e, %, Hours"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Facility</label>
              <select
                value={facility}
                onChange={(e) => setFacility(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              >
                <option>Global HQ</option>
                <option>Plant A (North)</option>
                <option>Plant B (South)</option>
                <option>Distribution Hub East</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Date</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#064e3b] hover:bg-[#043c2e] text-white rounded-lg font-semibold shadow-xs transition-all"
            >
              Save Record
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
