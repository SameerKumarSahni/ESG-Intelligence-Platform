import React, { useState } from 'react';
import {
  X,
  FileText,
  CheckCircle2,
  Download,
  Printer,
  Sparkles,
  ShieldCheck,
  Building,
  Calendar,
  Layers,
  Award
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { OrganizationInfo } from '../../types/esg';

interface GenerateReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  organization: OrganizationInfo;
}

export const GenerateReportModal: React.FC<GenerateReportModalProps> = ({
  isOpen,
  onClose,
  organization
}) => {
  const [selectedFramework, setSelectedFramework] = useState<'BRSR' | 'SEC' | 'CSRD' | 'GRI' | 'ALL'>('BRSR');
  const [fiscalYear, setFiscalYear] = useState('FY 2024 (Annual)');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedPdfReady, setGeneratedPdfReady] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setGeneratedPdfReady(true);
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }, 1200);
  };

  const handleDownload = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#064e3b] to-[#0f766e] text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center backdrop-blur-xs">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-lg leading-tight">
                Generate Institutional ESG Report
              </h3>
              <p className="text-xs text-emerald-100 mt-0.5">
                Audit-ready disclosure package for regulators and institutional investors.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {!generatedPdfReady ? (
            <>
              {/* Framework Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  Reporting Framework & Standard
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {(['BRSR', 'SEC', 'CSRD', 'GRI'] as const).map((fw) => (
                    <button
                      key={fw}
                      type="button"
                      onClick={() => setSelectedFramework(fw)}
                      className={`p-3 rounded-xl border text-xs font-bold text-center transition-all ${
                        selectedFramework === fw
                          ? 'border-[#064e3b] bg-emerald-50 text-[#064e3b] shadow-xs'
                          : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <span>{fw} Standard</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Fiscal Year & Target Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Reporting Period
                  </label>
                  <select
                    value={fiscalYear}
                    onChange={(e) => setFiscalYear(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#064e3b]"
                  >
                    <option value="FY 2024 (Annual)">FY 2024 (Full Annual Disclosure)</option>
                    <option value="Q3 2024 (Quarterly)">Q3 2024 (Interim Executive Review)</option>
                    <option value="YTD 2024">YTD 2024 (Cumulative Tracker)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    Target Recipient / Audience
                  </label>
                  <select className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#064e3b]">
                    <option>Board of Directors & Audit Committee</option>
                    <option>Securities & Exchange Commission / SEBI</option>
                    <option>Public Stakeholder ESG Portal</option>
                    <option>Credit Rating Agency (S&P/MSCI)</option>
                  </select>
                </div>
              </div>

              {/* Included Sections Checkboxes */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Report Synthesis Inclusions
                </label>
                <div className="space-y-2 text-xs text-slate-600">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5"
                    />
                    <span>Executive Summary & Overall ESG Score (78/100)</span>
                  </label>
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5"
                    />
                    <span>GHG Scope 1 & 2 Carbon Accounting Verification Table</span>
                  </label>
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5"
                    />
                    <span>AI Copilot Predictive Decarbonization Pathways</span>
                  </label>
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      defaultChecked
                      className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5"
                    />
                    <span>Peer Sector Benchmarking (Industrial Heavy Top 12%)</span>
                  </label>
                </div>
              </div>

              {/* Generate Trigger */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleGenerate}
                  disabled={isGenerating}
                  className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#064e3b] hover:bg-[#043c2e] text-white text-xs font-semibold rounded-lg shadow-sm transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isGenerating ? 'Compiling Dataset...' : 'Compile & Generate Report'}</span>
                </button>
              </div>
            </>
          ) : (
            /* Generated PDF Preview */
            <div className="space-y-6 animate-in fade-in zoom-in-95">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <h4 className="text-xs font-bold text-emerald-950">
                      Report Generated Successfully!
                    </h4>
                    <p className="text-[11px] text-emerald-700">
                      {selectedFramework} Compliance Assurance Pack ready for distribution.
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleDownload}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#064e3b] text-white text-xs font-bold rounded-lg shadow-xs hover:bg-[#043c2e]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download PDF</span>
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="p-1.5 bg-white border border-slate-200 text-slate-700 rounded-lg hover:bg-slate-50"
                    title="Print Document"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Report Cover Mock */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-slate-900 space-y-4">
                <div className="flex items-start justify-between border-b border-slate-200 pb-4">
                  <div>
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      {selectedFramework} OFFICIAL DISCLOSURE
                    </span>
                    <h2 className="text-lg font-bold text-slate-900 mt-1">
                      {organization.name}
                    </h2>
                    <p className="text-xs text-slate-500">{fiscalYear}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-[#064e3b]">78/100</div>
                    <div className="text-[10px] text-slate-500">Overall ESG Rating</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center py-2">
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Environmental</span>
                    <p className="text-base font-extrabold text-emerald-600 mt-0.5">82 / 100</p>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Social</span>
                    <p className="text-base font-extrabold text-blue-600 mt-0.5">74 / 100</p>
                  </div>
                  <div className="bg-white p-3 rounded-lg border border-slate-200">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Governance</span>
                    <p className="text-base font-extrabold text-purple-600 mt-0.5">79 / 100</p>
                  </div>
                </div>

                <div className="text-xs text-slate-600 leading-relaxed bg-white p-4 rounded-lg border border-slate-200 space-y-1.5">
                  <p className="font-semibold text-slate-800">Executive Summary:</p>
                  <p>
                    During {fiscalYear}, {organization.name} delivered a 4.2% year-over-year reduction in total Scope 1 & 2 carbon emissions (12,450 tCO2e), supported by increased on-site solar deployment and strict waste diversion across all four manufacturing clusters.
                  </p>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setGeneratedPdfReady(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Configure Another Report
                </button>
                <button
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-900 text-white text-xs font-semibold rounded-lg"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
