import React, { useState } from 'react';

interface SettingsModalProps {
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ onClose }) => {
  const [modelMode, setModelMode] = useState('gemini-3.7-flash');
  const [autoSync, setAutoSync] = useState(true);
  const [anomalyThreshold, setAnomalyThreshold] = useState('5%');

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[24px]">settings</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
                Platform Settings
              </h3>
              <p className="text-[13px] text-[#707974]">
                Configure AI Copilot parameters, sensor data sync, and alert thresholds.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
              AI Copilot Reasoning Engine
            </label>
            <select
              value={modelMode}
              onChange={(e) => setModelMode(e.target.value)}
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            >
              <option value="gemini-3.7-flash">Gemini 2.5 Flash / 3.7 (Recommended - Fast &amp; Multimodal)</option>
              <option value="gemini-2.5-pro">Gemini 2.5 Pro (Deep Decarbonization Research)</option>
            </select>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#f7f9fb] rounded-xl border border-[#bfc9c3]/30">
            <div>
              <span className="font-semibold text-[13.5px] text-[#191c1e] block">
                Automatic Sensor Telemetry Ingestion
              </span>
              <span className="text-[12px] text-[#707974]">
                Stream live GHG readings from smart grid meters every 15 minutes.
              </span>
            </div>
            <input
              type="checkbox"
              checked={autoSync}
              onChange={(e) => setAutoSync(e.target.checked)}
              className="w-5 h-5 accent-[#003527] cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
              Carbon Spike Anomaly Alert Sensitivity
            </label>
            <select
              value={anomalyThreshold}
              onChange={(e) => setAnomalyThreshold(e.target.value)}
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            >
              <option value="3%">High Sensitivity (±3% deviation triggers alert)</option>
              <option value="5%">Standard Sensitivity (±5% deviation)</option>
              <option value="10%">Low Sensitivity (±10% deviation)</option>
            </select>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              alert('Platform configuration saved successfully.');
              onClose();
            }}
            className="px-5 py-2 bg-[#003527] text-white font-bold text-[13px] rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export const SupportModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[24px]">help</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
                ESG Platform Support &amp; Docs
              </h3>
              <p className="text-[13px] text-[#707974]">
                Enterprise guidance for BRSR, GRI, SEC climate rules, and GHG accounting.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="space-y-3 text-[13.5px]">
          <div className="p-3.5 bg-[#f7f9fb] rounded-xl border border-[#bfc9c3]/30">
            <h4 className="font-bold text-[#003527] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px]">menu_book</span>
              Regulatory Documentation
            </h4>
            <p className="text-[12.5px] text-[#404944] mt-1">
              Access guidelines for SEBI BRSR Core, European CSRD double materiality, and US SEC Scope 1 &amp; 2 disclosure standards.
            </p>
          </div>

          <div className="p-3.5 bg-[#f7f9fb] rounded-xl border border-[#bfc9c3]/30">
            <h4 className="font-bold text-[#003527] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px]">smart_toy</span>
              AI Sustainability Copilot Assistance
            </h4>
            <p className="text-[12.5px] text-[#404944] mt-1">
              Ask any question directly to the AI Copilot tab for instant calculation check, supplier questionnaire drafts, or audit preparation.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#003527] text-white font-bold text-[13px] rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
