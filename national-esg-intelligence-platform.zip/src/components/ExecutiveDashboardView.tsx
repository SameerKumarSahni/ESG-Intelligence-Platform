import React, { useState } from 'react';

interface ExecutiveDashboardViewProps {
  onNavigateToTab: (tab: any) => void;
  onOpenReportModal: () => void;
}

export const ExecutiveDashboardView: React.FC<ExecutiveDashboardViewProps> = ({
  onNavigateToTab,
  onOpenReportModal,
}) => {
  const [timeRange, setTimeRange] = useState<'1Y' | '3Y' | '5Y'>('3Y');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState('Today, 08:45 AM');
  const [hoveredTrendPillar, setHoveredTrendPillar] = useState<string | null>(null);
  const [activeTooltip, setActiveTooltip] = useState<{ x: number; y: number; label: string; value: string } | null>(null);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setLastUpdated(`Today, ${timeStr}`);
      setIsRefreshing(false);
    }, 600);
  };

  // SVG Chart path data coordinates for 1Y, 3Y, 5Y
  const chartTrendsData = {
    '1Y': {
      env: 'M0,65 L25,58 L50,48 L75,38 L100,28',
      soc: 'M0,52 L25,48 L50,40 L75,32 L100,18',
      gov: 'M0,32 L25,30 L50,26 L75,22 L100,15',
      points: [
        { label: 'Q1', env: '78', soc: '84', gov: '88' },
        { label: 'Q2', env: '80', soc: '86', gov: '89' },
        { label: 'Q3', env: '81', soc: '87', gov: '90' },
        { label: 'Q4', env: '82', soc: '89', gov: '91' },
      ],
    },
    '3Y': {
      env: 'M0,70 L20,65 L40,60 L60,40 L80,30 L100,20',
      soc: 'M0,50 L20,55 L40,45 L60,35 L80,25 L100,10',
      gov: 'M0,30 L20,35 L40,30 L60,25 L80,20 L100,15',
      points: [
        { label: '2022', env: '72', soc: '79', gov: '85' },
        { label: '2023', env: '76', soc: '84', gov: '88' },
        { label: '2024 (Now)', env: '82', soc: '89', gov: '91' },
      ],
    },
    '5Y': {
      env: 'M0,80 L20,72 L40,64 L60,50 L80,32 L100,18',
      soc: 'M0,60 L20,58 L40,50 L60,40 L80,25 L100,12',
      gov: 'M0,45 L20,38 L40,32 L60,28 L80,20 L100,14',
      points: [
        { label: '2020', env: '64', soc: '72', gov: '80' },
        { label: '2022', env: '72', soc: '79', gov: '85' },
        { label: '2024', env: '82', soc: '89', gov: '91' },
      ],
    },
  };

  const activePaths = chartTrendsData[timeRange];

  return (
    <div id="executive-dashboard-container" className="max-w-[1440px] mx-auto space-y-8 pb-16">
      {/* Dashboard Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h2 className="font-['Montserrat',sans-serif] text-[32px] sm:text-[42px] font-bold text-[#191c1e] tracking-tight leading-tight">
            Executive Dashboard
          </h2>
          <p className="font-['Inter',sans-serif] text-[16px] sm:text-[17.5px] text-[#404944] mt-2 max-w-2xl">
            Unified performance metrics across all environmental, social, and governance pillars.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <span className="text-[13.5px] text-[#404944] font-medium">Last updated: {lastUpdated}</span>
          <button
            id="refresh-dashboard-btn"
            onClick={handleRefresh}
            className={`text-[#003527] hover:bg-[#003527]/10 p-2 rounded-full transition-all cursor-pointer ${
              isRefreshing ? 'animate-spin' : ''
            }`}
            title="Refresh Real-time Telemetry"
          >
            <span className="material-symbols-outlined text-[20px]">refresh</span>
          </button>
        </div>
      </div>

      {/* Top Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Overall Score Hero Card (Spans 4 columns) */}
        <div
          id="overall-esg-score-card"
          className="col-span-1 md:col-span-4 bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start">
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[22px] font-bold text-[#191c1e]">
                Overall ESG Score
              </h3>
              <p className="text-[12px] text-[#707974] mt-0.5">Composite Index (SASB & GRI)</p>
            </div>
            <span
              className="material-symbols-outlined text-[#707974] hover:text-[#003527] text-[20px] cursor-help"
              title="Composite score based on SASB and GRI frameworks computed across 24 enterprise materiality metrics."
            >
              info
            </span>
          </div>

          {/* Progress Ring Visual Simulation */}
          <div className="flex items-center justify-center py-6">
            <div className="relative w-48 h-48 flex items-center justify-center">
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {/* Background Track */}
                <circle
                  className="text-[#e6e8ea]"
                  cx="50"
                  cy="50"
                  fill="none"
                  r="43"
                  stroke="currentColor"
                  strokeWidth="8"
                />
                {/* Score Progress Fill */}
                <circle
                  className="text-[#003527] transition-all duration-1000 ease-out"
                  cx="50"
                  cy="50"
                  fill="none"
                  r="43"
                  stroke="currentColor"
                  strokeDasharray="270.17"
                  strokeDashoffset={270.17 * (1 - 0.86)}
                  strokeLinecap="round"
                  strokeWidth="8"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="font-['Montserrat',sans-serif] text-[48px] font-bold text-[#003527] leading-none">
                  86
                </span>
                <span className="text-[14px] font-medium text-[#707974] mt-1">/ 100</span>
              </div>
            </div>
          </div>

          {/* Bottom stats pill */}
          <div className="flex items-center justify-between mt-2 p-3.5 bg-[#f2f4f6] rounded-lg">
            <div className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#003527] text-[18px]">trending_up</span>
              <span className="font-['Inter',sans-serif] text-[13.5px] font-semibold text-[#003527]">
                +2.4% vs Last Qtr
              </span>
            </div>
            <span className="font-semibold text-[11.5px] text-[#003527] bg-[#003527]/10 px-3 py-1 rounded-full uppercase tracking-wider">
              Top Quartile
            </span>
          </div>
        </div>

        {/* Pillar Cards (Spans 8 columns, 3 nested cards) */}
        <div className="col-span-1 md:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-6">
          {/* Environmental */}
          <div
            id="pillar-card-environmental"
            onClick={() => onNavigateToTab('carbon-analytics')}
            className="bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] hover:shadow-md hover:border-[#004d46]/40 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="p-2.5 bg-[#004d46] text-[#53c2b5] rounded-lg group-hover:scale-105 transition-transform">
                <span className="material-symbols-outlined text-[22px]">eco</span>
              </div>
              <h4 className="font-['Montserrat',sans-serif] text-[19px] font-bold text-[#191c1e]">
                Environmental
              </h4>
            </div>
            <div className="mb-4">
              <div className="font-['Montserrat',sans-serif] text-[40px] font-bold text-[#191c1e] leading-none">
                82
              </div>
              <div className="text-[13.5px] text-[#707974] mt-1 font-medium">Score</div>
            </div>
            <div className="w-full bg-[#e6e8ea] h-2.5 rounded-full mb-3 overflow-hidden">
              <div
                className="bg-[#004d46] h-full rounded-full transition-all duration-700"
                style={{ width: '82%' }}
              />
            </div>
            <div className="flex justify-between text-[12.5px] font-semibold">
              <span className="text-[#004d46] flex items-center gap-0.5">
                <span className="material-symbols-outlined text-[14px]">arrow_upward</span> +4 pts
              </span>
              <span className="text-[#707974]">Target: 85</span>
            </div>
          </div>

          {/* Social */}
          <div
            id="pillar-card-social"
            onClick={() => onNavigateToTab('compliance-tracking')}
            className="bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] hover:shadow-md hover:border-[#4059aa]/40 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="p-2.5 bg-[#8fa7fe]/25 text-[#1d3989] rounded-lg group-hover:scale-105 transition-transform">
                <span className="material-symbols-outlined text-[22px]">diversity_3</span>
              </div>
              <h4 className="font-['Montserrat',sans-serif] text-[19px] font-bold text-[#191c1e]">
                Social
              </h4>
            </div>
            <div className="mb-4">
              <div className="font-['Montserrat',sans-serif] text-[40px] font-bold text-[#191c1e] leading-none">
                89
              </div>
              <div className="text-[13.5px] text-[#707974] mt-1 font-medium">Score</div>
            </div>
            <div className="w-full bg-[#e6e8ea] h-2.5 rounded-full mb-3 overflow-hidden">
              <div
                className="bg-[#4059aa] h-full rounded-full transition-all duration-700"
                style={{ width: '89%' }}
              />
            </div>
            <div className="flex justify-between text-[12.5px] font-semibold">
              <span className="text-[#4059aa] flex items-center gap-0.5">
                <span className="material-symbols-outlined text-[14px]">arrow_upward</span> +1 pt
              </span>
              <span className="text-[#707974]">Target: 90</span>
            </div>
          </div>

          {/* Governance */}
          <div
            id="pillar-card-governance"
            onClick={() => onNavigateToTab('compliance-tracking')}
            className="bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] hover:shadow-md hover:border-[#003527]/40 transition-all cursor-pointer group"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="p-2.5 bg-[#064e3b] text-[#80bea6] rounded-lg group-hover:scale-105 transition-transform">
                <span className="material-symbols-outlined text-[22px]">gavel</span>
              </div>
              <h4 className="font-['Montserrat',sans-serif] text-[19px] font-bold text-[#191c1e]">
                Governance
              </h4>
            </div>
            <div className="mb-4">
              <div className="font-['Montserrat',sans-serif] text-[40px] font-bold text-[#191c1e] leading-none">
                91
              </div>
              <div className="text-[13.5px] text-[#707974] mt-1 font-medium">Score</div>
            </div>
            <div className="w-full bg-[#e6e8ea] h-2.5 rounded-full mb-3 overflow-hidden">
              <div
                className="bg-[#003527] h-full rounded-full transition-all duration-700"
                style={{ width: '91%' }}
              />
            </div>
            <div className="flex justify-between text-[12.5px] font-semibold">
              <span className="text-[#003527]">Stable</span>
              <span className="text-[#707974]">Target: 90</span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Row (Spans 12 columns, 4 cards) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Carbon Footprint */}
        <div
          id="kpi-carbon-footprint"
          onClick={() => onNavigateToTab('carbon-analytics')}
          className="bg-white border border-[#bfc9c3]/35 rounded-xl p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[14px] font-semibold text-[#404944]">Carbon Footprint</span>
            <span className="material-symbols-outlined text-[#707974] text-[20px]">co2</span>
          </div>
          <div className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#191c1e] mb-1">
            14.2k <span className="text-[14px] font-normal text-[#707974]">tCO2e</span>
          </div>
          <div className="flex items-center gap-1 text-[12px] font-semibold text-[#003527]">
            <span className="material-symbols-outlined text-[15px]">arrow_downward</span>
            <span>5.2% vs baseline</span>
          </div>
        </div>

        {/* Energy Usage */}
        <div
          id="kpi-energy-usage"
          className="bg-white border border-[#bfc9c3]/35 rounded-xl p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[14px] font-semibold text-[#404944]">Energy Usage</span>
            <span className="material-symbols-outlined text-[#707974] text-[20px]">bolt</span>
          </div>
          <div className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#191c1e] mb-1">
            45.8 <span className="text-[14px] font-normal text-[#707974]">GWh</span>
          </div>
          <div className="flex items-center gap-1 text-[12px] font-semibold text-[#ba1a1a]">
            <span className="material-symbols-outlined text-[15px]">arrow_upward</span>
            <span>1.1% vs baseline</span>
          </div>
        </div>

        {/* Water Intensity */}
        <div
          id="kpi-water-intensity"
          className="bg-white border border-[#bfc9c3]/35 rounded-xl p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[14px] font-semibold text-[#404944]">Water Intensity</span>
            <span className="material-symbols-outlined text-[#707974] text-[20px]">water_drop</span>
          </div>
          <div className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#191c1e] mb-1">
            120 <span className="text-[14px] font-normal text-[#707974]">m3/rev</span>
          </div>
          <div className="flex items-center gap-1 text-[12px] font-semibold text-[#003527]">
            <span className="material-symbols-outlined text-[15px]">arrow_downward</span>
            <span>8.4% vs baseline</span>
          </div>
        </div>

        {/* Waste Management */}
        <div
          id="kpi-waste-diverted"
          className="bg-white border border-[#bfc9c3]/35 rounded-xl p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div className="flex justify-between items-start mb-2">
            <span className="text-[14px] font-semibold text-[#404944]">Waste Diverted</span>
            <span className="material-symbols-outlined text-[#707974] text-[20px]">recycling</span>
          </div>
          <div className="font-['Montserrat',sans-serif] text-[28px] font-bold text-[#191c1e] mb-1">
            74.5 <span className="text-[14px] font-normal text-[#707974]">%</span>
          </div>
          <div className="flex items-center gap-1 text-[12px] font-semibold text-[#003527]">
            <span className="material-symbols-outlined text-[15px]">trending_up</span>
            <span>On track for 80% goal</span>
          </div>
        </div>
      </div>

      {/* Chart Section (Spans 12 columns) */}
      <div
        id="sustainability-trends-chart-card"
        className="bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)]"
      >
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
          <div>
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              Sustainability Trends
            </h3>
            <p className="text-[13px] text-[#707974]">
              Multi-year historical trajectory across Environmental, Social, and Governance pillars.
            </p>
          </div>
          <div className="flex gap-2 bg-[#f2f4f6] p-1 rounded-lg border border-[#bfc9c3]/30">
            {(['1Y', '3Y', '5Y'] as const).map((range) => (
              <button
                key={range}
                id={`chart-range-${range}`}
                onClick={() => setTimeRange(range)}
                className={`px-3.5 py-1 text-[12px] font-semibold rounded-md transition-all cursor-pointer ${
                  timeRange === range
                    ? 'bg-[#003527] text-white shadow-xs'
                    : 'text-[#404944] hover:text-[#191c1e]'
                }`}
              >
                {range}
              </button>
            ))}
          </div>
        </div>

        {/* Chart Canvas Area */}
        <div className="w-full h-80 bg-[#f2f4f6]/80 rounded-xl relative overflow-hidden flex items-end px-6 pb-6 pt-12 border border-[#bfc9c3]/20">
          {/* Simulated Grid Lines */}
          <div className="absolute inset-0 flex flex-col justify-between pt-12 pb-8 px-6 pointer-events-none">
            <div className="w-full border-b border-[#bfc9c3]/25 h-0 flex items-center justify-between">
              <span className="text-[10px] text-[#707974] -mt-3">100</span>
            </div>
            <div className="w-full border-b border-[#bfc9c3]/25 h-0 flex items-center justify-between">
              <span className="text-[10px] text-[#707974] -mt-3">80</span>
            </div>
            <div className="w-full border-b border-[#bfc9c3]/25 h-0 flex items-center justify-between">
              <span className="text-[10px] text-[#707974] -mt-3">60</span>
            </div>
            <div className="w-full border-b border-[#bfc9c3]/25 h-0 flex items-center justify-between">
              <span className="text-[10px] text-[#707974] -mt-3">40</span>
            </div>
            <div className="w-full border-b border-[#bfc9c3]/50 h-0 flex items-center justify-between">
              <span className="text-[10px] text-[#707974] -mt-3">20</span>
            </div>
          </div>

          {/* SVG Line Chart */}
          <svg className="absolute inset-0 w-full h-full pt-12 pb-8 px-6" preserveAspectRatio="none" viewBox="0 0 100 100">
            {/* Env Line (Teal) */}
            <path
              d={activePaths.env}
              fill="none"
              stroke="#004d46"
              strokeWidth={hoveredTrendPillar === 'env' ? '3.5' : '2'}
              vectorEffect="non-scaling-stroke"
              className="transition-all duration-300"
            />
            {/* Soc Line (Dashed Navy) */}
            <path
              d={activePaths.soc}
              fill="none"
              stroke="#4059aa"
              strokeDasharray="4"
              strokeWidth={hoveredTrendPillar === 'soc' ? '3.5' : '2'}
              vectorEffect="non-scaling-stroke"
              className="transition-all duration-300"
            />
            {/* Gov Line (Thick Forest Green) */}
            <path
              d={activePaths.gov}
              fill="none"
              stroke="#003527"
              strokeWidth={hoveredTrendPillar === 'gov' ? '4.5' : '3'}
              vectorEffect="non-scaling-stroke"
              className="transition-all duration-300"
            />
          </svg>

          {/* Points summary overlay on X-axis */}
          <div className="w-full flex justify-between relative z-10 text-[12px] font-semibold text-[#404944]">
            {activePaths.points.map((pt, idx) => (
              <div key={idx} className="flex flex-col items-center group cursor-pointer">
                <span className="bg-white/80 backdrop-blur-xs px-2 py-0.5 rounded text-[11px] border border-[#bfc9c3]/30 mb-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  Env: {pt.env} | Soc: {pt.soc} | Gov: {pt.gov}
                </span>
                <span>{pt.label}</span>
              </div>
            ))}
          </div>

          {/* Legend Badge */}
          <div className="absolute top-4 right-4 flex gap-4 bg-white/90 px-3.5 py-1.5 rounded-lg backdrop-blur-sm border border-[#bfc9c3]/40 shadow-xs z-20">
            <button
              onMouseEnter={() => setHoveredTrendPillar('env')}
              onMouseLeave={() => setHoveredTrendPillar(null)}
              className="flex items-center gap-2 cursor-pointer"
            >
              <div className="w-3 h-3 rounded-full bg-[#004d46]" />
              <span className="text-[12px] font-semibold text-[#191c1e]">Env</span>
            </button>
            <button
              onMouseEnter={() => setHoveredTrendPillar('soc')}
              onMouseLeave={() => setHoveredTrendPillar(null)}
              className="flex items-center gap-2 cursor-pointer"
            >
              <div className="w-3 h-3 rounded-full bg-[#4059aa]" />
              <span className="text-[12px] font-semibold text-[#191c1e]">Soc</span>
            </button>
            <button
              onMouseEnter={() => setHoveredTrendPillar('gov')}
              onMouseLeave={() => setHoveredTrendPillar(null)}
              className="flex items-center gap-2 cursor-pointer"
            >
              <div className="w-3 h-3 rounded-full bg-[#003527]" />
              <span className="text-[12px] font-semibold text-[#191c1e]">Gov</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
