import React, { useState } from 'react';
import {
  Building2,
  Shield,
  Sliders,
  CheckCircle2,
  X,
  Server,
  Zap,
  Globe
} from 'lucide-react';
import { OrganizationInfo } from '../../types/esg';

interface SettingsModalProps {
  organization: OrganizationInfo;
  onUpdateOrg: (updated: OrganizationInfo) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  organization,
  onUpdateOrg,
  onClose
}) => {
  const [formData, setFormData] = useState<OrganizationInfo>({ ...organization });
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateOrg(formData);
    setSaveSuccess(true);
    setTimeout(() => {
      setSaveSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Organization & System Settings
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure institutional profiles, reporting standards, and emission factor databases.
          </p>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-slate-600 p-1"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        {/* Org Profile */}
        <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Building2 className="w-4 h-4 text-emerald-700" />
            Corporate Identity
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Legal Entity Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-900 font-semibold focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Dashboard Subtitle / Unit
              </label>
              <input
                type="text"
                value={formData.subhead}
                onChange={(e) => setFormData({ ...formData, subhead: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-900 font-semibold focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Industry Sector
              </label>
              <input
                type="text"
                value={formData.sector}
                onChange={(e) => setFormData({ ...formData, sector: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Active Reporting Fiscal Period
              </label>
              <input
                type="text"
                value={formData.fiscalYear}
                onChange={(e) => setFormData({ ...formData, fiscalYear: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded-lg p-2.5 text-slate-900 font-medium focus:ring-2 focus:ring-[#064e3b] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Emission Factors Database */}
        <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-3">
          <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-600" />
            Standard Emission Factor Catalog
          </h3>
          <p className="text-slate-500">
            Selected calculation libraries: <strong>EPA eGRID 2023</strong>, <strong>DEFRA UK 2024</strong>, <strong>GHG Protocol Corporate Standard (Scope 1, 2, 3)</strong>.
          </p>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          {saveSuccess ? (
            <span className="text-emerald-700 font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> Configuration Saved Successfully!
            </span>
          ) : (
            <span></span>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#064e3b] hover:bg-[#043c2e] text-white font-semibold rounded-lg shadow-sm"
            >
              Save Changes
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
