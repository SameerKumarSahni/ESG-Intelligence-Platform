import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Helper to initialize Gemini safely
  function getGeminiClient(): GoogleGenAI | null {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      return null;
    }
    return new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Copilot Chat endpoint
  app.post('/api/copilot/chat', async (req, res) => {
    try {
      const { message, history = [], esgContext } = req.body;

      if (!message) {
        return res.status(400).json({ error: 'Message is required' });
      }

      const ai = getGeminiClient();

      if (ai) {
        const systemPrompt = `You are the Sustainability Copilot, an elite AI advisor on the National ESG Intelligence Platform.
Your purpose is to deliver executive-grade ESG insights, carbon accounting assessments, compliance strategies (BRSR, GRI, CSRD, SEC, SASB, TCFD), and decarbonization roadmaps.

CURRENT PLATFORM ESG METRICS CONTEXT:
- Overall ESG Score: 86 / 100 (+2.4% vs last quarter, Top Quartile)
- Environmental Score: 82 / 100 (Target 85, +4 pts)
- Social Score: 89 / 100 (Target 90, +1 pt)
- Governance Score: 91 / 100 (Target 90, Stable)
- Total Carbon Footprint: 42,850 tCO2e (+4.2% vs prior year)
  - Scope 1 (Direct): 12,400 tCO2e (28.9%)
  - Scope 2 (Indirect): 8,950 tCO2e (20.9% - recent +12% increase in Eastern facilities due to grid intensity)
  - Scope 3 (Value Chain): 21,500 tCO2e (50.1% - major driver: Tier 1 supply chain)
- Energy Usage: 45.8 GWh (+1.1% vs baseline)
- Water Intensity: 120 m3/rev (-8.4% vs baseline, minor +3.5% spike in processing plants A & C)
- Waste Diverted: 74.5% (Goal: 80%)
- Compliance Status: 78% Overall Readiness (Q3 cycle), 3 Missing/Overdue (BRSR 2024 missing, EU Carbon Tax payment Q3 overdue, Supply chain audit pending), 12 Pending Tasks.

USER QUERY: "${message}"

RESPONSE FORMAT:
You MUST respond with a valid JSON object matching this schema:
{
  "text": "Clear, direct, and authoritative explanation addressing the user question directly with exact figures and context.",
  "dataWidgets": [
    {
      "title": "Short title (e.g. Scope 2 Emissions)",
      "metric": "+12%",
      "comparison": "vs last quarter",
      "description": "Short explanation (e.g. Increased energy consumption in Eastern region facilities.)",
      "type": "emission",
      "icon": "factory"
    }
  ],
  "recommendations": [
    {
      "title": "Actionable Recommendation Title",
      "description": "Specific concrete mitigation or next step",
      "icon": "solar_power",
      "highlight": true
    }
  ],
  "quickSuggestions": [
    "Draft a mitigation plan",
    "Show detailed regional breakdown"
  ]
}

Ensure the response is strictly valid JSON without wrapping in markdown backticks if possible, or standard json format.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: systemPrompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text || '';
        try {
          const parsed = JSON.parse(rawText);
          return res.json(parsed);
        } catch {
          // If JSON parse fails, wrap in default format
          return res.json({
            text: rawText,
            dataWidgets: [
              {
                title: 'Scope 2 Emissions',
                metric: '+12%',
                comparison: 'vs last quarter',
                description: 'Increased energy consumption in Eastern region facilities.',
                type: 'emission',
                icon: 'factory',
              },
            ],
            recommendations: [
              {
                title: 'Prioritize renewable energy procurement',
                description: 'Shift 15% of Eastern region grid dependency to renewable contracts to offset Scope 2 increase.',
                icon: 'solar_power',
                highlight: true,
              },
            ],
            quickSuggestions: ['Draft a mitigation plan', 'Show detailed regional breakdown'],
          });
        }
      } else {
        // Fallback intelligent handler for sandbox/preview
        const lowerMsg = message.toLowerCase();
        let replyText = "I've analyzed your latest sustainability and emissions telemetry across all facilities.";
        let widgets: any[] = [];
        let recs: any[] = [];
        let quicks: string[] = ['Draft a mitigation plan', 'Show detailed regional breakdown'];

        if (lowerMsg.includes('score') || lowerMsg.includes('decrease') || lowerMsg.includes('why')) {
          replyText = "I've analyzed the recent data updates. Your overall ESG score decreased by 4% (from 78 to 74) primarily due to changes in the Environmental pillar.";
          widgets = [
            {
              title: 'Scope 2 Emissions',
              metric: '+12%',
              comparison: 'vs last quarter',
              description: 'Increased energy consumption in Eastern region facilities.',
              type: 'emission',
              icon: 'factory',
            },
            {
              title: 'Water Usage',
              metric: '+3.5%',
              comparison: 'vs last quarter',
              description: 'Minor spike in processing plants.',
              type: 'water',
              icon: 'water_drop',
            },
          ];
          recs = [
            {
              title: 'Prioritize renewable energy procurement',
              description: 'Shift 15% of Eastern region grid dependency to renewable contracts to offset the Scope 2 increase.',
              icon: 'solar_power',
              highlight: true,
            },
            {
              title: 'Initiate water audit',
              description: 'Conduct a targeted audit at processing plants A and C to identify potential leakage or inefficiencies.',
              icon: 'plumbing',
              highlight: false,
            },
          ];
          quicks = ['Draft a mitigation plan', 'Show detailed regional breakdown', 'Compare against EU Taxonomy'];
        } else if (lowerMsg.includes('mitigation') || lowerMsg.includes('plan')) {
          replyText = "Here is a prioritized 90-day decarbonization & compliance mitigation roadmap designed to restore your Environmental index to 85+:";
          widgets = [
            {
              title: 'Target Reduction',
              metric: '-2,400 tCO2e',
              comparison: 'by Q1 2025',
              description: 'Estimated net carbon abatement through proposed PPA and boiler upgrades.',
              type: 'emission',
              icon: 'eco',
            },
            {
              title: 'Capital Req.',
              metric: '$180,000',
              comparison: 'ROI: 14 months',
              description: 'Energy efficiency retrofits with high local green tax credit eligibility.',
              type: 'energy',
              icon: 'payments',
            },
          ];
          recs = [
            {
              title: 'Execute 15MW Solar PPA Contract',
              description: 'Sign virtual power purchase agreement for Ohio and Frankfurt manufacturing hubs.',
              icon: 'solar_power',
              highlight: true,
            },
            {
              title: 'Resolve Overdue EU Carbon Tax',
              description: 'Submit pending EU ETS allowance filings to clear compliance penalty flag immediately.',
              icon: 'task_alt',
              highlight: true,
            },
          ];
          quicks = ['Export mitigation plan to PDF', 'Ask for supplier compliance checklist', 'Review Scope 3 breakdown'];
        } else if (lowerMsg.includes('scope 3') || lowerMsg.includes('supply chain')) {
          replyText = "Scope 3 emissions currently account for 50.1% (21,500 tCO2e) of total corporate emissions. The primary drivers are Category 1 Purchased Goods & Services and Category 4 Upstream Transportation.";
          widgets = [
            {
              title: 'Scope 3 Share',
              metric: '50.1%',
              comparison: '+3.1% YoY',
              description: '21,500 tCO2e across 142 surveyed tier-1 suppliers.',
              type: 'emission',
              icon: 'hub',
            },
            {
              title: 'Supplier Response Rate',
              metric: '74%',
              comparison: 'Target: 95%',
              description: '37 high-volume vendors have not yet submitted primary carbon accounting sheets.',
              type: 'social',
              icon: 'group',
            },
          ];
          recs = [
            {
              title: 'Deploy Supplier ESG Self-Assessment Portal',
              description: 'Send automated compliance reminder to 37 outstanding suppliers with deadline of Nov 1st.',
              icon: 'send',
              highlight: true,
            },
            {
              title: 'Incentivize Sea-Freight Transition',
              description: 'Shift 20% of high-urgency air freight to maritime low-carbon shipping lanes.',
              icon: 'directions_boat',
              highlight: false,
            },
          ];
          quicks = ['Generate Supplier Audit Checklist', 'View Compliance Tracking', 'Simulate Net Zero 2030'];
        } else {
          replyText = `Based on your query regarding "${message}", our ESG intelligence engine has cross-referenced real-time sensor streams and compliance logs. All core indicators show solid progress towards your FY 2024 sustainability objectives, with immediate focus required on Scope 2 energy procurement and overdue EU ETS submissions.`;
          widgets = [
            {
              title: 'Overall Readiness',
              metric: '78%',
              comparison: 'Q3 Cycle',
              description: '22% remaining across 3 critical compliance submissions.',
              type: 'governance',
              icon: 'donut_large',
            },
          ];
          recs = [
            {
              title: 'Review Action Items in Compliance Tracking',
              description: 'Address the 3 overdue/missing regulatory filings before the next reporting deadline.',
              icon: 'fact_check',
              highlight: true,
            },
          ];
          quicks = ['Draft a mitigation plan', 'Why did our ESG score decrease?', 'Export Executive Brief'];
        }

        return res.json({
          text: replyText,
          dataWidgets: widgets,
          recommendations: recs,
          quickSuggestions: quicks,
        });
      }
    } catch (err: any) {
      console.error('Copilot API error:', err);
      res.status(500).json({
        error: 'Failed to process copilot query',
        message: err.message,
      });
    }
  });

  // AI Report Generator endpoint
  app.post('/api/report/generate', async (req, res) => {
    try {
      const { framework = 'BRSR', fiscalYear = 'FY 2024', region = 'Global', materialityFocus = [] } = req.body;

      const ai = getGeminiClient();

      if (ai) {
        const prompt = `Generate an executive ESG Sustainability Report formatted in structured JSON.
Framework: ${framework}
Fiscal Year: ${fiscalYear}
Region: ${region}
Materiality Topics: ${materialityFocus.join(', ') || 'Carbon, Energy, Water, Governance'}

JSON schema required:
{
  "title": "${framework} Sustainability & ESG Intelligence Report (${fiscalYear})",
  "overallScore": 86,
  "scores": {
    "environmental": 82,
    "social": 89,
    "governance": 91
  },
  "emissions": {
    "total": 42850,
    "scope1": 12400,
    "scope2": 8950,
    "scope3": 21500
  },
  "executiveSummary": "Concise 3-paragraph executive summary highlighting performance, top risks, and strategic roadmap.",
  "keyFindings": ["Finding 1", "Finding 2", "Finding 3", "Finding 4"],
  "recommendations": ["Recommendation 1", "Recommendation 2", "Recommendation 3"],
  "fullContentMarkdown": "Full formatted comprehensive report in Markdown with sections: 1. Governance & Leadership Statement, 2. Environmental & Climate Disclosures (Scope 1/2/3), 3. Social Capital & Labor Metrics, 4. Regulatory Compliance & Audit Matrix."
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.7-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
          },
        });

        const rawText = response.text || '';
        const parsed = JSON.parse(rawText);
        return res.json({
          ...parsed,
          id: `rep-${Date.now()}`,
          framework,
          fiscalYear,
          createdAt: new Date().toISOString().split('T')[0],
          author: 'AI ESG Intelligence Engine',
          status: 'Ready',
        });
      } else {
        // Fallback report generation
        return res.json({
          id: `rep-${Date.now()}`,
          title: `${framework} Sustainability & ESG Intelligence Report (${fiscalYear})`,
          framework,
          fiscalYear,
          createdAt: new Date().toISOString().split('T')[0],
          author: 'AI ESG Intelligence Engine',
          status: 'Ready',
          overallScore: 86,
          scores: {
            environmental: 82,
            social: 89,
            governance: 91,
          },
          emissions: {
            total: 42850,
            scope1: 12400,
            scope2: 8950,
            scope3: 21500,
          },
          executiveSummary: `This ${framework} report for ${fiscalYear} covers ${region} operations with a primary focus on ${materialityFocus.join(', ') || 'decarbonization and governance'}. The organization secured an ESG composite score of 86/100, ranking in the top quartile of industry peers. Operational carbon footprint decreased by 5.2% vs baseline, supported by 74.5% total waste diversion.`,
          keyFindings: [
            'Scope 1 direct emissions reduced by 4.8% through facility heat recovery and boiler electrification.',
            'Scope 2 electricity emissions increased by 12% in Eastern facilities due to regional grid mix variations.',
            'Scope 3 supply chain represents 50.1% of gross corporate footprint (21,500 tCO2e).',
            'Workplace safety recorded 0 lost-time incidents with 100% compliance in mandatory health audits.',
          ],
          recommendations: [
            'Procure 15MW long-term renewable Power Purchase Agreements (PPAs) to stabilize Scope 2 exposure.',
            'Enforce mandatory CDP climate disclosure submissions across all Tier-1 suppliers by Q1.',
            'Deploy closed-loop wastewater recycling at manufacturing plants A and C.',
          ],
          fullContentMarkdown: `# National ESG Platform — ${framework} Intelligence Report (${fiscalYear})
**Region**: ${region} | **Score**: 86/100 (Top Quartile) | **Status**: Verified

---

## 1. Executive Statement
Our ${fiscalYear} sustainability disclosures demonstrate disciplined execution against Net-Zero 2040 milestones. We continue to integrate SASB, GRI, and ${framework} mandates into corporate financial planning.

### Pillar Performance
- **Environmental**: 82/100 (+4 pts, Target: 85)
- **Social**: 89/100 (+1 pt, Target: 90)
- **Governance**: 91/100 (Stable, Target: 90)

---

## 2. GHG Emissions & Energy Ledger
| Scope | Volume (tCO2e) | Proportion | Primary Source |
| :--- | :--- | :--- | :--- |
| **Scope 1 (Direct)** | 12,400 | 28.9% | Natural gas boilers & fleet |
| **Scope 2 (Indirect)** | 8,950 | 20.9% | Purchased grid electricity |
| **Scope 3 (Supply Chain)** | 21,500 | 50.2% | Purchased goods & freight |
| **Total** | **42,850** | **100.0%** | Comprehensive footprint |

---

## 3. Compliance and Risk Mitigation
All statutory filings have been audited against regional benchmarks. Three high-priority action items are scheduled for completion prior to the upcoming quarterly cycle.`,
        });
      }
    } catch (err: any) {
      console.error('Report API error:', err);
      res.status(500).json({ error: 'Failed to generate report', message: err.message });
    }
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`National ESG Platform Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
});
