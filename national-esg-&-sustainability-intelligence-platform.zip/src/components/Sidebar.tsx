import React from 'react';
import {
  LayoutDashboard,
  Database,
  BarChart3,
  Bot,
  CheckSquare,
  Settings,
  FileText,
  Building2,
  ExternalLink
} from 'lucide-react';
import { ActiveTab } from '../types/esg';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenReportModal: () => void;
  onGoToLanding: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenReportModal,
  onGoToLanding
}) => {
  const navItems = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'data-management' as ActiveTab, label: 'Data Management', icon: Database },
    { id: 'carbon-analytics' as ActiveTab, label: 'Carbon Analytics', icon: BarChart3 },
    { id: 'ai-copilot' as ActiveTab, label: 'AI Copilot', icon: Bot },
    { id: 'compliance' as ActiveTab, label: 'Compliance', icon: CheckSquare },
    { id: 'settings' as ActiveTab, label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 h-screen sticky top-0 z-30 select-none">
      <div>
        {/* Top Logo / Institutional Header */}
        <div 
          onClick={onGoToLanding}
          className="p-5 border-b border-slate-100 flex items-center gap-3 cursor-pointer group hover:bg-slate-50 transition-colors"
          title="Click to view Public Portal Overview"
        >
          <div className="w-10 h-10 rounded-xl bg-[#064e3b] text-white flex items-center justify-center font-bold text-sm shadow-sm group-hover:scale-105 transition-transform">
            NP
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-slate-900 text-base leading-tight tracking-tight">
                National Portal
              </h1>
            </div>
            <p className="text-xs text-slate-500 font-medium">Institutional Access</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="p-3 space-y-1 mt-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 text-left ${
                  isActive
                    ? 'bg-[#064e3b] text-white shadow-sm font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Section */}
      <div className="p-4 border-t border-slate-100 space-y-3">
        {/* Public Landing Link */}
        <button
          onClick={onGoToLanding}
          className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <span className="flex items-center gap-2">
            <Building2 className="w-3.5 h-3.5 text-slate-400" />
            Public ESG Portal
          </span>
          <ExternalLink className="w-3 h-3 text-slate-400" />
        </button>

        {/* Generate ESG Report Button */}
        <button
          onClick={onOpenReportModal}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#064e3b] hover:bg-[#043c2e] text-white rounded-lg text-sm font-medium shadow-sm transition-all duration-150 active:scale-[0.98]"
        >
          <FileText className="w-4 h-4" />
          <span>Generate ESG Report</span>
        </button>
      </div>
    </aside>
  );
};
