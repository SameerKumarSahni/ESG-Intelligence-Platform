import React from 'react';
import { X, ShieldCheck, Download, ExternalLink, Calendar, CheckCircle2, FileCheck2 } from 'lucide-react';
import { ComplianceItem } from '../../types/esg';

interface EvidenceModalProps {
  item: ComplianceItem | null;
  isOpen: boolean;
  onClose: () => void;
}

export const EvidenceModal: React.FC<EvidenceModalProps> = ({
  item,
  isOpen,
  onClose
}) => {
  if (!isOpen || !item) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-base leading-none">
                Compliance Audit Trail
              </h3>
              <p className="text-[11px] text-slate-400 mt-1">
                {item.framework} • {item.name}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-900 text-sm">{item.name}</span>
              <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[11px]">
                {item.status}
              </span>
            </div>
            <p className="text-slate-500">{item.subtext}</p>
          </div>

          <div className="space-y-1.5">
            <label className="font-bold text-slate-700 uppercase tracking-wider text-[10px]">
              Assurance Notes & Verification Findings
            </label>
            <p className="p-3 bg-white border border-slate-200 rounded-lg text-slate-700 leading-relaxed">
              {item.evidenceNotes ||
                'Verified in accordance with ISO 14064-3 standards for greenhouse gas declarations. Data audited across primary utility receipts and on-site SCADA logs.'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-[11px] bg-slate-50 p-3 rounded-lg border border-slate-100">
            <div>
              <span className="text-slate-400">Assurance Owner:</span>
              <p className="font-bold text-slate-800">{item.responsible.name}</p>
            </div>
            <div>
              <span className="text-slate-400">Due / Sign-off Date:</span>
              <p className="font-bold text-slate-800">{item.dueDate}</p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-slate-400 text-[10px]">SHA-256 Hash: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855</span>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition-colors"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
