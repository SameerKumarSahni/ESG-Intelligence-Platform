import React, { useState } from 'react';
import { X, UploadCloud, FileSpreadsheet, CheckCircle2, AlertCircle } from 'lucide-react';
import { DataRecord } from '../../types/esg';

interface BulkUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBulkIngest: (newRecords: DataRecord[]) => void;
}

export const BulkUploadModal: React.FC<BulkUploadModalProps> = ({
  isOpen,
  onClose,
  onBulkIngest
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);

  if (!isOpen) return null;

  const handleSimulatedUpload = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      const generatedRecords: DataRecord[] = [
        {
          id: `bulk-${Date.now()}-1`,
          date: '2024-03-31',
          indicator: 'Recycled Aluminum Scrap',
          category: 'environmental',
          value: 12400,
          unit: 'kg',
          facility: 'Plant A (North)',
          status: 'VERIFIED',
          sourceDoc: 'CSV_Bulk_Ingest_March.csv',
          confidence: 0.99
        },
        {
          id: `bulk-${Date.now()}-2`,
          date: '2024-03-31',
          indicator: 'Substation Reactive Power Loss',
          category: 'environmental',
          value: 3200,
          unit: 'kVARh',
          facility: 'Plant B (South)',
          status: 'DRAFT',
          sourceDoc: 'CSV_Bulk_Ingest_March.csv',
          confidence: 0.88
        }
      ];
      onBulkIngest(generatedRecords);
      onClose();
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <UploadCloud className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-base">Bulk ESG Data Upload</h3>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs">
          <p className="text-slate-600">
            Upload CSV, Excel, or JSON exports from your ERP, SCADA, or utility billing systems. The platform will automatically map indicators and calculate CO2e equivalents.
          </p>

          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files?.[0]) {
                setUploadedFile(e.dataTransfer.files[0]);
              }
            }}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
              isDragging
                ? 'border-[#064e3b] bg-emerald-50'
                : 'border-slate-300 hover:border-slate-400 bg-slate-50'
            }`}
          >
            <FileSpreadsheet className="w-10 h-10 mx-auto text-slate-400 mb-3" />
            {uploadedFile ? (
              <div className="text-slate-900 font-bold">
                <p>{uploadedFile.name}</p>
                <p className="text-[10px] text-slate-500 mt-1">
                  {(uploadedFile.size / 1024).toFixed(1)} KB • Ready for validation
                </p>
              </div>
            ) : (
              <div>
                <p className="font-bold text-slate-800">
                  Drag and drop your spreadsheet here
                </p>
                <p className="text-slate-400 mt-1">Supports .csv, .xlsx, .json up to 25MB</p>
                <button
                  type="button"
                  onClick={() => {
                    const mockFile = new File(['dummy'], 'Q3_Utility_Aggregated_Feed.csv', {
                      type: 'text/csv'
                    });
                    setUploadedFile(mockFile);
                  }}
                  className="mt-4 px-4 py-2 bg-white border border-slate-200 text-slate-700 font-semibold rounded-lg shadow-xs hover:bg-slate-50"
                >
                  Browse Files
                </button>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-[11px] text-slate-400">
              Template: <a href="#template" onClick={(e) => e.preventDefault()} className="underline text-blue-600">Download ESG_Schema_v2.csv</a>
            </span>

            <div className="flex gap-2">
              <button
                onClick={onClose}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-semibold"
              >
                Cancel
              </button>
              <button
                disabled={!uploadedFile || isProcessing}
                onClick={handleSimulatedUpload}
                className="px-5 py-2.5 bg-[#064e3b] hover:bg-[#043c2e] disabled:opacity-40 text-white rounded-lg font-semibold shadow-xs transition-all"
              >
                {isProcessing ? 'Ingesting...' : 'Validate & Import'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
