import React, { useState } from 'react';
import {
  Search,
  Bell,
  Settings as SettingsIcon,
  Plus,
  ChevronDown,
  Building,
  CheckCircle2,
  AlertTriangle,
  FileCheck2,
  X
} from 'lucide-react';
import { ActiveTab, OrganizationInfo } from '../types/esg';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  organization: OrganizationInfo;
  onOpenReportModal: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  organization,
  onOpenReportModal,
  searchQuery,
  setSearchQuery
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showOrgMenu, setShowOrgMenu] = useState(false);
  const [unreadCount, setUnreadCount] = useState(2);

  const notifications = [
    {
      id: 1,
      title: 'Facility B Electricity Spike',
      description: 'Consumption increased by 22% in Q3 vs baseline target.',
      type: 'warning',
      time: '25m ago'
    },
    {
      id: 2,
      title: 'SEC Climate Scope 1 Verified',
      description: 'Third-party assurance certification document approved.',
      type: 'success',
      time: '2h ago'
    },
    {
      id: 3,
      title: 'GRI Water Metrics Reminder',
      description: 'Facility level data for Plant B requires review.',
      type: 'info',
      time: '1d ago'
    }
  ];

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between sticky top-0 z-20">
      {/* Left Title / Breadcrumb */}
      <div className="flex items-center gap-3">
        <h2 className="text-lg font-bold text-slate-800 tracking-tight">
          ESG Intelligence
        </h2>
        <span className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          Live Sync Active
        </span>
      </div>

      {/* Center Search (Dynamic depending on active tab) */}
      <div className="flex-1 max-w-md mx-6">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={
              activeTab === 'data-management'
                ? 'Search records, facilities, or metrics...'
                : activeTab === 'compliance'
                ? 'Search compliance frameworks or disclosures...'
                : 'Search platform data, insights, or records...'
            }
            className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-full focus:outline-none focus:ring-2 focus:ring-[#064e3b] focus:bg-white text-slate-800 placeholder-slate-400 transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              if (!showNotifications) setUnreadCount(0);
            }}
            className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-full transition-colors relative"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-red-500"></span>
            )}
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Audit & System Alerts
                </h4>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs"
                >
                  Close
                </button>
              </div>
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-3 hover:bg-slate-50 transition-colors cursor-pointer flex gap-3 text-left"
                  >
                    <div className="mt-0.5">
                      {n.type === 'warning' && (
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                      )}
                      {n.type === 'success' && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      )}
                      {n.type === 'info' && (
                        <FileCheck2 className="w-4 h-4 text-blue-500" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold text-slate-800">{n.title}</p>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{n.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Settings Button */}
        <button
          onClick={() => setActiveTab('settings')}
          className={`p-2 rounded-full transition-colors ${
            activeTab === 'settings'
              ? 'bg-slate-100 text-slate-900'
              : 'text-slate-500 hover:text-slate-800 hover:bg-slate-100'
          }`}
          title="Organization Settings"
        >
          <SettingsIcon className="w-4 h-4" />
        </button>

        {/* New Report Button */}
        <button
          onClick={onOpenReportModal}
          className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#064e3b] hover:bg-[#043c2e] text-white rounded-md text-xs font-semibold shadow-sm transition-all"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Report</span>
        </button>

        {/* User Profile Avatar */}
        <div className="relative">
          <button
            onClick={() => setShowOrgMenu(!showOrgMenu)}
            className="flex items-center gap-2 pl-2 border-l border-slate-200"
          >
            <div className="w-8 h-8 rounded-full overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=200&auto=format&fit=crop"
                alt="Elena Rostova"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
          </button>

          {showOrgMenu && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-3 z-50">
              <div className="pb-2 border-b border-slate-100">
                <p className="text-xs font-bold text-slate-800">Elena Rostova</p>
                <p className="text-[11px] text-slate-500">Chief Sustainability Officer</p>
              </div>
              <div className="pt-2 text-xs space-y-1">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Active Entity
                </div>
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-900 font-medium flex items-center gap-2">
                  <Building className="w-3.5 h-3.5 text-emerald-700" />
                  <span className="truncate">{organization.name}</span>
                </div>
                <button
                  onClick={() => {
                    setActiveTab('settings');
                    setShowOrgMenu(false);
                  }}
                  className="w-full text-left p-1.5 text-slate-600 hover:text-slate-900 rounded hover:bg-slate-50"
                >
                  Configure Facilities & Factors
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
