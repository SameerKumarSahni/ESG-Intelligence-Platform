import React from 'react';

interface RegionalDataModalProps {
  onClose: () => void;
  onFilterRegion: (region: string) => void;
}

export const RegionalDataModal: React.FC<RegionalDataModalProps> = ({ onClose, onFilterRegion }) => {
  const facilities = [
    { name: 'Rotterdam Distribution Hub', region: 'Western Europe', scope1: '1,200 tCO2e', status: 'ISO 14001 Certified', renewable: '85%' },
    { name: 'Frankfurt Manufacturing Campus', region: 'Western Europe', scope1: '3,800 tCO2e', status: 'EUA Surrender Required', renewable: '78%' },
    { name: 'Ohio Assembly Plant & R&D', region: 'North America', scope1: '4,100 tCO2e', status: 'Active PPA 15MW', renewable: '65%' },
    { name: 'Singapore Logistics Center', region: 'Asia Pacific', scope1: '950 tCO2e', status: 'BCA Green Mark Platinum', renewable: '92%' },
    { name: 'São Paulo Processing Unit', region: 'Latin America', scope1: '2,350 tCO2e', status: 'ZLD Water Recycling Active', renewable: '70%' },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl space-y-6 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[24px]">location_on</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[22px] font-bold text-[#191c1e]">
                Operating Regional Facilities
              </h3>
              <p className="text-[13px] text-[#707974]">
                Facility-level telemetry, renewable energy contracts, and localized compliance status.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="space-y-3">
          {facilities.map((fac, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl border border-[#bfc9c3]/30 bg-[#f7f9fb] hover:bg-white hover:border-[#003527] transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3"
            >
              <div>
                <span className="text-[11px] font-bold text-[#003527] uppercase">{fac.region}</span>
                <h4 className="font-bold text-[14.5px] text-[#191c1e]">{fac.name}</h4>
                <p className="text-[12px] text-[#707974] mt-0.5">{fac.status}</p>
              </div>
              <div className="flex items-center gap-4 text-[13px]">
                <div>
                  <span className="text-[#707974] block text-[11px]">Scope 1</span>
                  <span className="font-bold font-mono text-[#191c1e]">{fac.scope1}</span>
                </div>
                <div>
                  <span className="text-[#707974] block text-[11px]">Renewable %</span>
                  <span className="font-bold text-[#004d46]">{fac.renewable}</span>
                </div>
                <button
                  onClick={() => {
                    onFilterRegion(fac.region);
                    onClose();
                  }}
                  className="px-3 py-1.5 bg-[#003527] text-white font-semibold text-[12px] rounded-lg hover:bg-[#064e3b] transition-colors cursor-pointer"
                >
                  Filter Region
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-[#f2f4f6] text-[#191c1e] font-semibold text-[13px] rounded-lg hover:bg-[#e6e8ea] transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
