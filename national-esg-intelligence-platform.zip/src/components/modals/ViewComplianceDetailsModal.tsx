import React from 'react';
import { ComplianceItem } from '../../types';

interface ViewComplianceDetailsModalProps {
  item: ComplianceItem | null;
  onClose: () => void;
  onUploadEvidence: (item: ComplianceItem) => void;
}

export const ViewComplianceDetailsModal: React.FC<ViewComplianceDetailsModalProps> = ({
  item,
  onClose,
  onUploadEvidence,
}) => {
  if (!item) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[24px]">{item.icon}</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
                {item.title}
              </h3>
              <p className="text-[13px] text-[#707974]">{item.subtitle}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <div className="grid grid-cols-3 gap-3 p-3 bg-[#f2f4f6] rounded-xl text-[12.5px]">
          <div>
            <span className="text-[#707974] block">Pillar</span>
            <span className="font-semibold text-[#191c1e]">{item.pillar}</span>
          </div>
          <div>
            <span className="text-[#707974] block">Status</span>
            <span className="font-semibold text-[#003527]">{item.status}</span>
          </div>
          <div>
            <span className="text-[#707974] block">Filing Deadline</span>
            <span className="font-semibold font-mono text-[#191c1e]">{item.deadline}</span>
          </div>
        </div>

        <div className="space-y-2">
          <h4 className="text-[13px] font-bold uppercase tracking-wider text-[#404944]">
            Audit Scope &amp; Legal Description
          </h4>
          <p className="text-[14px] text-[#191c1e] leading-relaxed bg-[#f7f9fb] p-4 rounded-xl border border-[#bfc9c3]/30">
            {item.details || 'Full ESG compliance review requirement verified against current SEC/SEBI/CSRD regulatory reporting specifications.'}
          </p>
        </div>

        <div className="flex justify-between items-center pt-2">
          <button
            onClick={() => alert(`Framework citation: ${item.title} conforms with ISO 14001, GHG Protocol Corporate Standard, and BRSR Section C Principle 6.`)}
            className="text-[12.5px] font-semibold text-[#003527] hover:underline flex items-center gap-1"
          >
            <span className="material-symbols-outlined text-[16px]">menu_book</span>
            View Framework Standard
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onUploadEvidence(item);
              }}
              className="px-4 py-2 text-[13px] font-bold bg-[#003527] text-white rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">upload</span>
              Update Evidence
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
