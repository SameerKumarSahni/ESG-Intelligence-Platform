import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Download,
  Trash2,
  Lightbulb,
  CheckCircle2,
  RefreshCw,
  Send,
  Paperclip,
  Zap,
  Sun,
  BarChart2,
  Users,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  ShieldCheck,
  Building
} from 'lucide-react';
import { CopilotMessage, OrganizationInfo } from '../types/esg';
import { initialCopilotConversation } from '../data/mockData';

interface AiCopilotViewProps {
  organization: OrganizationInfo;
  onOpenReportModal: () => void;
  onNavigateTab: (tab: any) => void;
}

export const AiCopilotView: React.FC<AiCopilotViewProps> = ({
  organization,
  onOpenReportModal,
  onNavigateTab
}) => {
  const [messages, setMessages] = useState<CopilotMessage[]>(initialCopilotConversation);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const suggestedQueries = [
    {
      title: 'Why did our carbon emissions increase in Q3?',
      tag: 'Scans Scope 1 & 2',
      icon: 'TrendingUp'
    },
    {
      title: 'Summarize our ESG performance',
      tag: 'YTD Executive Brief',
      icon: 'FileText'
    },
    {
      title: 'How can we reduce energy consumption?',
      tag: 'Generates actionable steps',
      icon: 'Zap'
    },
    {
      title: 'Check SEC Scope 3 compliance status',
      tag: 'Audit Readiness',
      icon: 'ShieldCheck'
    }
  ];

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;

    const userMsg: CopilotMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsLoading(true);

    try {
      // Attempt server-side Gemini API call if backend is running, otherwise intelligent local copilot
      const response = await fetch('/api/ai/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          organization: organization.name,
          history: messages.slice(-4)
        })
      });

      if (response.ok) {
        const data = await response.json();
        const botMsg: CopilotMessage = {
          id: `bot-${Date.now()}`,
          role: 'assistant',
          content: data.text || data.response || 'Analysis complete.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          cards: data.cards,
          actionLinks: data.actionLinks
        };
        setMessages((prev) => [...prev, botMsg]);
      } else {
        // Fallback intelligent responder based on ESG queries
        generateContextualResponse(text);
      }
    } catch (err) {
      generateContextualResponse(text);
    } finally {
      setIsLoading(false);
    }
  };

  const generateContextualResponse = (query: string) => {
    const q = query.toLowerCase();
    let replyText = '';
    let cards = undefined;
    let actionLinks = undefined;

    if (q.includes('why') || q.includes('increase') || q.includes('carbon')) {
      replyText =
        'Based on your ESG records, the **18% increase** in Q3 was primarily driven by a **22% surge in electricity consumption** at Facility B, coupled with a temporary decrease in solar array efficiency due to scheduled maintenance.';
      cards = [
        {
          title: 'FACILITY B ELEC.',
          value: '1.4k MWh',
          changeBadge: '↗ +22%',
          changeBadgeType: 'increase-bad' as const,
          colorBar: 'bg-red-500',
          iconType: 'Zap'
        },
        {
          title: 'SOLAR ARRAY EFF.',
          value: '68%',
          changeBadge: '↘ -12%',
          changeBadgeType: 'decrease-good' as const,
          colorBar: 'bg-emerald-600',
          iconType: 'Sun'
        }
      ];
      actionLinks = [
        { label: 'View detailed Q3 report', action: 'report', icon: 'BarChart2' },
        { label: 'Check maintenance logs', action: 'compliance', icon: 'Users' }
      ];
    } else if (q.includes('summarize') || q.includes('performance') || q.includes('brief')) {
      replyText =
        `Here is the executive summary for **${organization.name}** (FY 2024):\n\n• **Overall ESG Score**: **78/100** (+2.4 points QoQ).\n• **Environmental Pillar**: **82/100** with 32% renewable mix and 68% recycling rate.\n• **Social Pillar**: **74/100** with zero lost-time injury incidents and 42% leadership diversity.\n• **Governance Pillar**: **79/100** with 67% independent board representation.\n• **Compliance**: 85% on-track across BRSR and SEC climate mandates.`;
      actionLinks = [
        { label: 'Generate Full ESG PDF Report', action: 'report', icon: 'BarChart2' },
        { label: 'Explore Compliance Gap Matrix', action: 'compliance', icon: 'ShieldCheck' }
      ];
    } else if (q.includes('reduce') || q.includes('energy') || q.includes('save')) {
      replyText =
        'To reduce corporate energy consumption by an estimated **12-16% by Q4**, our AI recommendations are:\n\n1. **HVAC Optimization in Facility B**: Calibrate chilled water setpoints and schedule auto-setbacks during non-operational shifts.\n2. **Rooftop Solar Maintenance**: Complete solar PV inverter firmware patch at Global HQ to restore 100% capacity factor.\n3. **Power Factor Correction**: Install automatic capacitor banks in Plant A to reduce reactive load penalty.';
      cards = [
        {
          title: 'EST. ENERGY SAVINGS',
          value: '280 MWh/mo',
          changeBadge: '↓ 14%',
          changeBadgeType: 'decrease-good' as const,
          colorBar: 'bg-emerald-600',
          iconType: 'Zap'
        },
        {
          title: 'EST. CO2 AVOIDANCE',
          value: '126 tCO2e',
          changeBadge: '↓ 126t',
          changeBadgeType: 'decrease-good' as const,
          colorBar: 'bg-blue-600',
          iconType: 'Leaf'
        }
      ];
    } else {
      replyText =
        `I analyzed your ESG records for **${organization.name}**. Current total carbon footprint is **12,450 tCO2e** across 4 operational facilities. Scope 1 direct emissions account for 33%, while Scope 2 indirect emissions represent 67%. Would you like me to model decarbonization pathways or draft disclosure notes?`;
      actionLinks = [
        { label: 'View Carbon Accounting Engine', action: 'carbon-analytics', icon: 'BarChart2' },
        { label: 'Audit Raw Facility Meters', action: 'data-management', icon: 'Building' }
      ];
    }

    setTimeout(() => {
      const botMsg: CopilotMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        cards,
        actionLinks
      };
      setMessages((prev) => [...prev, botMsg]);
    }, 400);
  };

  const handleActionClick = (action: string) => {
    if (action === 'report') {
      onOpenReportModal();
    } else if (action === 'compliance') {
      onNavigateTab('compliance');
    } else if (action === 'carbon-analytics') {
      onNavigateTab('carbon-analytics');
    } else if (action === 'data-management') {
      onNavigateTab('data-management');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pb-12">
      {/* Left Chat Area (8 Cols) matching Image 7 */}
      <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[760px] overflow-hidden">
        {/* Chat Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-100 text-[#064e3b] flex items-center justify-center border border-slate-200">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-slate-900 text-base">
                  Sustainability Assistant
                </h2>
                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  AI CO-PILOT
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Context: Q3 Corporate Emissions Data
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const logText = messages.map((m) => `${m.role.toUpperCase()} (${m.timestamp}):\n${m.content}`).join('\n\n');
                const blob = new Blob([logText], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `ESG_Copilot_Chat_${new Date().toISOString().slice(0, 10)}.txt`;
                a.click();
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export Log</span>
            </button>

            <button
              onClick={() => setMessages([])}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-red-50 border border-slate-200 text-red-600 text-xs font-semibold rounded-lg shadow-xs transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          </div>
        </div>

        {/* Chat Thread Messages */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-slate-50/40">
          {messages.length === 0 && (
            <div className="text-center py-20 text-slate-400">
              <Bot className="w-12 h-12 mx-auto text-slate-300 mb-3" />
              <p className="font-semibold text-slate-600">How can I assist your sustainability team today?</p>
              <p className="text-xs text-slate-400 mt-1">
                Select a suggested query from the right or type a custom question below.
              </p>
            </div>
          )}

          {messages.map((msg, index) => (
            <div key={msg.id || index} className="space-y-3">
              {/* Date Header for initial turn */}
              {index === 0 && (
                <div className="text-center">
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider bg-slate-100 px-3 py-1 rounded-full">
                    {msg.timestamp || 'TODAY, 10:42 AM'}
                  </span>
                </div>
              )}

              {msg.role === 'user' ? (
                /* User Message Bubble matching Image 7 */
                <div className="flex justify-end">
                  <div className="bg-[#e5e7eb] text-slate-900 rounded-2xl rounded-tr-xs px-5 py-3 text-sm max-w-lg font-medium shadow-xs">
                    {msg.content}
                  </div>
                </div>
              ) : (
                /* Assistant Message Bubble with Cards matching Image 7 */
                <div className="flex items-start gap-3 max-w-2xl">
                  <div className="w-8 h-8 rounded-full bg-[#1e293b] text-white flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-4 h-4" />
                  </div>

                  <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-xs p-5 shadow-sm space-y-4 flex-1">
                    {/* Bot Markdown/Text */}
                    <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-line">
                      {msg.content.split('**').map((part, i) =>
                        i % 2 === 1 ? (
                          <strong key={i} className="font-bold text-slate-950">
                            {part}
                          </strong>
                        ) : (
                          part
                        )
                      )}
                    </div>

                    {/* Embedded Structured Metric Cards matching Image 7 */}
                    {msg.cards && msg.cards.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                        {msg.cards.map((card, cIdx) => (
                          <div
                            key={cIdx}
                            className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex flex-col justify-between"
                          >
                            <div className="flex items-center justify-between text-[11px] font-bold text-slate-500 tracking-wider uppercase">
                              <span>{card.title}</span>
                              {card.iconType === 'Zap' ? (
                                <Zap className="w-3.5 h-3.5 text-slate-400" />
                              ) : (
                                <Sun className="w-3.5 h-3.5 text-slate-400" />
                              )}
                            </div>

                            <div className="flex items-baseline gap-2 my-2">
                              <span className="text-2xl font-extrabold text-slate-900 tracking-tight">
                                {card.value}
                              </span>
                              <span
                                className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                                  card.changeBadgeType === 'increase-bad'
                                    ? 'bg-red-50 text-red-700'
                                    : 'bg-emerald-50 text-emerald-700'
                                }`}
                              >
                                {card.changeBadge}
                              </span>
                            </div>

                            {/* Bottom colored bar matching Image 7 */}
                            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${card.colorBar}`}
                                style={{ width: card.title.includes('ELEC') ? '80%' : '68%' }}
                              ></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Action Links matching Image 7 */}
                    {msg.actionLinks && msg.actionLinks.length > 0 && (
                      <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-slate-100">
                        {msg.actionLinks.map((link, lIdx) => (
                          <button
                            key={lIdx}
                            onClick={() => handleActionClick(link.action)}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1e3a8a] hover:text-[#172554] hover:underline"
                          >
                            {link.icon === 'BarChart2' ? (
                              <BarChart2 className="w-3.5 h-3.5" />
                            ) : (
                              <Users className="w-3.5 h-3.5" />
                            )}
                            <span>{link.label}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-start gap-3 max-w-md animate-pulse">
              <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm text-xs text-slate-500 font-medium">
                Synthesizing multi-facility emissions telemetry...
              </div>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Chat Input Area matching Image 7 */}
        <div className="p-4 bg-white border-t border-slate-200 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl p-1.5 focus-within:ring-2 focus-within:ring-[#064e3b] focus-within:bg-white transition-all"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about your emissions, compliance, or ESG data..."
              className="flex-1 bg-transparent px-4 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none"
            />

            <button
              type="button"
              onClick={() => onNavigateTab('data-management')}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-200/60 transition-colors"
              title="Attach Document for OCR Intelligence"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="p-2.5 bg-[#064e3b] hover:bg-[#043c2e] disabled:opacity-40 text-white rounded-xl shadow-xs transition-all active:scale-95"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* AI Disclaimer Footer matching Image 7 */}
          <p className="text-[11px] text-slate-400 text-center mt-2.5">
            AI-generated insights may require manual verification against primary data sources.
          </p>
        </div>
      </div>

      {/* Right Column: Suggested Queries + Active Data Sources matching Image 7 */}
      <div className="lg:col-span-4 space-y-6">
        {/* Suggested Queries Card matching Image 7 */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center gap-2 mb-1">
            <Lightbulb className="w-4 h-4 text-slate-700" />
            <h3 className="font-bold text-slate-900 text-base">Suggested Queries</h3>
          </div>
          <p className="text-xs text-slate-500 mb-4">
            Based on recent data uploads and compliance deadlines.
          </p>

          <div className="space-y-3">
            {suggestedQueries.map((query, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(query.title)}
                className="w-full text-left p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 transition-all group"
              >
                <p className="text-xs font-semibold text-slate-900 group-hover:text-[#064e3b] transition-colors leading-snug">
                  {query.title}
                </p>
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1.5 font-medium">
                  <span>↗</span>
                  <span>{query.tag}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* ACTIVE DATA SOURCES Card matching Image 7 */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
          <h4 className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-4">
            ACTIVE DATA SOURCES
          </h4>

          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-700">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>ERP Integration Sync</span>
              </div>
              <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
                Connected
              </span>
            </div>

            <div className="flex items-center justify-between text-xs font-medium text-slate-700">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Facility Smart Meters</span>
              </div>
              <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-semibold">
                4 Active
              </span>
            </div>

            <div className="flex items-center justify-between text-xs font-medium text-slate-700">
              <div className="flex items-center gap-2.5">
                <RefreshCw className="w-4 h-4 text-slate-400 animate-spin" />
                <span>Supply Chain API</span>
              </div>
              <span className="text-[11px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-semibold">
                Updating
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
