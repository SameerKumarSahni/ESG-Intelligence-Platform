export type NavigationTab =
  | 'executive-dashboard'
  | 'carbon-analytics'
  | 'compliance-tracking'
  | 'ai-report-gen'
  | 'sustainability-copilot';

export type PillarType = 'Environmental' | 'Social' | 'Governance';

export type ComplianceStatus = 'Missing' | 'Overdue' | 'Pending' | 'Under Review' | 'Complete';

export interface ComplianceItem {
  id: string;
  title: string;
  subtitle: string;
  status: ComplianceStatus;
  deadline: string;
  pillar: PillarType;
  actionLabel?: string;
  actionType: 'upload' | 'resolve' | 'view' | 'download';
  icon: string;
  evidenceFile?: string;
  resolvedAt?: string;
  details?: string;
}

export interface DataWidget {
  title: string;
  metric: string;
  comparison: string;
  description: string;
  type: 'emission' | 'water' | 'energy' | 'social' | 'governance';
  icon: string;
}

export interface Recommendation {
  title: string;
  description: string;
  icon: string;
  highlight?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  dataWidgets?: DataWidget[];
  recommendations?: Recommendation[];
  quickSuggestions?: string[];
  isStreaming?: boolean;
}

export interface ReportConfig {
  framework: 'BRSR' | 'GRI' | 'CSRD' | 'SEC' | 'SASB' | 'TCFD';
  fiscalYear: string;
  region: string;
  includeScope3: boolean;
  materialityFocus: string[];
  customNotes?: string;
}

export interface GeneratedReport {
  id: string;
  title: string;
  framework: string;
  fiscalYear: string;
  createdAt: string;
  author: string;
  status: 'Ready' | 'Generating' | 'Draft';
  executiveSummary: string;
  overallScore: number;
  scores: {
    environmental: number;
    social: number;
    governance: number;
  };
  emissions: {
    total: number;
    scope1: number;
    scope2: number;
    scope3: number;
  };
  keyFindings: string[];
  recommendations: string[];
  fullContentMarkdown: string;
}

export interface GlobalMetric {
  id: string;
  region: string;
  country: string;
  esgScore: number;
  carbonIntensity: number; // tCO2e / $M
  renewableEnergyPercent: number;
  complianceRate: number;
  trend: 'up' | 'down' | 'neutral';
}

export interface Announcement {
  id: string;
  title: string;
  date: string;
  category: 'Regulatory' | 'Audit' | 'Platform' | 'Target';
  priority: 'high' | 'medium' | 'low';
  summary: string;
  read: boolean;
}
