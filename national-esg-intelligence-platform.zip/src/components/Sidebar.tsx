import React from 'react';
import { NavigationTab } from '../types';

interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenNewReport: () => void;
  onOpenSettings: () => void;
  onOpenSupport: () => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenNewReport,
  onOpenSettings,
  onOpenSupport,
  isOpenMobile,
  onCloseMobile,
}) => {
  const navItems: Array<{ id: NavigationTab; label: string; icon: string }> = [
    { id: 'executive-dashboard', label: 'Executive Dashboard', icon: 'dashboard' },
    { id: 'carbon-analytics', label: 'Carbon Analytics', icon: 'monitoring' },
    { id: 'compliance-tracking', label: 'Compliance Tracking', icon: 'fact_check' },
    { id: 'ai-report-gen', label: 'AI Report Gen', icon: 'description' },
    { id: 'sustainability-copilot', label: 'Sustainability Copilot', icon: 'smart_toy' },
  ];

  const handleNavClick = (tabId: NavigationTab) => {
    onSelectTab(tabId);
    if (isOpenMobile) onCloseMobile();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          id="sidebar-mobile-backdrop"
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/50 z-30 md:hidden backdrop-blur-xs transition-opacity"
        />
      )}

      {/* Main Sidebar */}
      <aside
        id="app-sidebar"
        className={`fixed left-0 top-0 h-full w-[280px] bg-[#003527] text-[#b0f0d6] font-['Inter',sans-serif] shadow-xl z-40 flex flex-col py-6 transition-transform duration-300 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="px-6 mb-6 flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-md bg-[#064e3b] p-1 flex items-center justify-center shrink-0 border border-[#b0f0d6]/20 shadow-inner">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuDa32XsbOBXsZ1cciLo7_poWYAj7xFt_E9jCaxG6d08XTU0U1fohKbuXs5N1RIM5O8xdJDBk1unK6s8_4D4sXf7Kd7xNEYgC30aL8ZJp24sZnmSCDL2puF046eEOrsRQYLt8yyeGQ9ASCfoz_OMPzjdrxedVRgOFdyy2_e6z9qISLrki2kl6B84XWTbRo7F_PkNYMh8-Xpb2ra_SIFdfrQrAvFn_3bnyaipadZNz0v7cmGRetLfu_tpBA"
              alt="ESG Intelligence Logo"
              className="w-full h-full object-contain rounded-xs"
            />
          </div>
          <div>
            <h1 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-white tracking-tight leading-snug">
              ESG Intelligence
            </h1>
            <p className="text-[12px] font-medium text-[#95d3ba]/80 tracking-wide">
              Sustainability Platform
            </p>
          </div>
        </div>

        {/* Generate Report Quick Button */}
        <div className="px-5 mb-6">
          <button
            id="sidebar-generate-report-btn"
            onClick={onOpenNewReport}
            className="w-full bg-[#b0f0d6] text-[#002117] font-semibold text-[13px] py-2.5 px-4 rounded-lg hover:bg-[#95d3ba] transition-all duration-150 shadow-sm flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
          >
            <span className="material-symbols-outlined text-[18px]">add</span>
            <span>Generate Report</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex-1 px-3 space-y-1.5 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-3.5 py-3 px-4 rounded-lg text-[14.5px] transition-all duration-150 text-left cursor-pointer ${
                  isActive
                    ? 'text-[#95d3ba] font-semibold border-l-4 border-[#95d3ba] bg-[#064e3b]/60 pl-3.5 shadow-sm'
                    : 'text-white/75 hover:text-white hover:bg-[#064e3b]/30 font-medium'
                }`}
              >
                <span
                  className={`material-symbols-outlined text-[21px] ${
                    isActive ? 'fill' : ''
                  }`}
                >
                  {item.icon}
                </span>
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer Actions */}
        <div className="px-5 mt-auto pt-4 border-t border-white/10 space-y-1">
          <button
            id="sidebar-settings-btn"
            onClick={onOpenSettings}
            className="w-full flex items-center gap-3 py-2 px-3 text-white/75 hover:text-white hover:bg-[#064e3b]/30 rounded-md text-[13.5px] transition-colors text-left cursor-pointer"
          >
            <span className="material-symbols-outlined text-[19px]">settings</span>
            <span>Settings</span>
          </button>
          <button
            id="sidebar-support-btn"
            onClick={onOpenSupport}
            className="w-full flex items-center gap-3 py-2 px-3 text-white/75 hover:text-white hover:bg-[#064e3b]/30 rounded-md text-[13.5px] transition-colors text-left cursor-pointer"
          >
            <span className="material-symbols-outlined text-[19px]">help</span>
            <span>Support</span>
          </button>
        </div>
      </aside>
    </>
  );
};
