import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { LandingPage } from './components/LandingPage';
import { DashboardView } from './components/DashboardView';
import { CarbonAnalyticsView } from './components/CarbonAnalyticsView';
import { AiCopilotView } from './components/AiCopilotView';
import { ComplianceView } from './components/ComplianceView';
import { DataManagementView } from './components/DataManagementView';
import { SettingsModal } from './components/modals/SettingsModal';
import { GenerateReportModal } from './components/modals/GenerateReportModal';
import { AddRecordModal } from './components/modals/AddRecordModal';
import { BulkUploadModal } from './components/modals/BulkUploadModal';
import { EvidenceModal } from './components/modals/EvidenceModal';
import {
  ActiveTab,
  OrganizationInfo,
  ComplianceItem,
  DataRecord
} from './types/esg';
import {
  initialOrganization,
  initialDataRecords
} from './data/mockData';

export function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [organization, setOrganization] = useState<OrganizationInfo>(initialOrganization);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals state
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isAddRecordModalOpen, setIsAddRecordModalOpen] = useState(false);
  const [isBulkUploadModalOpen, setIsBulkUploadModalOpen] = useState(false);
  const [evidenceItem, setEvidenceItem] = useState<ComplianceItem | null>(null);

  // Notifications or toast alerts
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleAddRecord = (record: DataRecord) => {
    showToast(`Added new record: ${record.indicator} (${record.value.toLocaleString()} ${record.unit})`);
  };

  const handleBulkIngest = (newRecords: DataRecord[]) => {
    showToast(`Successfully ingested ${newRecords.length} records from batch file.`);
  };

  const handleExportData = () => {
    const csvContent = "data:text/csv;charset=utf-8,Indicator,Value,Unit,Facility,Category,Status\n" +
      "Electricity Consumption,142500,kWh,Plant A (North),Environmental,VERIFIED\n" +
      "Water Usage,8240,m3,Plant B (South),Environmental,DRAFT\n" +
      "Natural Gas Consumption,14300,m3,Manufacturing Facility A,Environmental,VERIFIED\n" +
      "Solar Generation,45200,kWh,Global HQ,Environmental,VERIFIED\n";
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `ESG_Ledger_Export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("ESG Ledger exported as CSV file.");
  };

  const handleEscalate = (item: ComplianceItem) => {
    showToast(`Escalation notification dispatched to Chief Environmental Officer for ${item.name}.`);
  };

  // If user is on the Public Landing page (Image 1)
  if (activeTab === 'landing') {
    return (
      <div className="min-h-screen bg-white">
        <LandingPage
          onEnterDashboard={() => setActiveTab('dashboard')}
          onExploreCapabilities={() => setActiveTab('carbon-analytics')}
        />
        {/* Quick Return Floating Bar */}
        <div className="fixed bottom-4 right-4 z-50">
          <button
            onClick={() => setActiveTab('dashboard')}
            className="px-5 py-2.5 bg-[#064e3b] hover:bg-[#043c2e] text-white text-xs font-bold rounded-full shadow-2xl transition-transform hover:scale-105 active:scale-95 flex items-center gap-2"
          >
            <span>Open Institutional Dashboard</span>
            <span>→</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 flex font-sans antialiased">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-2xl border border-slate-800 animate-in fade-in slide-in-from-top-3 flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onGoToLanding={() => setActiveTab('landing')}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        {/* Top Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          organization={organization}
          onOpenReportModal={() => setIsReportModalOpen(true)}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* Scrollable View Content */}
        <main className="flex-1 p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              organization={organization}
              setActiveTab={setActiveTab}
              onOpenReportModal={() => setIsReportModalOpen(true)}
              onDrillDownFacilityB={() => setActiveTab('ai-copilot')}
            />
          )}

          {activeTab === 'data-management' && (
            <DataManagementView
              organization={organization}
              onOpenAddModal={() => setIsAddRecordModalOpen(true)}
              onOpenBulkUploadModal={() => setIsBulkUploadModalOpen(true)}
              onExportRecords={handleExportData}
            />
          )}

          {activeTab === 'carbon-analytics' && (
            <CarbonAnalyticsView onExportData={handleExportData} />
          )}

          {activeTab === 'ai-copilot' && (
            <AiCopilotView
              organization={organization}
              onOpenReportModal={() => setIsReportModalOpen(true)}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'compliance' && (
            <ComplianceView
              onViewEvidence={(item) => setEvidenceItem(item)}
              onUploadEvidence={(item) => setIsBulkUploadModalOpen(true)}
              onEscalate={handleEscalate}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsModal
              organization={organization}
              onUpdateOrg={(updated) => {
                setOrganization(updated);
                showToast("Organization configuration updated.");
              }}
              onClose={() => setActiveTab('dashboard')}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <GenerateReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        organization={organization}
      />

      <AddRecordModal
        isOpen={isAddRecordModalOpen}
        onClose={() => setIsAddRecordModalOpen(false)}
        onAddRecord={handleAddRecord}
      />

      <BulkUploadModal
        isOpen={isBulkUploadModalOpen}
        onClose={() => setIsBulkUploadModalOpen(false)}
        onBulkIngest={handleBulkIngest}
      />

      <EvidenceModal
        item={evidenceItem}
        isOpen={Boolean(evidenceItem)}
        onClose={() => setEvidenceItem(null)}
      />
    </div>
  );
}
export default App;
