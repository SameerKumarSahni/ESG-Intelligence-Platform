import React, { useState } from 'react';

interface CarbonAnalyticsViewProps {
  onAskCopilot: (prompt: string) => void;
}

export const CarbonAnalyticsView: React.FC<CarbonAnalyticsViewProps> = ({ onAskCopilot }) => {
  const [fiscalYear, setFiscalYear] = useState<'FY 2024' | 'FY 2023'>('FY 2024');
  const [identifyTrends, setIdentifyTrends] = useState(true);
  const [activeSegment, setActiveSegment] = useState<string | null>(null);
  const [hoveredMonth, setHoveredMonth] = useState<string | null>(null);

  const monthlyData = [
    { month: 'Jan', current: 2.4, previous: 2.1, isOverTarget: false },
    { month: 'Feb', current: 2.2, previous: 2.0, isOverTarget: false },
    { month: 'Mar', current: 2.6, previous: 2.3, isOverTarget: false },
    { month: 'Apr', current: 3.1, previous: 2.5, isOverTarget: true }, // Over Target limit 2.8k
    { month: 'May', current: 2.0, previous: 1.9, isOverTarget: false },
    { month: 'Jun', current: 1.8, previous: 1.7, isOverTarget: false },
  ];

  const emissionSources = [
    { name: 'Electricity', percent: 35, color: '#003527', strokeDash: '88 251', offset: 0, detail: '15,000 tCO2e across 4 global regional grids' },
    { name: 'Transport', percent: 25, color: '#53c2b5', strokeDash: '63 251', offset: -88, detail: '10,710 tCO2e logistics fleet & freight' },
    { name: 'Heating', percent: 20, color: '#8fa7fe', strokeDash: '50 251', offset: -151, detail: '8,570 tCO2e onsite natural gas boilers' },
    { name: 'Other', percent: 20, color: '#bfc9c3', strokeDash: '50 251', offset: -201, detail: '8,570 tCO2e packaging & refrigerant loss' },
  ];

  return (
    <div id="carbon-analytics-container" className="max-w-[1440px] mx-auto space-y-8 pb-20">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-[#707974] mb-2 text-[12px]">
            <span className="material-symbols-outlined text-[16px]">home</span>
            <span>/</span>
            <span className="font-semibold text-[#191c1e]">Carbon Analytics</span>
          </div>
          <h2 className="font-['Montserrat',sans-serif] text-[32px] sm:text-[40px] font-bold text-[#191c1e] tracking-tight leading-tight">
            Carbon Analytics
          </h2>
          <p className="text-[15px] sm:text-[16.5px] text-[#404944] mt-2 max-w-2xl">
            Detailed breakdown of <span className="font-semibold text-[#003527]">estimated emissions</span> across Scope 1, 2, and 3 to support informed reduction strategies.
          </p>
        </div>

        {/* Year Selector */}
        <div className="flex items-center gap-2 bg-[#f2f4f6] p-1 rounded-lg border border-[#bfc9c3]/40">
          {(['FY 2024', 'FY 2023'] as const).map((fy) => (
            <button
              key={fy}
              id={`fy-selector-${fy.toLowerCase().replace(' ', '-')}`}
              onClick={() => setFiscalYear(fy)}
              className={`px-4 py-1.5 rounded-md text-[13px] font-semibold transition-all cursor-pointer ${
                fiscalYear === fy
                  ? 'bg-white text-[#003527] shadow-xs border border-[#bfc9c3]/30'
                  : 'text-[#404944] hover:text-[#003527]'
              }`}
            >
              {fy}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Bento Grid Row 1 (Scopes) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Total Emissions Card (Col Span 4) */}
        <div
          id="total-emissions-card"
          className="md:col-span-4 bg-white rounded-xl border border-[#bfc9c3]/35 p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] relative overflow-hidden group hover:shadow-md transition-shadow"
        >
          <div className="absolute top-2 right-2 p-2 opacity-10 group-hover:opacity-20 transition-opacity pointer-events-none">
            <span className="material-symbols-outlined text-[80px] text-[#003527]">co2</span>
          </div>
          <div className="flex justify-between items-start mb-4 relative z-10">
            <h3 className="text-[12px] font-bold text-[#404944] uppercase tracking-wider flex items-center gap-1">
              Total Est. Emissions
              <span
                className="material-symbols-outlined text-[15px] text-[#707974] cursor-help"
                title="Total estimated CO2e across all operational and supply chain scopes."
              >
                info
              </span>
            </h3>
          </div>
          <div className="flex items-baseline gap-2 mb-3 relative z-10">
            <span className="font-['Montserrat',sans-serif] text-[36px] font-bold text-[#003527] tracking-tight">
              42,850
            </span>
            <span className="text-[14px] text-[#404944] font-medium">tCO₂e</span>
          </div>
          <div className="flex items-center gap-2 relative z-10">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#ffdad6] text-[#ba1a1a] text-[12px] font-bold">
              <span className="material-symbols-outlined text-[14px]">trending_up</span> +4.2%
            </span>
            <span className="text-[12px] text-[#707974]">vs prior year</span>
          </div>
        </div>

        {/* Scope 1 Direct (Col Span 2) */}
        <div
          id="scope-1-card"
          className="md:col-span-2 bg-white rounded-xl border border-[#bfc9c3]/35 p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div>
            <h3 className="text-[11.5px] font-bold text-[#404944] uppercase tracking-wider mb-2">
              Scope 1 (Direct)
            </h3>
            <div className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              12,400 <span className="text-[12px] text-[#707974] font-normal">tCO₂e</span>
            </div>
          </div>
          <div className="w-full bg-[#eceef0] h-2 rounded-full mt-4 overflow-hidden">
            <div className="bg-[#6bd8cb] h-full rounded-full w-[30%]" />
          </div>
        </div>

        {/* Scope 2 Indirect (Col Span 2) */}
        <div
          id="scope-2-card"
          className="md:col-span-2 bg-white rounded-xl border border-[#bfc9c3]/35 p-5 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-md transition-shadow"
        >
          <div>
            <h3 className="text-[11.5px] font-bold text-[#404944] uppercase tracking-wider mb-2">
              Scope 2 (Indirect)
            </h3>
            <div className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              8,950 <span className="text-[12px] text-[#707974] font-normal">tCO₂e</span>
            </div>
          </div>
          <div className="w-full bg-[#eceef0] h-2 rounded-full mt-4 overflow-hidden">
            <div className="bg-[#8fa7fe] h-full rounded-full w-[20%]" />
          </div>
        </div>

        {/* Scope 3 Value Chain (Col Span 4) */}
        <div
          id="scope-3-card"
          className="md:col-span-4 bg-[#003527] text-white rounded-xl p-6 shadow-[0px_8px_24px_rgba(0,53,39,0.15)] flex flex-col justify-between relative overflow-hidden group"
        >
          {/* Stipple Background Pattern */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
              backgroundSize: '14px 14px',
            }}
          />
          <div className="relative z-10 flex justify-between items-start">
            <h3 className="text-[12px] font-bold text-[#b0f0d6] uppercase tracking-wider mb-1">
              Scope 3 (Value Chain)
            </h3>
            <span className="material-symbols-outlined text-[#95d3ba] text-[20px]">warning</span>
          </div>
          <div className="relative z-10 mt-1">
            <div className="font-['Montserrat',sans-serif] text-[30px] font-bold text-white leading-tight">
              21,500 <span className="text-[14px] font-normal text-[#95d3ba]">tCO₂e</span>
            </div>
            <p className="text-[12px] text-[#b0f0d6]/90 mt-1 leading-relaxed">
              Represents 50.1% of total footprint. Major driver: Supply Chain.
            </p>
          </div>
          <div className="w-full bg-[#064e3b] h-2 rounded-full mt-4 overflow-hidden relative z-10">
            <div className="bg-[#b0f0d6] h-full rounded-full w-[50%]" />
          </div>
        </div>
      </div>

      {/* Analytics Main Section */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Emissions by Source (Donut Chart area) - Col Span 4 */}
        <div
          id="emissions-sources-card"
          className="md:col-span-4 bg-white rounded-xl border border-[#bfc9c3]/35 p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
              Emission Sources
            </h3>
            <button
              onClick={() => onAskCopilot('Analyze our top emission sources and suggest reduction pathways')}
              className="text-[#707974] hover:text-[#003527] p-1 rounded-md"
              title="Copilot Deep Dive"
            >
              <span className="material-symbols-outlined text-[20px]">more_vert</span>
            </button>
          </div>

          {/* Donut Chart SVG */}
          <div className="flex-1 flex flex-col items-center justify-center relative min-h-[240px]">
            <svg className="w-full h-full max-w-[200px] max-h-[200px] transform -rotate-90" viewBox="0 0 100 100">
              {/* Background ring */}
              <circle cx="50" cy="50" fill="none" r="40" stroke="#f2f4f6" strokeWidth="12" />

              {/* Segments */}
              {emissionSources.map((s) => (
                <circle
                  key={s.name}
                  className="cursor-pointer transition-all duration-300 hover:stroke-[15]"
                  cx="50"
                  cy="50"
                  fill="none"
                  r="40"
                  stroke={s.color}
                  strokeDasharray={s.strokeDash}
                  strokeDashoffset={s.offset}
                  strokeWidth={activeSegment === s.name ? 15 : 12}
                  onMouseEnter={() => setActiveSegment(s.name)}
                  onMouseLeave={() => setActiveSegment(null)}
                />
              ))}
            </svg>

            {/* Center Text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-[10px] text-[#707974] uppercase font-bold tracking-wider">
                {activeSegment ? activeSegment : 'Total Est.'}
              </span>
              <span className="font-['Montserrat',sans-serif] text-[22px] font-bold text-[#191c1e]">
                {activeSegment
                  ? `${emissionSources.find((s) => s.name === activeSegment)?.percent}%`
                  : '42.8k'}
              </span>
            </div>
          </div>

          {/* Legend */}
          <div className="mt-4 grid grid-cols-2 gap-3">
            {emissionSources.map((s) => (
              <div
                key={s.name}
                onMouseEnter={() => setActiveSegment(s.name)}
                onMouseLeave={() => setActiveSegment(null)}
                className={`flex items-center gap-2 text-[13px] p-1.5 rounded-md cursor-pointer transition-colors ${
                  activeSegment === s.name ? 'bg-[#f2f4f6]' : ''
                }`}
              >
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                <span className="text-[#404944] font-medium truncate">
                  {s.name} ({s.percent}%)
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Trend Bar Chart & Controls - Col Span 8 */}
        <div
          id="emissions-vs-target-card"
          className="md:col-span-8 bg-white rounded-xl border border-[#bfc9c3]/35 p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.03)] flex flex-col justify-between"
        >
          {/* Controls Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
                Emissions vs. Target
              </h3>
              <p className="text-[13px] text-[#707974] mt-0.5">
                Monthly estimated breakdown against reduction goals.
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Toggle Switch */}
              <label className="flex items-center cursor-pointer select-none">
                <div className="relative">
                  <input
                    type="checkbox"
                    checked={identifyTrends}
                    onChange={(e) => setIdentifyTrends(e.target.checked)}
                    className="sr-only"
                  />
                  <div
                    className={`block w-10 h-6 rounded-full border transition-colors ${
                      identifyTrends ? 'bg-[#003527]' : 'bg-[#e0e3e5]'
                    }`}
                  />
                  <div
                    className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${
                      identifyTrends ? 'translate-x-4' : 'translate-x-0'
                    }`}
                  />
                </div>
                <span className="ml-2.5 text-[13px] font-semibold text-[#404944]">
                  Identify Trends
                </span>
              </label>

              {/* Action Button */}
              <button
                id="identify-major-sources-btn"
                onClick={() =>
                  onAskCopilot('Identify major sources causing the April emission spike above target limit')
                }
                className="flex items-center gap-1.5 border border-[#4059aa] text-[#4059aa] px-3.5 py-1.5 rounded-lg text-[13px] font-semibold hover:bg-[#4059aa]/5 transition-colors cursor-pointer"
              >
                <span className="material-symbols-outlined text-[17px]">search_insights</span>
                <span>Identify Major Sources</span>
              </button>
            </div>
          </div>

          {/* Bar Chart Area */}
          <div className="flex-1 w-full relative min-h-[240px] flex items-end justify-between px-2 gap-2 pb-6 border-b border-[#e0e3e5]">
            {/* Y Axis Labels */}
            <div className="absolute left-0 top-0 bottom-6 w-10 flex flex-col justify-between text-[11px] text-[#707974] border-r border-[#e0e3e5] pr-2 pb-1">
              <span>4k</span>
              <span>3k</span>
              <span>2k</span>
              <span>1k</span>
              <span>0</span>
            </div>

            {/* Target Line (2.8k/mo) */}
            <div className="absolute left-10 right-0 top-[30%] border-t-2 border-dashed border-[#ba1a1a]/50 z-10 pointer-events-none">
              <span className="absolute -top-5 right-2 text-[11.5px] text-[#ba1a1a] font-semibold bg-white/90 px-1.5 rounded">
                Target Limit (2.8k/mo)
              </span>
            </div>

            {/* Bars (Jan - Jun) */}
            <div className="ml-10 flex-1 flex items-end justify-around h-full relative z-20">
              {monthlyData.map((m) => {
                const heightPercent = (m.current / 4) * 100;
                const prevHeightPercent = (m.previous / 4) * 100;

                return (
                  <div
                    key={m.month}
                    onMouseEnter={() => setHoveredMonth(m.month)}
                    onMouseLeave={() => setHoveredMonth(null)}
                    className="flex flex-col items-center w-full max-w-[44px] group relative cursor-pointer"
                  >
                    {/* Tooltip on hover */}
                    {hoveredMonth === m.month && (
                      <div className="absolute -top-12 z-30 bg-[#191c1e] text-white text-[11px] py-1 px-2.5 rounded shadow-lg whitespace-nowrap">
                        <p className="font-bold">{m.month}: {m.current}k tCO2e</p>
                        <p className="text-[#95d3ba]">Prev: {m.previous}k tCO2e</p>
                      </div>
                    )}

                    {/* Previous Year Bar */}
                    <div
                      className="w-full bg-[#003527]/20 rounded-t-xs mb-1 group-hover:bg-[#003527]/30 transition-colors"
                      style={{ height: `${prevHeightPercent}%` }}
                    />

                    {/* Current Year Bar */}
                    <div
                      className={`w-full rounded-t-xs transition-opacity ${
                        m.isOverTarget
                          ? 'bg-[#ba1a1a] shadow-xs'
                          : 'bg-[#003527] group-hover:opacity-90'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />

                    <span
                      className={`absolute -bottom-6 text-[12px] font-semibold ${
                        m.month === 'Jun'
                          ? 'text-[#003527] font-bold'
                          : 'text-[#404944]'
                      }`}
                    >
                      {m.month}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Chart Legend */}
          <div className="mt-8 flex justify-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-3.5 h-3.5 rounded-xs bg-[#003527]" />
              <span className="text-[12.5px] font-medium text-[#404944]">
                Current Year (Actuals)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3.5 h-3.5 rounded-xs bg-[#003527]/20 border border-[#003527]/20" />
              <span className="text-[12.5px] font-medium text-[#404944]">Previous Year</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
