import React, { useState } from 'react';
import { ReportConfig } from '../../types';

interface GenerateReportModalProps {
  onClose: () => void;
  onSubmitAndNavigate: (config: ReportConfig) => void;
}

export const GenerateReportModal: React.FC<GenerateReportModalProps> = ({
  onClose,
  onSubmitAndNavigate,
}) => {
  const [framework, setFramework] = useState<'BRSR' | 'GRI' | 'CSRD' | 'SEC' | 'SASB' | 'TCFD'>('BRSR');
  const [fiscalYear, setFiscalYear] = useState('FY 2024');
  const [region, setRegion] = useState('Global');
  const [includeScope3, setIncludeScope3] = useState(true);
  const [customNotes, setCustomNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitAndNavigate({
      framework,
      fiscalYear,
      region,
      includeScope3,
      materialityFocus: ['Carbon Footprint', 'Renewable Energy', 'Diversity & Inclusion'],
      customNotes,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#003527] text-[#b0f0d6] rounded-xl">
              <span className="material-symbols-outlined text-[24px]">description</span>
            </div>
            <div>
              <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e]">
                New ESG Report
              </h3>
              <p className="text-[13px] text-[#707974]">
                Configure AI automated synthesis across standards.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
              Standard / Framework
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['BRSR', 'GRI', 'CSRD', 'SEC', 'SASB', 'TCFD'] as const).map((fw) => (
                <button
                  key={fw}
                  type="button"
                  onClick={() => setFramework(fw)}
                  className={`py-2 px-3 text-[13px] font-semibold rounded-lg border transition-all cursor-pointer ${
                    framework === fw
                      ? 'bg-[#003527] text-white border-[#003527] shadow-xs'
                      : 'bg-[#f2f4f6] text-[#404944] border-transparent hover:border-[#bfc9c3]'
                  }`}
                >
                  {fw}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Fiscal Year
              </label>
              <select
                value={fiscalYear}
                onChange={(e) => setFiscalYear(e.target.value)}
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              >
                <option value="FY 2024">FY 2024</option>
                <option value="FY 2023">FY 2023</option>
                <option value="FY 2025 (Forecast)">FY 2025 (Forecast)</option>
              </select>
            </div>

            <div>
              <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
                Regional Scope
              </label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
              >
                <option value="Global">Global Operations</option>
                <option value="North America">North America</option>
                <option value="Western Europe">Western Europe</option>
                <option value="Asia Pacific">Asia Pacific</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#f7f9fb] rounded-xl border border-[#bfc9c3]/30">
            <span className="font-semibold text-[13px] text-[#191c1e]">
              Include Scope 3 Value Chain Calculations
            </span>
            <input
              type="checkbox"
              checked={includeScope3}
              onChange={(e) => setIncludeScope3(e.target.checked)}
              className="w-4 h-4 accent-[#003527] cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Custom Directives
            </label>
            <input
              type="text"
              value={customNotes}
              onChange={(e) => setCustomNotes(e.target.value)}
              placeholder="e.g. Include executive statement on net-zero 2040 roadmap"
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-[13px] font-bold bg-[#003527] text-[#b0f0d6] rounded-lg hover:bg-[#064e3b] transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">auto_awesome</span>
              <span>Open in Report Studio</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
