import React from 'react';
import {
  ArrowRight,
  BarChart3,
  Bot,
  Trees,
  Users,
  Landmark,
  CheckCircle2
} from 'lucide-react';

interface LandingPageProps {
  onEnterDashboard: () => void;
  onExploreCapabilities: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onEnterDashboard,
  onExploreCapabilities
}) => {
  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col justify-between selection:bg-emerald-100 selection:text-emerald-900 relative overflow-hidden">
      {/* Background Subtle Mesh / Constellation Graphic Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="meshGradient" cx="70%" cy="30%" r="60%">
              <stop offset="0%" stopColor="#e0f2fe" stopOpacity="0.8" />
              <stop offset="50%" stopColor="#f0fdf4" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="100%" height="100%" fill="url(#meshGradient)" />
          {/* Subtle node network lines */}
          <g stroke="#cbd5e1" strokeWidth="0.75" strokeDasharray="3 3" opacity="0.6">
            <line x1="10%" y1="20%" x2="35%" y2="35%" />
            <line x1="35%" y1="35%" x2="60%" y2="15%" />
            <line x1="60%" y1="15%" x2="85%" y2="40%" />
            <line x1="35%" y1="35%" x2="45%" y2="70%" />
            <line x1="60%" y1="15%" x2="80%" y2="65%" />
          </g>
          {/* Constellation dots */}
          <circle cx="10%" cy="20%" r="3" fill="#3b82f6" opacity="0.4" />
          <circle cx="35%" cy="35%" r="4" fill="#059669" opacity="0.5" />
          <circle cx="60%" cy="15%" r="3" fill="#6366f1" opacity="0.4" />
          <circle cx="85%" cy="40%" r="4" fill="#10b981" opacity="0.5" />
        </svg>
      </div>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-20 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column (Headline + CTAs) */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-4xl md:text-5xl lg:text-[52px] font-extrabold text-slate-950 tracking-tight leading-[1.15]">
              Empower Your Organization with{' '}
              <span className="text-[#3b5998] md:text-[#4338ca] bg-gradient-to-r from-blue-700 to-indigo-600 bg-clip-text text-transparent">
                AI-Driven
              </span>{' '}
              Sustainability Intelligence
            </h1>

            <p className="text-base md:text-lg text-slate-600 leading-relaxed max-w-xl">
              The National ESG & Sustainability Intelligence Platform provides
              institutional-grade analytics, seamless compliance tracking, and
              predictive insights to navigate the future of environmental
              stewardship.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onEnterDashboard}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#064e3b] hover:bg-[#043c2e] text-white rounded-lg font-medium text-sm transition-all shadow-sm hover:shadow active:scale-[0.98]"
              >
                <span>Access Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onExploreCapabilities}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-white hover:bg-slate-50 text-[#3b5998] border border-blue-200 rounded-lg font-medium text-sm transition-all shadow-sm active:scale-[0.98]"
              >
                <span>Explore Capabilities</span>
              </button>
            </div>
          </div>

          {/* Right Column (Carbon Projection Card) */}
          <div className="lg:col-span-5 relative">
            {/* Background Watermark */}
            <div className="absolute -top-12 -left-12 text-6xl md:text-7xl font-extrabold text-slate-200/40 select-none pointer-events-none -z-10 tracking-tight">
              ESG Intelligence
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-xl border border-slate-200/80">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
                <h3 className="font-bold text-slate-900 text-base">Carbon Projection</h3>
                <div className="p-1 rounded text-blue-600 bg-blue-50">
                  <BarChart3 className="w-4 h-4" />
                </div>
              </div>

              {/* Bar Chart Graphic matching screenshot */}
              <div className="bg-[#f0f4f1] rounded-xl p-4 mb-5 h-44 flex items-end justify-between gap-3">
                {/* 5 Stepped Descending Bars matching screenshot */}
                <div className="w-1/5 bg-[#52d398] rounded-t-sm h-[92%] transition-all hover:opacity-90"></div>
                <div className="w-1/5 bg-[#64ddab] rounded-t-sm h-[74%] transition-all hover:opacity-90"></div>
                <div className="w-1/5 bg-[#6ee7b7] rounded-t-sm h-[58%] transition-all hover:opacity-90"></div>
                <div className="w-1/5 bg-[#99f0ca] rounded-t-sm h-[38%] transition-all hover:opacity-90"></div>
                <div className="w-1/5 bg-[#a7f3d0] rounded-t-sm h-[24%] transition-all hover:opacity-90"></div>
              </div>

              {/* AI Insight Box matching Image 1 */}
              <div className="bg-[#eaf5ef] border border-[#c4e6d4] rounded-xl p-3.5 flex items-start gap-3">
                <div className="p-1.5 bg-[#d1fae5] rounded-lg text-[#065f46] shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
                <p className="text-xs text-[#064e3b] font-medium leading-relaxed">
                  <strong className="font-semibold">AI Insight:</strong> Projected 15% reduction in Scope 2 emissions based on current renewable energy procurement trends.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive ESG Framework Section */}
      <section className="bg-slate-50/70 border-t border-slate-200/80 py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight mb-2">
              Comprehensive ESG Framework
            </h2>
            <p className="text-sm md:text-base text-slate-600">
              Structured analysis across Environmental, Social, and Governance pillars for complete institutional oversight.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Environmental Card */}
            <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-11 h-11 rounded-xl bg-emerald-50 text-emerald-800 flex items-center justify-center mb-5">
                  <Trees className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Environmental</h3>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed mb-6">
                  Track carbon footprint, monitor energy consumption, and manage resource efficiency across your supply chain.
                </p>
              </div>
              <div className="space-y-2.5 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Carbon Analytics</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Energy Auditing</span>
                </div>
              </div>
            </div>

            {/* Social Card */}
            <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-11 h-11 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center mb-5">
                  <Users className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Social</h3>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed mb-6">
                  Ensure employee welfare, track diversity metrics, and measure community impact and engagement.
                </p>
              </div>
              <div className="space-y-2.5 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Employee Welfare</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Community Impact</span>
                </div>
              </div>
            </div>

            {/* Governance Card */}
            <div className="bg-white rounded-2xl p-7 border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
              <div>
                <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-800 flex items-center justify-center mb-5">
                  <Landmark className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Governance</h3>
                <p className="text-xs md:text-sm text-slate-600 leading-relaxed mb-6">
                  Maintain regulatory compliance, assess institutional risk, and ensure transparent corporate practices.
                </p>
              </div>
              <div className="space-y-2.5 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Compliance Tracking</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>Risk Assessment</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer matching Image 1 */}
      <footer className="border-t border-slate-200 py-6 px-6 bg-white text-xs text-slate-600">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="font-semibold text-slate-900">
            National ESG Intelligence Platform
          </div>

          <div className="flex items-center flex-wrap gap-6 font-medium text-slate-600">
            <button onClick={onExploreCapabilities} className="hover:text-slate-900 underline">Privacy Policy</button>
            <button onClick={onExploreCapabilities} className="hover:text-slate-900 underline">Terms of Service</button>
            <button onClick={onExploreCapabilities} className="hover:text-slate-900 underline">Security Disclosure</button>
            <button onClick={onExploreCapabilities} className="hover:text-slate-900 underline">Methodology</button>
          </div>

          <div className="text-slate-500">
            © 2024 National ESG Intelligence Platform. All Rights Reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};
