import React, { useState } from 'react';
import {
  Filter,
  UploadCloud,
  Download,
  Plus,
  FileText,
  CheckCircle2,
  AlertTriangle,
  X,
  Eye,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  Building,
  Check,
  Search,
  Maximize2
} from 'lucide-react';
import {
  DataRecord,
  EsgPillar,
  DocumentIntelligenceData,
  OrganizationInfo
} from '../types/esg';
import { initialDataRecords } from '../data/mockData';

interface DataManagementViewProps {
  organization: OrganizationInfo;
  onOpenAddModal: () => void;
  onOpenBulkUploadModal: () => void;
  onExportRecords: () => void;
}

export const DataManagementView: React.FC<DataManagementViewProps> = ({
  organization,
  onOpenAddModal,
  onOpenBulkUploadModal,
  onExportRecords
}) => {
  const [records, setRecords] = useState<DataRecord[]>(initialDataRecords);
  const [activePillar, setActivePillar] = useState<EsgPillar>('environmental');
  const [selectedIds, setSelectedIds] = useState<string[]>(['rec-001', 'rec-002']);
  const [searchFilter, setSearchFilter] = useState('');
  
  // Document Intelligence Drawer State matching Image 11
  const [docDrawer, setDocDrawer] = useState<DocumentIntelligenceData>({
    isOpen: true,
    activeRecordId: 'rec-001',
    sourceDocTitle: 'Apex_Global_Utility_Statement_March2024.pdf',
    previewUrl: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=800&auto=format&fit=crop',
    extractedFields: {
      indicator: {
        name: 'Indicator',
        value: 'Electricity Consumption',
        confidence: 0.98,
        isMatch: true
      },
      value: {
        name: 'Value',
        value: '142,500',
        unit: 'kWh',
        confidence: 0.99,
        isMatch: true
      },
      facilityMatch: {
        name: 'Facility Match',
        facilityName: 'Plant A (North)',
        confidence: 0.85,
        isWarning: true
      }
    },
    documentDetails: {
      invoiceNo: 'INV-2024-03-8821',
      billingPeriod: 'Mar 01 - Mar 31, 2024',
      supplier: 'National Power & Grid Corp',
      issueDate: '2024-04-02'
    }
  });

  const [notificationToast, setNotificationToast] = useState<string | null>(null);

  const filteredRecords = records.filter((rec) => {
    if (rec.category !== activePillar) return false;
    if (
      searchFilter &&
      !rec.indicator.toLowerCase().includes(searchFilter.toLowerCase()) &&
      !rec.facility.toLowerCase().includes(searchFilter.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(filteredRecords.map((r) => r.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleInspectDoc = (record: DataRecord) => {
    setDocDrawer({
      isOpen: true,
      activeRecordId: record.id,
      sourceDocTitle: record.sourceDoc || `${record.indicator}_audit.pdf`,
      previewUrl:
        'https://images.unsplash.com/photo-1554224155-6726b3ff858f?q=80&w=800&auto=format&fit=crop',
      extractedFields: {
        indicator: {
          name: 'Indicator',
          value: record.indicator,
          confidence: 0.98,
          isMatch: true
        },
        value: {
          name: 'Value',
          value: record.value.toLocaleString(),
          unit: record.unit,
          confidence: 0.99,
          isMatch: true
        },
        facilityMatch: {
          name: 'Facility Match',
          facilityName: record.facility,
          confidence: record.status === 'DRAFT' ? 0.85 : 0.98,
          isWarning: record.status === 'DRAFT'
        }
      },
      documentDetails: {
        invoiceNo: `INV-2024-${record.id}`,
        billingPeriod: '2024 Q1 Audit Log',
        supplier: 'National Verification Authority',
        issueDate: record.date
      }
    });
  };

  const handleConfirmAndSave = () => {
    if (docDrawer.activeRecordId) {
      setRecords((prev) =>
        prev.map((r) =>
          r.id === docDrawer.activeRecordId ? { ...r, status: 'VERIFIED' } : r
        )
      );
    }
    setNotificationToast('Record successfully confirmed and saved to ESG Ledger!');
    setTimeout(() => setNotificationToast(null), 3500);
  };

  const handleReject = () => {
    if (docDrawer.activeRecordId) {
      setRecords((prev) =>
        prev.map((r) =>
          r.id === docDrawer.activeRecordId ? { ...r, status: 'REJECTED' } : r
        )
      );
    }
    setNotificationToast('Document OCR extraction flagged for manual re-audit.');
    setTimeout(() => setNotificationToast(null), 3500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Toast Notification */}
      {notificationToast && (
        <div className="fixed bottom-6 right-6 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-2xl z-50 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-4">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-semibold">{notificationToast}</span>
        </div>
      )}

      {/* Header matching Image 11 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
            Data Management
          </h1>
          <p className="text-sm text-slate-500 font-medium mt-0.5">
            {organization.name} • {organization.fiscalYear}
          </p>
        </div>

        {/* Action Buttons matching Image 11 */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setSearchFilter(searchFilter ? '' : 'Plant')}
            className={`inline-flex items-center gap-1.5 px-3 py-2 border rounded-lg text-xs font-semibold shadow-xs transition-colors ${
              searchFilter
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filter</span>
          </button>

          <button
            onClick={onOpenBulkUploadModal}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            <UploadCloud className="w-3.5 h-3.5 text-slate-500" />
            <span>Bulk Upload (CSV)</span>
          </button>

          <button
            onClick={onExportRecords}
            className="inline-flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-[#064e3b] hover:bg-[#043c2e] text-white text-xs font-semibold rounded-lg shadow-sm transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Record</span>
          </button>
        </div>
      </div>

      {/* Pillar Tabs matching Image 11 */}
      <div className="flex items-center gap-8 border-b border-slate-200 text-sm font-semibold">
        {(['environmental', 'social', 'governance'] as EsgPillar[]).map((pillar) => (
          <button
            key={pillar}
            onClick={() => setActivePillar(pillar)}
            className={`pb-3 capitalize transition-all relative ${
              activePillar === pillar
                ? 'text-slate-900 font-bold border-b-2 border-slate-900 -mb-[2px]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {pillar}
          </button>
        ))}
      </div>

      {/* Main Grid: Data Records Table (Left) + Document Intelligence Drawer (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Table Area */}
        <div
          className={`${
            docDrawer.isOpen ? 'lg:col-span-8' : 'lg:col-span-12'
          } bg-white rounded-2xl border border-slate-200 shadow-sm p-6 transition-all duration-300`}
        >
          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                  <th className="pb-3 pr-3 w-8">
                    <input
                      type="checkbox"
                      checked={
                        selectedIds.length > 0 &&
                        filteredRecords.every((r) => selectedIds.includes(r.id))
                      }
                      onChange={handleSelectAll}
                      className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5 cursor-pointer"
                    />
                  </th>
                  <th className="pb-3 px-3">DATE</th>
                  <th className="pb-3 px-3">INDICATOR</th>
                  <th className="pb-3 px-3 text-right">VALUE</th>
                  <th className="pb-3 px-3">UNIT</th>
                  <th className="pb-3 px-3">FACILITY</th>
                  <th className="pb-3 px-3">STATUS</th>
                  <th className="pb-3 pl-3 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRecords.map((record) => {
                  const isSelected = selectedIds.includes(record.id);
                  const isInspected = docDrawer.isOpen && docDrawer.activeRecordId === record.id;

                  return (
                    <tr
                      key={record.id}
                      className={`transition-colors ${
                        isInspected
                          ? 'bg-emerald-50/40 font-medium'
                          : isSelected
                          ? 'bg-slate-50'
                          : 'hover:bg-slate-50/60'
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-4 pr-3">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(record.id)}
                          className="rounded text-[#064e3b] focus:ring-[#064e3b] h-3.5 w-3.5 cursor-pointer"
                        />
                      </td>

                      {/* Date matching Image 11 */}
                      <td className="py-4 px-3 font-mono text-slate-600">
                        {record.date}
                      </td>

                      {/* Indicator */}
                      <td className="py-4 px-3 font-bold text-slate-900">
                        {record.indicator}
                      </td>

                      {/* Value */}
                      <td className="py-4 px-3 font-mono font-bold text-slate-900 text-right">
                        {record.value.toLocaleString()}
                      </td>

                      {/* Unit */}
                      <td className="py-4 px-3 text-slate-500 font-medium">
                        {record.unit}
                      </td>

                      {/* Facility */}
                      <td className="py-4 px-3 text-slate-700 font-medium">
                        {record.facility}
                      </td>

                      {/* Status Badge matching Image 11 */}
                      <td className="py-4 px-3">
                        {record.status === 'VERIFIED' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-[#e6f4ea] text-[#137333]">
                            VERIFIED
                          </span>
                        )}
                        {record.status === 'DRAFT' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-600">
                            DRAFT
                          </span>
                        )}
                        {record.status === 'REJECTED' && (
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-red-100 text-red-700">
                            REJECTED
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-4 pl-3 text-right">
                        <button
                          onClick={() => handleInspectDoc(record)}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#1e3a8a] hover:text-[#172554] hover:underline"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Inspect</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination Controls */}
          <div className="flex items-center justify-between pt-6 mt-4 border-t border-slate-100 text-xs text-slate-500">
            <div>Showing 1-10 of 144 records</div>
            <div className="flex items-center gap-1.5">
              <button className="p-1.5 rounded border border-slate-200 text-slate-400 hover:bg-slate-50">
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button className="px-2.5 py-1 rounded bg-[#064e3b] text-white font-bold">1</button>
              <button className="px-2.5 py-1 rounded border border-slate-200 hover:bg-slate-50">2</button>
              <button className="px-2.5 py-1 rounded border border-slate-200 hover:bg-slate-50">3</button>
              <button className="p-1.5 rounded border border-slate-200 text-slate-600 hover:bg-slate-50">
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Document Intelligence Drawer (Right Column) matching Image 11 */}
        {docDrawer.isOpen && (
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-lg p-6 space-y-6 animate-in fade-in slide-in-from-right-4 duration-200">
            {/* Header matching Image 11 */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-slate-700" />
                <h3 className="font-bold text-slate-900 text-base">
                  Document Intelligence
                </h3>
              </div>
              <button
                onClick={() => setDocDrawer((prev) => ({ ...prev, isOpen: false }))}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed -mt-2">
              AI extracted data from attached source document.
            </p>

            {/* Document Thumbnail Preview matching Image 11 */}
            <div className="bg-slate-100 rounded-xl p-3 border border-slate-200 relative group overflow-hidden">
              <div className="h-44 bg-white rounded-lg border border-slate-200 p-4 flex flex-col justify-between shadow-xs">
                {/* Simulated Invoice Document Header */}
                <div className="flex items-start justify-between border-b border-slate-100 pb-2">
                  <div>
                    <div className="text-[10px] font-bold text-slate-800 uppercase tracking-wide">
                      {docDrawer.documentDetails.supplier}
                    </div>
                    <div className="text-[9px] text-slate-400 font-mono">
                      {docDrawer.documentDetails.invoiceNo}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] bg-emerald-50 text-emerald-800 font-bold px-1.5 py-0.5 rounded">
                      OCR PARSED
                    </span>
                  </div>
                </div>

                {/* Simulated Document Body */}
                <div className="space-y-1.5 py-2 text-[10px] text-slate-600">
                  <div className="flex justify-between border-b border-dashed border-slate-100 pb-1">
                    <span>Meter No:</span>
                    <span className="font-mono font-bold">MTR-99214-PLANT-A</span>
                  </div>
                  <div className="flex justify-between border-b border-dashed border-slate-100 pb-1">
                    <span>Billing Units:</span>
                    <span className="font-mono font-extrabold text-emerald-800 bg-emerald-100/70 px-1 rounded">
                      142,500 kWh
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Substation:</span>
                    <span>North Grid Feeder #4</span>
                  </div>
                </div>

                {/* Simulated Document Footer */}
                <div className="text-[9px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100">
                  <span>Period: {docDrawer.documentDetails.billingPeriod}</span>
                  <span className="font-bold text-slate-600">PAID</span>
                </div>
              </div>
            </div>

            {/* Extracted Fields Cards matching Image 11 */}
            <div className="space-y-3">
              {/* Field 1: Indicator */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-medium text-slate-500">Indicator</p>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">
                    {docDrawer.extractedFields.indicator.value}
                  </p>
                </div>
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              </div>

              {/* Field 2: Value */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-medium text-slate-500">Value</p>
                  <p className="text-sm font-bold text-slate-900 mt-0.5 font-mono">
                    {docDrawer.extractedFields.value.value}
                  </p>
                </div>
                <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              </div>

              {/* Field 3: Facility Match matching Image 11 */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
                <div>
                  <p className="text-[11px] font-medium text-slate-500">Facility Match</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <p className="text-sm font-bold text-slate-900">
                      {docDrawer.extractedFields.facilityMatch.facilityName}
                    </p>
                    <span className="text-[11px] text-amber-700 font-medium italic">
                      (85% confidence)
                    </span>
                  </div>
                </div>
                <div className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
                  <AlertTriangle className="w-3 h-3" />
                </div>
              </div>
            </div>

            {/* Action Buttons matching Image 11 */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              {/* Reject */}
              <button
                onClick={handleReject}
                className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition-colors"
              >
                Reject
              </button>

              {/* Confirm & Save */}
              <button
                onClick={handleConfirmAndSave}
                className="w-full py-2.5 px-4 bg-[#064e3b] hover:bg-[#043c2e] text-white text-xs font-semibold rounded-lg shadow-sm transition-all active:scale-95"
              >
                Confirm & Save
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
