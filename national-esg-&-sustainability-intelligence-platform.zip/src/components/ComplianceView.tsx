import React, { useState } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Clock,
  ExternalLink,
  Upload,
  AlertTriangle,
  ChevronDown,
  Filter,
  Bot,
  Sparkles,
  Search,
  Plus
} from 'lucide-react';
import { ComplianceItem } from '../types/esg';
import { initialComplianceItems } from '../data/mockData';

interface ComplianceViewProps {
  onViewEvidence: (item: ComplianceItem) => void;
  onUploadEvidence: (item: ComplianceItem) => void;
  onEscalate: (item: ComplianceItem) => void;
}

export const ComplianceView: React.FC<ComplianceViewProps> = ({
  onViewEvidence,
  onUploadEvidence,
  onEscalate
}) => {
  const [items, setItems] = useState<ComplianceItem[]>(initialComplianceItems);
  const [selectedFramework, setSelectedFramework] = useState<string>('All Frameworks');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const frameworks = ['All Frameworks', 'BRSR', 'SEC', 'CSRD', 'GRI'];

  const filteredItems = items.filter((item) => {
    if (selectedFramework !== 'All Frameworks' && item.framework !== selectedFramework) {
      return false;
    }
    if (statusFilter !== 'ALL' && item.status !== statusFilter) {
      return false;
    }
    return true;
  });

  const completeCount = items.filter((i) => i.status === 'COMPLETE').length;
  const pendingCount = items.filter((i) => i.status === 'PENDING').length;
  const overdueCount = items.filter((i) => i.status === 'OVERDUE').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header matching Image 9 */}
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
          Compliance Tracking
        </h1>
        <p className="text-sm text-slate-500 font-medium mt-0.5">
          Monitor adherence to regulatory frameworks and internal policies.
        </p>
      </div>

      {/* Grid: Left Column (Overall Compliance + AI Compliance Analyst) + Right Column (Requirement Items) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (4 Cols) matching Image 9 */}
        <div className="lg:col-span-4 space-y-6">
          {/* Overall Compliance Card matching Image 9 */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col items-center justify-between text-center">
            <div className="w-full text-left">
              <h3 className="font-bold text-slate-900 text-base">Overall Compliance</h3>
            </div>

            {/* Circular Semi-Gauge matching Image 9 */}
            <div className="relative w-48 h-36 my-6 flex flex-col items-center justify-center">
              <svg className="w-48 h-48 overflow-visible" viewBox="0 0 100 100">
                {/* Background Track */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                  stroke="#e2e8f0"
                  strokeWidth="8"
                  strokeDasharray="188 251"
                  strokeDashoffset="-31"
                  strokeLinecap="round"
                  className="-rotate-90 origin-center"
                />
                {/* Progress Value: 85% of arc -> stroke-dasharray="160 251" */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="transparent"
                  stroke="#0d9488"
                  strokeWidth="8"
                  strokeDasharray="160 251"
                  strokeDashoffset="-31"
                  strokeLinecap="round"
                  className="-rotate-90 origin-center transition-all duration-700"
                />
              </svg>

              {/* Center percentage & pill */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pt-2">
                <span className="text-4xl font-black text-slate-900 tracking-tight">
                  85%
                </span>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 mt-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                  ON TRACK
                </span>
              </div>
            </div>

            {/* Breakdown Counts matching Image 9 */}
            <div className="w-full grid grid-cols-3 pt-6 border-t border-slate-100 text-center">
              <div className="border-r border-slate-100">
                <p className="text-2xl font-extrabold text-slate-900">42</p>
                <p className="text-xs font-medium text-slate-500 mt-0.5">Complete</p>
              </div>
              <div className="border-r border-slate-100">
                <p className="text-2xl font-extrabold text-amber-600">6</p>
                <p className="text-xs font-medium text-slate-500 mt-0.5">Pending</p>
              </div>
              <div>
                <p className="text-2xl font-extrabold text-red-600">1</p>
                <p className="text-xs font-medium text-slate-500 mt-0.5">Overdue</p>
              </div>
            </div>
          </div>

          {/* AI Compliance Analyst (BETA) Card matching Image 9 */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">
                  AI Compliance Analyst
                </h3>
              </div>
              <span className="text-[10px] font-extrabold tracking-wider bg-slate-900 text-white px-2 py-0.5 rounded uppercase">
                BETA
              </span>
            </div>

            {/* AI Callout Box */}
            <div className="bg-emerald-50/70 border border-emerald-100 rounded-xl p-4 text-xs leading-relaxed text-slate-700 space-y-2">
              <p>
                You are currently <strong className="text-emerald-900 font-bold">85% compliant</strong> with SEC climate disclosure requirements. Action required on <strong className="text-slate-900 font-bold">Scope 3 emissions data</strong>.
              </p>
              <p className="text-[11px] text-slate-500">
                Next major filing window closes in <strong>42 days</strong>.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column (8 Cols): Requirement Items Table matching Image 9 */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
          {/* Table Header Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <h3 className="font-bold text-slate-900 text-base">Requirement Items</h3>

            <div className="flex items-center gap-2">
              {/* Framework Dropdown matching Image 9 */}
              <div className="relative">
                <select
                  value={selectedFramework}
                  onChange={(e) => setSelectedFramework(e.target.value)}
                  className="appearance-none bg-white border border-slate-200 hover:border-slate-300 text-xs font-semibold text-slate-800 px-3 py-2 pr-8 rounded-lg shadow-xs cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#064e3b]"
                >
                  {frameworks.map((fw) => (
                    <option key={fw} value={fw}>
                      {fw}
                    </option>
                  ))}
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Filter Button */}
              <button
                onClick={() => {
                  setStatusFilter((prev) =>
                    prev === 'ALL' ? 'PENDING' : prev === 'PENDING' ? 'OVERDUE' : 'ALL'
                  );
                }}
                className={`p-2 border rounded-lg text-xs font-semibold transition-colors flex items-center gap-1 ${
                  statusFilter !== 'ALL'
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
                title={`Filter by Status: ${statusFilter}`}
              >
                <Filter className="w-4 h-4" />
                {statusFilter !== 'ALL' && <span className="text-[10px] uppercase">{statusFilter}</span>}
              </button>
            </div>
          </div>

          {/* Table Content matching Image 9 */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                  <th className="pb-3 pr-4">Requirement Name</th>
                  <th className="pb-3 px-3">Status</th>
                  <th className="pb-3 px-3">Due Date</th>
                  <th className="pb-3 px-3">Responsible</th>
                  <th className="pb-3 pl-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/60 transition-colors">
                    {/* Name & Subtext */}
                    <td className="py-4 pr-4">
                      <div className="font-bold text-slate-900 text-sm">
                        {item.name}
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {item.subtext}
                      </div>
                    </td>

                    {/* Status Badge matching Image 9 */}
                    <td className="py-4 px-3">
                      {item.status === 'COMPLETE' && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-[#e6f4ea] text-[#137333] tracking-wide">
                          COMPLETE
                        </span>
                      )}
                      {item.status === 'PENDING' && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-[#fef7e0] text-[#b06000] tracking-wide">
                          PENDING
                        </span>
                      )}
                      {item.status === 'OVERDUE' && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-bold bg-[#fce8e6] text-[#c5221f] tracking-wide">
                          OVERDUE
                        </span>
                      )}
                    </td>

                    {/* Due Date matching Image 9 */}
                    <td className="py-4 px-3">
                      <span
                        className={`font-medium ${
                          item.status === 'OVERDUE' ? 'text-red-600 font-semibold' : 'text-slate-700'
                        }`}
                      >
                        {item.dueDate}
                      </span>
                    </td>

                    {/* Responsible matching Image 9 */}
                    <td className="py-4 px-3">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-6 h-6 rounded-full text-white text-[10px] font-bold flex items-center justify-center shrink-0 ${
                            item.responsible.avatarColor || 'bg-slate-400'
                          }`}
                        >
                          {item.responsible.initials}
                        </div>
                        <span
                          className={`font-medium truncate ${
                            item.responsible.name === 'Unassigned'
                              ? 'italic text-slate-400'
                              : 'text-slate-800'
                          }`}
                        >
                          {item.responsible.name}
                        </span>
                      </div>
                    </td>

                    {/* Actions matching Image 9 */}
                    <td className="py-4 pl-3 text-right">
                      {item.status === 'COMPLETE' && (
                        <button
                          onClick={() => onViewEvidence(item)}
                          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#1e3a8a] hover:text-[#172554] hover:underline"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Evidence</span>
                        </button>
                      )}

                      {item.status === 'PENDING' && (
                        <button
                          onClick={() => onUploadEvidence(item)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold rounded-md shadow-xs transition-colors"
                        >
                          <Upload className="w-3.5 h-3.5 text-slate-500" />
                          <span>Upload</span>
                        </button>
                      )}

                      {item.status === 'OVERDUE' && (
                        <button
                          onClick={() => onEscalate(item)}
                          className="inline-flex items-center gap-1 text-xs font-bold text-red-600 hover:text-red-800 hover:underline"
                        >
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Escalate</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Footer matching Image 9 */}
      <footer className="border-t border-slate-200 pt-6 mt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <p>© 2024 National ESG Intelligence Platform. All Rights Reserved.</p>
        <div className="flex items-center gap-6">
          <button className="hover:text-slate-800">Privacy Policy</button>
          <button className="hover:text-slate-800">Terms of Service</button>
          <button className="hover:text-slate-800">Security Disclosure</button>
          <button className="hover:text-slate-800">Methodology</button>
        </div>
      </footer>
    </div>
  );
};
