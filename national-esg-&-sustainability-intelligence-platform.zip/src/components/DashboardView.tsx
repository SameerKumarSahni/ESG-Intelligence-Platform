import React, { useState } from 'react';
import {
  TrendingUp,
  Leaf,
  Users,
  Building2,
  CloudFog,
  SunMedium,
  Recycle,
  MoreVertical,
  Bot,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  ArrowRight,
  FileCheck,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { ActiveTab, OrganizationInfo } from '../types/esg';
import {
  initialExecutiveMetrics,
  initialQuickStats,
  carbonEmissionsTrend6Months
} from '../data/mockData';

interface DashboardViewProps {
  organization: OrganizationInfo;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenReportModal: () => void;
  onDrillDownFacilityB: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  organization,
  setActiveTab,
  onOpenReportModal,
  onDrillDownFacilityB
}) => {
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'6M' | '12M' | 'YTD'>('6M');

  const maxVal = Math.max(...carbonEmissionsTrend6Months.map((d) => d.emissions));

  return (
    <div className="space-y-6 pb-12">
      {/* Executive Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
          {organization.name}
        </h1>
        <p className="text-sm text-slate-500 font-medium mt-0.5">
          {organization.subhead}
        </p>
      </div>

      {/* Top 4 Metric Cards matching Image 3 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Overall ESG Score */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              OVERALL ESG SCORE
            </span>
            <TrendingUp className="w-4 h-4 text-slate-400" />
          </div>

          <div className="my-3">
            <div className="flex items-baseline gap-1">
              <span className="text-4xl font-extrabold text-slate-900 tracking-tight">78</span>
              <span className="text-sm font-semibold text-slate-400">/100</span>
            </div>
          </div>

          <div>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-100">
              <span className="text-emerald-600 font-bold">↗</span> +2.4 from last quarter
            </span>
          </div>
        </div>

        {/* Environmental */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              ENVIRONMENTAL
            </span>
            <Leaf className="w-4 h-4 text-emerald-600" />
          </div>

          <div className="my-3">
            <span className="text-4xl font-extrabold text-slate-900 tracking-tight">82</span>
          </div>

          {/* Progress bar matching design */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-emerald-600 h-full rounded-full" style={{ width: '82%' }}></div>
          </div>
        </div>

        {/* Social */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              SOCIAL
            </span>
            <Users className="w-4 h-4 text-blue-600" />
          </div>

          <div className="my-3">
            <span className="text-4xl font-extrabold text-slate-900 tracking-tight">74</span>
          </div>

          {/* Progress bar matching design */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-blue-600 h-full rounded-full" style={{ width: '74%' }}></div>
          </div>
        </div>

        {/* Governance */}
        <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 tracking-wider uppercase">
              GOVERNANCE
            </span>
            <Building2 className="w-4 h-4 text-purple-600" />
          </div>

          <div className="my-3">
            <span className="text-4xl font-extrabold text-slate-900 tracking-tight">79</span>
          </div>

          {/* Progress bar matching design */}
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
            <div className="bg-purple-600 h-full rounded-full" style={{ width: '79%' }}></div>
          </div>
        </div>
      </div>

      {/* 3 Secondary Quick Stats Pills matching Image 3 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Carbon Emissions */}
        <div 
          onClick={() => setActiveTab('carbon-analytics')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex items-center gap-4 cursor-pointer hover:border-slate-300 transition-all"
        >
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
            <span className="text-xs font-mono font-bold">CO₂</span>
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Carbon Emissions</p>
            <p className="text-lg font-bold text-slate-900">
              4,250 <span className="text-xs font-normal text-slate-500">tCO2e</span>
            </p>
          </div>
        </div>

        {/* Renewable Energy */}
        <div 
          onClick={() => setActiveTab('data-management')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex items-center gap-4 cursor-pointer hover:border-slate-300 transition-all"
        >
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <SunMedium className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Renewable Energy</p>
            <p className="text-lg font-bold text-slate-900">32%</p>
          </div>
        </div>

        {/* Recycling Rate */}
        <div 
          onClick={() => setActiveTab('compliance')}
          className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm flex items-center gap-4 cursor-pointer hover:border-slate-300 transition-all"
        >
          <div className="w-11 h-11 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <Recycle className="w-5 h-5" />
          </div>
          <div>
            <p className="text-xs text-slate-500 font-medium">Recycling Rate</p>
            <p className="text-lg font-bold text-slate-900">68%</p>
          </div>
        </div>
      </div>

      {/* Middle Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Carbon Emissions Trend (6 Months) */}
        <div className="lg:col-span-8 bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Carbon Emissions Trend (6 Months)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">Scope 1 & Scope 2 aggregated monthly breakdown</p>
            </div>
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex items-center bg-slate-100 rounded-lg p-0.5 text-xs font-semibold">
                {(['6M', '12M', 'YTD'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setSelectedTimeframe(tf)}
                    className={`px-2.5 py-1 rounded-md transition-colors ${
                      selectedTimeframe === tf
                        ? 'bg-white text-slate-800 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
              <button 
                onClick={() => setActiveTab('carbon-analytics')}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-md hover:bg-slate-50"
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Interactive Chart Container matching Image 3 */}
          <div className="border border-dashed border-slate-200 rounded-xl p-6 bg-slate-50/40 relative">
            <div className="h-64 flex items-end justify-between gap-4 pt-6 pb-2">
              {carbonEmissionsTrend6Months.map((item, idx) => {
                const heightPercent = Math.round((item.emissions / maxVal) * 85);
                const isHovered = hoveredBar === idx;

                return (
                  <div
                    key={item.month}
                    className="flex-1 flex flex-col items-center h-full justify-end group relative cursor-pointer"
                    onMouseEnter={() => setHoveredBar(idx)}
                    onMouseLeave={() => setHoveredBar(null)}
                    onClick={() => setActiveTab('carbon-analytics')}
                  >
                    {/* Tooltip */}
                    {isHovered && (
                      <div className="absolute -top-12 bg-slate-900 text-white text-xs py-1 px-2.5 rounded-md shadow-lg z-20 whitespace-nowrap animate-in fade-in zoom-in-95">
                        <p className="font-semibold">{item.month}: {item.emissions} tCO2e</p>
                        <p className="text-[10px] text-slate-300">Target: {item.target} tCO2e</p>
                      </div>
                    )}

                    {/* Chart Bar */}
                    <div
                      className={`w-full rounded-t-sm transition-all duration-300 ${
                        idx === 4 
                          ? 'bg-[#98b8a6] hover:bg-[#85ab95]' // Sept spike
                          : 'bg-[#b6cdbf] hover:bg-[#9ebfaa]'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    ></div>

                    {/* X-axis Month Label */}
                    <span className="text-xs font-medium text-slate-500 mt-3 group-hover:text-slate-900 transition-colors">
                      {item.month}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Subtle Label Overlay matching Image 3 */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-xs font-semibold text-slate-600 pointer-events-none select-none bg-white/70 px-3 py-1 rounded-full border border-slate-200 shadow-xs">
              Line Chart Visualization Space • Active Feed
            </div>
          </div>
        </div>

        {/* Right Column: AI Copilot Insights + Peer Comparison */}
        <div className="lg:col-span-4 space-y-6">
          {/* AI Copilot Insights Card */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            {/* Header with Blue Gradient / Pill matching Image 3 */}
            <div className="bg-gradient-to-r from-[#2e7d60] to-[#3b82f6] text-white px-5 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4" />
                <h3 className="font-bold text-sm">AI Copilot Insights</h3>
              </div>
              <Sparkles className="w-3.5 h-3.5 opacity-80" />
            </div>

            <div className="p-4 space-y-3">
              {/* Warning Alert Box matching Image 3 */}
              <div 
                onClick={onDrillDownFacilityB}
                className="bg-[#fffbeb] border border-[#fef3c7] rounded-xl p-3 cursor-pointer hover:border-amber-300 transition-all"
              >
                <div className="flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-amber-900 leading-snug">
                      Energy consumption increased 15% in Facility B
                    </p>
                    <p className="text-[11px] text-amber-700 mt-1">
                      Recommended: Audit HVAC systems.
                    </p>
                  </div>
                </div>
              </div>

              {/* Success Alert Box matching Image 3 */}
              <div 
                onClick={() => setActiveTab('compliance')}
                className="bg-[#ecfdf5] border border-[#d1fae5] rounded-xl p-3 cursor-pointer hover:border-emerald-300 transition-all"
              >
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-emerald-900 leading-snug">
                      Recycling improved 8% overall
                    </p>
                    <p className="text-[11px] text-emerald-700 mt-1">
                      Target reached ahead of schedule.
                    </p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setActiveTab('ai-copilot')}
                className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-[#064e3b] hover:bg-slate-50 rounded-lg transition-colors"
              >
                <span>Open Sustainability Assistant</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Peer Comparison Card matching Image 3 */}
          <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900 text-sm">Peer Comparison</h3>
              <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                Industrial Sector
              </span>
            </div>

            {/* Radar / Target concentric circles space matching Image 3 */}
            <div className="border border-dashed border-slate-200 rounded-xl p-5 bg-slate-50/50 flex flex-col items-center justify-center relative h-44">
              <div className="relative w-32 h-32 flex items-center justify-center">
                {/* Concentric rings */}
                <div className="absolute inset-0 rounded-full border-2 border-slate-200"></div>
                <div className="absolute inset-3 rounded-full border border-slate-200"></div>
                <div className="absolute inset-7 rounded-full border border-slate-200"></div>
                <div className="absolute inset-11 rounded-full border border-emerald-400 bg-emerald-50/50"></div>
                
                {/* GreenTech Dot Benchmark */}
                <div className="absolute top-4 right-6 w-3 h-3 rounded-full bg-emerald-600 shadow-sm"></div>
                {/* Peer Average Dot */}
                <div className="absolute bottom-6 left-5 w-2.5 h-2.5 rounded-full bg-slate-400"></div>

                <span className="text-xs font-semibold text-slate-700 bg-white/90 px-2.5 py-1 rounded shadow-xs z-10 border border-slate-200">
                  Radar Chart Space
                </span>
              </div>

              <div className="flex items-center justify-between w-full text-[11px] text-slate-500 mt-2 px-2">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block"></span>
                  GreenTech: <strong>Top 12%</strong>
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-slate-400 inline-block"></span>
                  Peer Avg: 68/100
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming Deadlines & Recent Reports Section matching Image 3 */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-slate-900 text-base">
            Upcoming Deadlines & Recent Reports
          </h3>
          <button
            onClick={() => setActiveTab('compliance')}
            className="px-3 py-1.5 text-xs font-semibold text-[#064e3b] border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors"
          >
            View All
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-blue-700 uppercase bg-blue-50 px-2 py-0.5 rounded">
                BRSR CORE
              </span>
              <span className="text-xs font-medium text-slate-500">Due Oct 15</span>
            </div>
            <p className="text-xs font-bold text-slate-800">
              Annual Sustainability Assurance Package
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Section A & B general disclosures ready for sign-off.</p>
            <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Ready
              </span>
              <button 
                onClick={() => setActiveTab('compliance')}
                className="text-xs text-slate-700 hover:text-slate-900 font-medium flex items-center gap-1"
              >
                Review <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-purple-700 uppercase bg-purple-50 px-2 py-0.5 rounded">
                SEC CLIMATE
              </span>
              <span className="text-xs font-medium text-slate-500">Due Dec 15</span>
            </div>
            <p className="text-xs font-bold text-slate-800">
              Scope 3 Supply Chain Footprint Verification
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Vendor activity submissions currently at 74% completeness.</p>
            <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-amber-600 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Pending
              </span>
              <button 
                onClick={() => setActiveTab('compliance')}
                className="text-xs text-slate-700 hover:text-slate-900 font-medium flex items-center gap-1"
              >
                Action <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 transition-colors flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-emerald-700 uppercase bg-emerald-50 px-2 py-0.5 rounded">
                EXECUTIVE BRIEF
              </span>
              <span className="text-xs font-medium text-slate-500">Generated Today</span>
            </div>
            <p className="text-xs font-bold text-slate-800">
              Q3 Board Sustainability & Decarbonization Pack
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Full breakdown of energy audits, emissions, and ESG ratings.</p>
            <div className="mt-3 pt-3 border-t border-slate-200/60 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-blue-600 flex items-center gap-1">
                <FileCheck className="w-3 h-3" /> Complete
              </span>
              <button 
                onClick={onOpenReportModal}
                className="text-xs text-slate-700 hover:text-slate-900 font-medium flex items-center gap-1"
              >
                Download <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
