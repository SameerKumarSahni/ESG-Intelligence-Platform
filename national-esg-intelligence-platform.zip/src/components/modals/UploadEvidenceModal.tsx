import React, { useState } from 'react';
import { ComplianceItem } from '../../types';

interface UploadEvidenceModalProps {
  item: ComplianceItem | null;
  onClose: () => void;
  onSuccess: (itemId: string, fileName: string) => void;
}

export const UploadEvidenceModal: React.FC<UploadEvidenceModalProps> = ({ item, onClose, onSuccess }) => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [notes, setNotes] = useState('');

  if (!item) return null;

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      alert('Please select or drop an audit document/evidence file.');
      return;
    }
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      onSuccess(item.id, file.name);
      onClose();
    }, 800);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div
        id="upload-evidence-modal-box"
        className="bg-white border border-[#bfc9c3]/50 rounded-2xl max-w-lg w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150"
      >
        <div className="flex justify-between items-start">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#003527] bg-[#003527]/10 px-2 py-0.5 rounded">
              {item.pillar} Pillar
            </span>
            <h3 className="font-['Montserrat',sans-serif] text-[20px] font-bold text-[#191c1e] mt-1">
              Upload Compliance Evidence
            </h3>
            <p className="text-[13px] text-[#707974]">{item.title}</p>
          </div>
          <button onClick={onClose} className="text-[#707974] hover:text-[#191c1e] p-1">
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Dropzone */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-[#bfc9c3] hover:border-[#003527] rounded-xl p-6 text-center cursor-pointer bg-[#f7f9fb] transition-colors"
            onClick={() => document.getElementById('file-upload-input')?.click()}
          >
            <input
              id="file-upload-input"
              type="file"
              onChange={handleFileChange}
              accept=".pdf,.xlsx,.csv,.docx"
              className="hidden"
            />
            <span className="material-symbols-outlined text-[40px] text-[#003527] mb-2">
              cloud_upload
            </span>
            {file ? (
              <div>
                <p className="font-semibold text-[14px] text-[#003527]">{file.name}</p>
                <p className="text-[12px] text-[#707974]">{(file.size / 1024).toFixed(1)} KB — Ready</p>
              </div>
            ) : (
              <div>
                <p className="text-[14px] font-semibold text-[#191c1e]">
                  Drag &amp; drop audit report or click to browse
                </p>
                <p className="text-[12px] text-[#707974] mt-1">Supports PDF, XLSX, CSV, DOCX (Max 25MB)</p>
              </div>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-[12px] font-bold text-[#404944] uppercase tracking-wider mb-1">
              Auditor Comments / Verification Reference
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="e.g. Certified by Bureau Veritas; verified by internal sustainability team."
              className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2 text-[13px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-[13px] font-semibold text-[#404944] hover:bg-[#f2f4f6] rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isUploading || !file}
              className="px-5 py-2 text-[13px] font-bold bg-[#003527] text-white rounded-lg hover:bg-[#064e3b] disabled:opacity-50 transition-all cursor-pointer flex items-center gap-1.5"
            >
              {isUploading ? (
                <>
                  <span className="material-symbols-outlined text-[16px] animate-spin">
                    progress_activity
                  </span>
                  <span>Verifying Document...</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[16px]">upload_file</span>
                  <span>Submit Evidence</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
