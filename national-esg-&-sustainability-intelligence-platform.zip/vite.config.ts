import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, Plugin } from 'vite';
import { GoogleGenAI } from '@google/genai';

function esgAiServerPlugin(): Plugin {
  return {
    name: 'esg-ai-server-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (req.url === '/api/ai/copilot' && req.method === 'POST') {
          let body = '';
          req.on('data', chunk => {
            body += chunk;
          });
          req.on('end', async () => {
            try {
              const { prompt, organization } = JSON.parse(body || '{}');
              const apiKey = process.env.GEMINI_API_KEY;

              if (apiKey) {
                const ai = new GoogleGenAI({
                  apiKey,
                  httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
                });

                const systemInstruction = `You are the National ESG & Sustainability Intelligence Assistant for ${organization || 'GreenTech Manufacturing Pvt. Ltd.'}.
Provide precise, institutional-grade responses citing Scope 1, Scope 2, Scope 3, BRSR Core, SEC Climate Disclosure, and CSRD metrics.
Format your responses cleanly using markdown bullet points and bold key statistics.`;

                const response = await ai.models.generateContent({
                  model: 'gemini-2.5-flash',
                  contents: [
                    { role: 'user', parts: [{ text: `${systemInstruction}\n\nUser Question: ${prompt}` }] }
                  ]
                });

                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ text: response.text }));
                return;
              }

              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({
                text: `Analysis for ${organization || 'GreenTech Manufacturing'}: Based on current Q3 ledger entries, total emissions are tracked at 12,450 tCO2e across 4 operational facilities. Key hotspots include Facility B electricity load and cooling tower operations.`
              }));
            } catch (err: any) {
              res.statusCode = 500;
              res.setHeader('Content-Type', 'application/json');
              res.end(JSON.stringify({ error: err.message || 'Internal AI Error' }));
            }
          });
          return;
        }
        next();
      });
    }
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), esgAiServerPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
