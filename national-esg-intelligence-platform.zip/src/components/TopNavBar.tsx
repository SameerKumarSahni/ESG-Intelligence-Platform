import React, { useState } from 'react';

interface TopNavBarProps {
  onToggleMobileSidebar: () => void;
  onOpenNewReport: () => void;
  onOpenGlobalMetrics: () => void;
  onOpenAnnouncements: () => void;
  onOpenRegionalData: () => void;
  unreadAnnouncementsCount: number;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  onToggleMobileSidebar,
  onOpenNewReport,
  onOpenGlobalMetrics,
  onOpenAnnouncements,
  onOpenRegionalData,
  unreadAnnouncementsCount,
  searchQuery,
  onSearchChange,
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  return (
    <header
      id="app-topnavbar"
      className="fixed top-0 right-0 left-0 md:left-[280px] z-30 h-16 bg-[#f7f9fb] border-b border-[#bfc9c3]/40 px-4 md:px-8 flex items-center justify-between transition-all duration-200"
    >
      {/* Left: Mobile trigger & Platform Title */}
      <div className="flex items-center gap-3">
        <button
          id="mobile-sidebar-toggle"
          onClick={onToggleMobileSidebar}
          className="md:hidden text-[#191c1e] hover:bg-[#eceef0] p-1.5 rounded-md transition-colors"
          aria-label="Toggle navigation menu"
        >
          <span className="material-symbols-outlined text-[24px]">menu</span>
        </button>
        <div className="font-['Montserrat',sans-serif] text-[18px] md:text-[20px] font-extrabold text-[#191c1e] tracking-tight truncate">
          National ESG Platform
        </div>
      </div>

      {/* Center: Search input */}
      <div className="hidden lg:flex flex-1 max-w-md mx-6 relative">
        <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#707974] text-[20px]">
          search
        </span>
        <input
          id="universal-search-input"
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search metrics, reports, frameworks, scopes..."
          className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-full py-2 pl-10 pr-4 text-[13.5px] text-[#191c1e] placeholder:text-[#707974] focus:outline-none focus:border-[#003527] focus:ring-1 focus:ring-[#003527] transition-all"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-[#707974] hover:text-[#191c1e]"
          >
            <span className="material-symbols-outlined text-[16px]">close</span>
          </button>
        )}
      </div>

      {/* Right: Nav Links & User Action */}
      <div className="flex items-center gap-3 md:gap-5">
        <nav className="hidden xl:flex items-center gap-6 mr-2">
          <button
            id="topnav-global-metrics-btn"
            onClick={onOpenGlobalMetrics}
            className="text-[13px] font-semibold text-[#404944] hover:text-[#003527] transition-colors cursor-pointer"
          >
            Global Metrics
          </button>
          <button
            id="topnav-announcements-btn"
            onClick={onOpenAnnouncements}
            className="text-[13px] font-semibold text-[#404944] hover:text-[#003527] transition-colors cursor-pointer relative"
          >
            Announcements
            {unreadAnnouncementsCount > 0 && (
              <span className="inline-block w-2 h-2 rounded-full bg-[#ba1a1a] ml-1.5 -top-1 relative" />
            )}
          </button>
          <button
            id="topnav-regional-data-btn"
            onClick={onOpenRegionalData}
            className="text-[13px] font-semibold text-[#404944] hover:text-[#003527] transition-colors cursor-pointer"
          >
            Regional Data
          </button>
        </nav>

        {/* Notifications Icon */}
        <button
          id="topnav-notifications-btn"
          onClick={onOpenAnnouncements}
          className="relative text-[#404944] hover:text-[#003527] p-1.5 rounded-full hover:bg-[#eceef0] transition-colors cursor-pointer"
          title="Notifications & Regulatory Alerts"
        >
          <span className="material-symbols-outlined text-[22px]">notifications</span>
          {unreadAnnouncementsCount > 0 && (
            <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#ba1a1a] rounded-full ring-2 ring-[#f7f9fb]" />
          )}
        </button>

        {/* New Report CTA Button */}
        <button
          id="topnav-new-report-btn"
          onClick={onOpenNewReport}
          className="bg-[#003527] text-white font-semibold text-[13px] px-3.5 md:px-4 py-2 rounded-lg hover:bg-[#064e3b] transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-98"
        >
          <span className="material-symbols-outlined text-[16px]">add</span>
          <span>New Report</span>
        </button>

        {/* Profile Avatar */}
        <div className="relative">
          <button
            id="user-profile-menu-btn"
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="w-8 h-8 rounded-full border border-[#bfc9c3] overflow-hidden cursor-pointer hover:ring-2 hover:ring-[#95d3ba] transition-all"
            title="Executive Account"
          >
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAp_aXWt17CdKnhknxLJEvTKwRhoKg_n3a4JKk7yFYjDYwe65WBWL_-2yVgNm-uM0QvEFxu8SsQXB1ZOtjbsFdO__GOGPgE3ZHlR0uPiyZoi3k2E7vm5oGncG8P2UceMAIADiRf8R0FKC_eyz5uVrTZt7N4-kndBXjMAJ6C4-5cjIm7kWscVH-7Ll4OKRbOkGOxNy4HI7iJ2SiTJAp--ap2e_1OYpuVebCQ9BagwBNji5Ikr2JX_4-I3g"
              alt="Executive Profile"
              className="w-full h-full object-cover"
            />
          </button>

          {showProfileMenu && (
            <div
              id="user-profile-dropdown"
              className="absolute right-0 mt-2 w-56 bg-white border border-[#bfc9c3]/50 rounded-xl shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
            >
              <div className="px-4 py-2.5 border-b border-[#eceef0]">
                <p className="text-[13.5px] font-semibold text-[#191c1e]">Sameer Sahni</p>
                <p className="text-[11.5px] text-[#707974]">Chief Sustainability Officer</p>
                <span className="inline-block mt-1 px-2 py-0.5 text-[10.5px] font-semibold bg-[#b0f0d6]/50 text-[#003527] rounded-full">
                  Enterprise Admin
                </span>
              </div>
              <button
                onClick={() => {
                  setShowProfileMenu(false);
                  onOpenGlobalMetrics();
                }}
                className="w-full px-4 py-2 text-left text-[13px] text-[#404944] hover:bg-[#f2f4f6] flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[17px]">public</span>
                Global Performance
              </button>
              <button
                onClick={() => {
                  setShowProfileMenu(false);
                  onOpenRegionalData();
                }}
                className="w-full px-4 py-2 text-left text-[13px] text-[#404944] hover:bg-[#f2f4f6] flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[17px]">location_on</span>
                Operating Facilities
              </button>
              <div className="border-t border-[#eceef0] my-1" />
              <button
                onClick={() => {
                  setShowProfileMenu(false);
                  alert('ESG Enterprise Session: Validated with SEBI/GRI compliance telemetry.');
                }}
                className="w-full px-4 py-2 text-left text-[13px] text-[#ba1a1a] hover:bg-[#ffdad6]/30 flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[17px]">logout</span>
                Sign Out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
