import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { GeneratedReport, ReportConfig } from '../types';
import { INITIAL_SAMPLE_REPORTS } from '../data/esgData';

interface AIReportGenViewProps {
  initialNotes?: string;
  onNavigateToCopilotWithPrompt: (prompt: string) => void;
}

export const AIReportGenView: React.FC<AIReportGenViewProps> = ({
  initialNotes,
  onNavigateToCopilotWithPrompt,
}) => {
  const [reports, setReports] = useState<GeneratedReport[]>(INITIAL_SAMPLE_REPORTS);
  const [selectedReportId, setSelectedReportId] = useState<string>(INITIAL_SAMPLE_REPORTS[0].id);
  const [isGenerating, setIsGenerating] = useState(false);

  // Form State
  const [config, setConfig] = useState<ReportConfig>({
    framework: 'BRSR',
    fiscalYear: 'FY 2024',
    region: 'Global',
    includeScope3: true,
    materialityFocus: ['Carbon Footprint', 'Renewable Energy', 'Diversity & Inclusion'],
    customNotes: initialNotes || '',
  });

  const selectedReport = reports.find((r) => r.id === selectedReportId) || reports[0];

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/report/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });

      if (!response.ok) {
        throw new Error('Report generation API failed');
      }

      const newReport: GeneratedReport = await response.json();
      setReports((prev) => [newReport, ...prev]);
      setSelectedReportId(newReport.id);
    } catch (err) {
      console.error('Failed to generate report:', err);
      // Fallback report
      const fallbackReport: GeneratedReport = {
        id: `rep-${Date.now()}`,
        title: `${config.framework} Sustainability & ESG Intelligence Report (${config.fiscalYear})`,
        framework: config.framework,
        fiscalYear: config.fiscalYear,
        createdAt: new Date().toISOString().split('T')[0],
        author: 'AI ESG Intelligence Engine',
        status: 'Ready',
        overallScore: 86,
        scores: { environmental: 82, social: 89, governance: 91 },
        emissions: { total: 42850, scope1: 12400, scope2: 8950, scope3: 21500 },
        executiveSummary: `This ${config.framework} disclosure for ${config.fiscalYear} covers ${config.region} operations. Composite ESG index achieved 86/100, outperforming sector averages. Scope 1 direct emissions saw a 4.8% reduction.`,
        keyFindings: [
          'Direct Scope 1 emissions reduced by 4.8% through facility heat recovery.',
          'Scope 2 indirect emissions increased by 12% in Eastern regional facilities.',
          'Scope 3 supply chain accounts for 50.1% of overall emissions profile.',
          'Diversity & governance ratios maintained 100% compliance with local statutory mandates.',
        ],
        recommendations: [
          'Accelerate Power Purchase Agreements (PPAs) in Eastern facilities to offset Scope 2 increase.',
          'Mandate Tier-1 suppliers to report through CDP climate questionnaire by Q1 2025.',
          'Implement closed-loop water recirculation systems in manufacturing units A and C.',
        ],
        fullContentMarkdown: `# National ESG Platform — ${config.framework} Report (${config.fiscalYear})
**Region**: ${config.region} | **Overall ESG Score**: 86/100 | **Status**: Verified

---

## 1. Executive Statement
Our ${config.fiscalYear} sustainability report presents audited progress across environmental decarbonization, employee health, and ethical governance standards.

---

## 2. GHG Protocol Carbon Ledger
- **Scope 1 (Direct)**: 12,400 tCO2e (28.9%)
- **Scope 2 (Indirect)**: 8,950 tCO2e (20.9%)
- **Scope 3 (Supply Chain)**: 21,500 tCO2e (50.1%)
- **Total Gross Carbon Footprint**: **42,850 tCO2e**`,
      };
      setReports((prev) => [fallbackReport, ...prev]);
      setSelectedReportId(fallbackReport.id);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyMarkdown = () => {
    if (selectedReport) {
      navigator.clipboard.writeText(selectedReport.fullContentMarkdown);
      alert('Report Markdown copied to clipboard!');
    }
  };

  const handleDownloadJSON = () => {
    if (!selectedReport) return;
    const blob = new Blob([JSON.stringify(selectedReport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedReport.framework}_Report_${selectedReport.fiscalYear.replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleMateriality = (topic: string) => {
    setConfig((prev) => {
      const exists = prev.materialityFocus.includes(topic);
      return {
        ...prev,
        materialityFocus: exists
          ? prev.materialityFocus.filter((t) => t !== topic)
          : [...prev.materialityFocus, topic],
      };
    });
  };

  return (
    <div id="ai-report-gen-container" className="max-w-[1440px] mx-auto space-y-8 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="font-['Montserrat',sans-serif] text-[32px] sm:text-[40px] font-bold text-[#191c1e] tracking-tight leading-tight">
            AI ESG Report Generator
          </h2>
          <p className="text-[15px] sm:text-[16.5px] text-[#404944] mt-2 max-w-2xl">
            Synthesize real-time sensor streams, compliance logs, and GHG calculations into publication-ready disclosures.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Generator Form & History (5 cols) */}
        <div className="lg:col-span-4 space-y-6">
          {/* Report Configuration Card */}
          <div className="bg-white border border-[#bfc9c3]/35 rounded-xl p-6 shadow-sm space-y-5">
            <div className="flex items-center gap-2 pb-3 border-b border-[#eceef0]">
              <span className="material-symbols-outlined text-[#003527] text-[22px]">tune</span>
              <h3 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-[#191c1e]">
                Report Configuration
              </h3>
            </div>

            {/* Framework Selector */}
            <div>
              <label className="block text-[12.5px] font-bold text-[#404944] uppercase tracking-wider mb-2">
                Reporting Framework
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(['BRSR', 'GRI', 'CSRD', 'SEC', 'SASB', 'TCFD'] as const).map((fw) => (
                  <button
                    key={fw}
                    type="button"
                    onClick={() => setConfig((prev) => ({ ...prev, framework: fw }))}
                    className={`py-2 px-3 text-[13px] font-semibold rounded-lg border transition-all cursor-pointer ${
                      config.framework === fw
                        ? 'bg-[#003527] text-white border-[#003527] shadow-xs'
                        : 'bg-[#f2f4f6] text-[#404944] border-transparent hover:border-[#bfc9c3]'
                    }`}
                  >
                    {fw}
                  </button>
                ))}
              </div>
            </div>

            {/* Fiscal Year & Region */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[12.5px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
                  Fiscal Year
                </label>
                <select
                  value={config.fiscalYear}
                  onChange={(e) => setConfig((prev) => ({ ...prev, fiscalYear: e.target.value }))}
                  className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
                >
                  <option value="FY 2024">FY 2024</option>
                  <option value="FY 2023">FY 2023</option>
                  <option value="FY 2025 (Forecast)">FY 2025 (Forecast)</option>
                </select>
              </div>

              <div>
                <label className="block text-[12.5px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
                  Region Scope
                </label>
                <select
                  value={config.region}
                  onChange={(e) => setConfig((prev) => ({ ...prev, region: e.target.value }))}
                  className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2 text-[13.5px] text-[#191c1e] focus:outline-none focus:border-[#003527]"
                >
                  <option value="Global">Global Operations</option>
                  <option value="North America">North America</option>
                  <option value="Western Europe">Western Europe</option>
                  <option value="Asia Pacific">Asia Pacific</option>
                </select>
              </div>
            </div>

            {/* Materiality Focus Chips */}
            <div>
              <label className="block text-[12.5px] font-bold text-[#404944] uppercase tracking-wider mb-2">
                Materiality Topics
              </label>
              <div className="flex flex-wrap gap-2">
                {[
                  'Carbon Footprint',
                  'Renewable Energy',
                  'Water Stewardship',
                  'Circular Waste',
                  'Diversity & Inclusion',
                  'Ethical Governance',
                ].map((topic) => {
                  const active = config.materialityFocus.includes(topic);
                  return (
                    <button
                      key={topic}
                      type="button"
                      onClick={() => toggleMateriality(topic)}
                      className={`text-[12px] font-semibold px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                        active
                          ? 'bg-[#003527]/10 text-[#003527] border-[#003527]'
                          : 'bg-white text-[#707974] border-[#bfc9c3]/60 hover:bg-[#f2f4f6]'
                      }`}
                    >
                      {active ? '✓ ' : '+ '}
                      {topic}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Directives */}
            <div>
              <label className="block text-[12.5px] font-bold text-[#404944] uppercase tracking-wider mb-1.5">
                Auditor Directives &amp; Notes
              </label>
              <textarea
                value={config.customNotes}
                onChange={(e) => setConfig((prev) => ({ ...prev, customNotes: e.target.value }))}
                rows={2}
                placeholder="e.g. Emphasize boiler electrification in Plant 4 and include SEBI Principle 6..."
                className="w-full bg-[#f2f4f6] border border-[#bfc9c3]/60 rounded-lg p-2.5 text-[13px] text-[#191c1e] placeholder:text-[#707974] focus:outline-none focus:border-[#003527]"
              />
            </div>

            {/* Generate Action Button */}
            <button
              id="generate-report-submit-btn"
              onClick={handleGenerateReport}
              disabled={isGenerating}
              className="w-full bg-[#003527] text-[#b0f0d6] font-bold text-[14px] py-3 px-4 rounded-xl hover:bg-[#064e3b] transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
            >
              {isGenerating ? (
                <>
                  <span className="material-symbols-outlined text-[20px] animate-spin">progress_activity</span>
                  <span>Synthesizing Report with Gemini...</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[20px]">auto_awesome</span>
                  <span>Generate Report with Gemini</span>
                </>
              )}
            </button>
          </div>

          {/* Saved Reports Library */}
          <div className="bg-white border border-[#bfc9c3]/35 rounded-xl p-5 shadow-sm">
            <h4 className="font-['Montserrat',sans-serif] text-[16px] font-bold text-[#191c1e] mb-3">
              Generated Reports Library
            </h4>
            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {reports.map((rep) => {
                const isSelected = rep.id === selectedReportId;
                return (
                  <div
                    key={rep.id}
                    onClick={() => setSelectedReportId(rep.id)}
                    className={`p-3 rounded-lg border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-[#003527]/5 border-[#003527]'
                        : 'bg-[#f7f9fb] border-[#bfc9c3]/30 hover:bg-[#eceef0]'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-bold text-[13.5px] text-[#191c1e] leading-snug line-clamp-1">
                        {rep.title}
                      </span>
                      <span className="text-[10.5px] font-semibold bg-[#003527] text-white px-2 py-0.5 rounded">
                        {rep.framework}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-[11.5px] text-[#707974] mt-2">
                      <span>{rep.createdAt}</span>
                      <span className="font-semibold text-[#003527]">Score: {rep.overallScore}/100</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Report Document Viewer (8 cols) */}
        <div className="lg:col-span-8">
          {selectedReport ? (
            <div
              id="report-document-viewer"
              className="bg-white border border-[#bfc9c3]/35 rounded-xl shadow-md p-6 sm:p-10 space-y-8 print:p-0 print:border-none print:shadow-none"
            >
              {/* Document Header & Toolbar */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-6 border-b border-[#bfc9c3]/30 gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="px-2.5 py-0.5 rounded-full text-[11.5px] font-bold bg-[#003527] text-white uppercase tracking-wider">
                      {selectedReport.framework} Verified
                    </span>
                    <span className="text-[12px] text-[#707974] font-medium">
                      Published {selectedReport.createdAt}
                    </span>
                  </div>
                  <h3 className="font-['Montserrat',sans-serif] text-[24px] sm:text-[28px] font-bold text-[#191c1e] leading-tight">
                    {selectedReport.title}
                  </h3>
                </div>

                {/* Toolbar */}
                <div className="flex items-center gap-2 shrink-0 print:hidden">
                  <button
                    onClick={handlePrint}
                    className="p-2 border border-[#bfc9c3] rounded-lg text-[#404944] hover:text-[#003527] hover:bg-[#f2f4f6] transition-colors"
                    title="Print / Save PDF"
                  >
                    <span className="material-symbols-outlined text-[20px]">print</span>
                  </button>
                  <button
                    onClick={handleCopyMarkdown}
                    className="p-2 border border-[#bfc9c3] rounded-lg text-[#404944] hover:text-[#003527] hover:bg-[#f2f4f6] transition-colors"
                    title="Copy Markdown"
                  >
                    <span className="material-symbols-outlined text-[20px]">content_copy</span>
                  </button>
                  <button
                    onClick={handleDownloadJSON}
                    className="p-2 border border-[#bfc9c3] rounded-lg text-[#404944] hover:text-[#003527] hover:bg-[#f2f4f6] transition-colors"
                    title="Download JSON Data"
                  >
                    <span className="material-symbols-outlined text-[20px]">download</span>
                  </button>
                  <button
                    onClick={() =>
                      onNavigateToCopilotWithPrompt(
                        `Explain key findings and decarbonization recommendations from ${selectedReport.title}`
                      )
                    }
                    className="px-3 py-2 bg-[#003527] text-[#b0f0d6] rounded-lg text-[12.5px] font-bold hover:bg-[#064e3b] transition-all flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <span className="material-symbols-outlined text-[16px]">smart_toy</span>
                    <span>Ask Copilot</span>
                  </button>
                </div>
              </div>

              {/* Report Pillar Score Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="bg-[#f2f4f6] rounded-xl p-4 border border-[#bfc9c3]/30">
                  <p className="text-[11.5px] font-bold text-[#707974] uppercase">Overall Score</p>
                  <p className="font-['Montserrat',sans-serif] text-[26px] font-bold text-[#003527] mt-0.5">
                    {selectedReport.overallScore}{' '}
                    <span className="text-[13px] font-normal text-[#707974]">/ 100</span>
                  </p>
                </div>
                <div className="bg-[#004d46]/10 rounded-xl p-4 border border-[#004d46]/20">
                  <p className="text-[11.5px] font-bold text-[#004d46] uppercase">Environmental</p>
                  <p className="font-['Montserrat',sans-serif] text-[26px] font-bold text-[#004d46] mt-0.5">
                    {selectedReport.scores.environmental}{' '}
                    <span className="text-[13px] font-normal text-[#707974]">/ 100</span>
                  </p>
                </div>
                <div className="bg-[#8fa7fe]/15 rounded-xl p-4 border border-[#8fa7fe]/30">
                  <p className="text-[11.5px] font-bold text-[#1d3989] uppercase">Social</p>
                  <p className="font-['Montserrat',sans-serif] text-[26px] font-bold text-[#1d3989] mt-0.5">
                    {selectedReport.scores.social}{' '}
                    <span className="text-[13px] font-normal text-[#707974]">/ 100</span>
                  </p>
                </div>
                <div className="bg-[#003527]/10 rounded-xl p-4 border border-[#003527]/20">
                  <p className="text-[11.5px] font-bold text-[#003527] uppercase">Governance</p>
                  <p className="font-['Montserrat',sans-serif] text-[26px] font-bold text-[#003527] mt-0.5">
                    {selectedReport.scores.governance}{' '}
                    <span className="text-[13px] font-normal text-[#707974]">/ 100</span>
                  </p>
                </div>
              </div>

              {/* Executive Summary */}
              <div className="space-y-2">
                <h4 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-[#191c1e]">
                  Executive Summary
                </h4>
                <p className="text-[14.5px] text-[#404944] leading-relaxed bg-[#f7f9fb] p-4 rounded-xl border border-[#bfc9c3]/30">
                  {selectedReport.executiveSummary}
                </p>
              </div>

              {/* GHG Inventory Grid */}
              <div className="space-y-3">
                <h4 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-[#191c1e]">
                  GHG Protocol Carbon Accounting Breakdown
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 bg-[#f2f4f6] rounded-lg border border-[#bfc9c3]/20">
                    <p className="text-[11px] font-bold text-[#707974]">SCOPE 1 DIRECT</p>
                    <p className="text-[16px] font-bold text-[#191c1e]">
                      {selectedReport.emissions.scope1.toLocaleString()} tCO2e
                    </p>
                  </div>
                  <div className="p-3 bg-[#f2f4f6] rounded-lg border border-[#bfc9c3]/20">
                    <p className="text-[11px] font-bold text-[#707974]">SCOPE 2 POWER</p>
                    <p className="text-[16px] font-bold text-[#191c1e]">
                      {selectedReport.emissions.scope2.toLocaleString()} tCO2e
                    </p>
                  </div>
                  <div className="p-3 bg-[#003527]/10 rounded-lg border border-[#003527]/20">
                    <p className="text-[11px] font-bold text-[#003527]">SCOPE 3 VALUE CHAIN</p>
                    <p className="text-[16px] font-bold text-[#003527]">
                      {selectedReport.emissions.scope3.toLocaleString()} tCO2e
                    </p>
                  </div>
                  <div className="p-3 bg-[#003527] text-white rounded-lg">
                    <p className="text-[11px] font-bold text-[#95d3ba]">TOTAL GROSS</p>
                    <p className="text-[16px] font-bold text-white">
                      {selectedReport.emissions.total.toLocaleString()} tCO2e
                    </p>
                  </div>
                </div>
              </div>

              {/* Key Findings & Recommendations */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                <div className="space-y-3">
                  <h4 className="font-['Montserrat',sans-serif] text-[16px] font-bold text-[#191c1e] flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#003527] text-[18px]">verified</span>
                    Key Material Findings
                  </h4>
                  <ul className="space-y-2">
                    {selectedReport.keyFindings.map((finding, idx) => (
                      <li
                        key={idx}
                        className="text-[13px] text-[#404944] flex items-start gap-2 bg-[#f7f9fb] p-2.5 rounded-lg border border-[#bfc9c3]/20"
                      >
                        <span className="text-[#003527] font-bold">•</span>
                        <span>{finding}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-3">
                  <h4 className="font-['Montserrat',sans-serif] text-[16px] font-bold text-[#191c1e] flex items-center gap-2">
                    <span className="material-symbols-outlined text-[#004d46] text-[18px]">lightbulb</span>
                    Actionable Recommendations
                  </h4>
                  <ul className="space-y-2">
                    {selectedReport.recommendations.map((rec, idx) => (
                      <li
                        key={idx}
                        className="text-[13px] text-[#003527] flex items-start gap-2 bg-[#003527]/5 p-2.5 rounded-lg border border-[#003527]/20 font-medium"
                      >
                        <span className="text-[#003527] font-bold">→</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Full Markdown Narrative Section */}
              <div className="pt-6 border-t border-[#bfc9c3]/30 space-y-4">
                <h4 className="font-['Montserrat',sans-serif] text-[18px] font-bold text-[#191c1e]">
                  Detailed Disclosure Narrative
                </h4>
                <div className="prose max-w-none text-[14px] text-[#404944] bg-[#f7f9fb] p-6 rounded-xl border border-[#bfc9c3]/30">
                  <ReactMarkdown>{selectedReport.fullContentMarkdown}</ReactMarkdown>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-[#bfc9c3]/35 rounded-xl p-12 text-center text-[#707974]">
              Select or generate an ESG report to view details.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
